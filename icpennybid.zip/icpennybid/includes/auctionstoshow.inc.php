<?
if(!defined("INCLUDED")) exit("Access denied");
	$LIMIT = 30;
?>
