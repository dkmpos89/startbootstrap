<?#//v.3.0.0
if(!defined('INCLUDED')) exit("Access denied");
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
#// Retrieve banned free mail domains
$DOMAINS=@mysql_result(@mysql_query("SELECT banemail FROM BPPENNYAUTOBID_usersettings"),0,"banemail");
$BANNEDDOMAINS = array_filter(explode("\n",$DOMAINS),chop);
if(count($BANNEDDOMAINS)>0){
	$TPL_domains_alert=$MSG_30_0053."<UL>";
	while(list($k,$v) = each($BANNEDDOMAINS)){
		$TPL_domains_alert.="<LI><B>".$v."</B>";
	}
	$TPL_domains_alert.="</UL>";
}else{
	$TPL_domains_alert='';
}

Function BannedEmail($email,$domains){
	$dom = explode('@',$email);
	$domains = array_map(chop,$domains);
	if(in_array($dom[1],$domains)){
		return TRUE;
	}else{
		return FALSE;
	}

}
 ?>
