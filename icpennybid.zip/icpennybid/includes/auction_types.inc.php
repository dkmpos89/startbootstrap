<?#//v.3.0.0
if(!defined("INCLUDED")) exit("Access denied");
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

	$auction_types = array (
		1 => "Classic"
//		2 => "Extended",
//        3 => "Extended Reverse"
	);
?>