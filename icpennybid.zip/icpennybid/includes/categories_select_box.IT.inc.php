<SELECT NAME="id">
<OPTION VALUE="">Seleziona la tua categoria</OPTION>
<OPTION VALUE=""></OPTION>
	<OPTION VALUE="3">Auto1</OPTION>
	<OPTION VALUE="2">Computers1</OPTION>
	<OPTION VALUE="1">Phones1</OPTION>
	<OPTION VALUE=""></OPTION>
	<OPTION VALUE="0">tutte le categorie</OPTION>
</SELECT>
