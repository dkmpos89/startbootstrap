<?php
if (!file_exists("includes/passwd.inc.php")) {
	echo "information unavailable";
	exit;
}
#///////////////////////////////////////////////////////
require_once ('./includes/config.inc.php');
#// Run cron according to SETTINGS
if($SETTINGS['cron'] == 2)
{
	//include_once "cron.php";
}
$TIME = mktime(date("H") + $SETTINGS['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));
//echo "<br />";
$NOW = date("YmdHis", $TIME);

$param = $_REQUEST['param'];
if(!validateParam())
{
	echo "information unavailable";
	exit;
}

// prepare classic auctions values (get last created auctions)
$query = "SELECT id,title,starts, ends, pict_url, auction_type, item_value, minimum_bid, bid_value,jump30 FROM BPPENNYAUTOBID_auctions WHERE 
	closed='0' AND suspended=0 AND auction_type = 1 AND ";

$query .= "starts <= " . $NOW;
$query .= " AND id IN($param) ";
//$query .= " ORDER BY ends ASC ";
//echo "SQL: ".$query;

//$query .= "starts <= " . $NOW . " ORDER BY ends ASC LIMIT " . $SETTINGS['lastitemsnumber'];
//echo "sql: ".$query;
//exit;
$result = mysql_query($query);


if($result)
	$num_auction = mysql_num_rows($result);
else
	$num_auction = 0;
$i = 0;
$TPL_auctions_classic = array();
 
$out_param = "";
$out_ids = "";
$out_bids = "";
$out_ends="";
//echo "<br>num_auction".$num_auction;
while($i < $num_auction)
{
	$id = mysql_result($result, $i, "id");
	$ends = mysql_result($result, $i, "ends");
	$jump=mysql_result($result, $i, "jump30");
	
	/*if (strtotime($ends)-strtotime($NOW)<=2) {
		if ($jump==1) {
			$new_ends=date("YmdHis",strtotime($NOW)+32);
			mysql_query("UPDATE BPPENNYAUTOBID_auctions SET ends='".$new_ends."', jump30=0 WHERE id='".$id."'");
		}
	}*/
				
	$minimum_a_bid = mysql_result($result, $i, "minimum_bid");
	$ends = mysql_result($result, $i, "ends");
	
	$sql="SELECT MAX(bid) AS max_bid FROM BPPENNYAUTOBID_bids WHERE auction=".$id;
	$result_bid = mysql_query($sql);

	$TPL_auctions_classic[$i]["current_bid"]=mysql_result($result_bid, 0, "max_bid");
	
	if ($TPL_auctions_classic[$i]["current_bid"]=="") {
		$TPL_auctions_classic[$i]["current_bid"]=$minimum_a_bid;
	}
	if($out_ids != "") $out_ids .= "___";
	
	if($out_bids != "") $out_bids .= "___";
	if($out_ends != "") $out_ends .= "___";
	if($out_next_bids != "") $out_next_bids .= "___";
	if($out_winners != "") $out_winners .= "___";
	
	$out_ids .= $id;
	$out_bids .= print_money($TPL_auctions_classic[$i]["current_bid"]);
	$out_ends .=strtotime($ends)-time();
	$out_next_bids .=print_money(get_next_bid($id));
	if (get_winner_name($id)!="") {
		$out_winners .=get_winner_name($id);
	} else {
		$out_winners .="no-winner";
	}
	$i++;		
}

if($out_ids == "" || $out_bids == "")
{
	$out_param = "No information";
}
else {
	$out_param = $out_ids."---".$out_bids."---".$out_ends."---".$out_next_bids."---".$out_winners;
}

echo $out_param;

exit;

//=========================================================================================================
function validateParam()
{
	global $param;
	$arr = explode($param);
	for($j = 0; $j < count($arr); $j++)
	{
		if(!is_integer($arr[$j])) return false;
	}
	return true;
}
function get_next_bid($auction_id) {
	
	if (intval($auction_id)>0) {
		$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id));
		$result_bids = mysql_query("select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($auction_id) . " GROUP BY auction, bidder ORDER BY maxbid DESC");

		$customincrement = mysql_result($result, 0, "increment");
		$max_bid = mysql_result($result_bids, 0, "maxbid");
		$minimum_bid = mysql_result($result, 0, "minimum_bid");
		if($max_bid == 0) {
			$MAX_BID = $minimum_bid;
			//// Added by Yosi 22 Jul 2009 - consider if auction starts with some value
			$max_bid = $minimum_bid;
		}else
		{
			$MAX_BID = $max_bid;
		}
		/* Get bid increment for current bid and calculate minimum bid */
		
		$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";
		
		//echo "<div style='display:none;'>sql:<br>";
		//echo "$query</div>";
		
		$result_incr = mysql_query($query);
		if(mysql_num_rows($result_incr) != 0)
		{
			$increment = mysql_result($result_incr, 0, "increment");
		}
		if($customincrement > 0)
		{	
			$increment = $customincrement;
		}
		
		if($max_bid == 0 || $atype == 2)
		{
			$next_bid = $minimum_bid;
		}else
		{	
			$next_bid = $max_bid + $increment;
		}
		return $next_bid;
	} else {
		return 0;
	}
}
function get_winner_name($auction_id) {
	$sql = "SELECT b.bid, b.bidder, COUNT(bid) AS bid_count,u.nick
		  FROM BPPENNYAUTOBID_bids b
		  INNER JOIN BPPENNYAUTOBID_users u ON b.bidder=u.id
		  WHERE b.auction=".$auction_id." GROUP BY b.bid ORDER BY b.bid DESC ";
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return $row1['nick'];
	} else {
		return "";
	}
}
?>