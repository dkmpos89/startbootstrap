<?#//v.3.1.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
require('./includes/config.inc.php');
include_once "header.php";
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td>
      <table width="100%" border="0" cellspacing="0" cellpadding="8" height="296" bgcolor="#FFFFFF">
        <tr>
          <td height="292" valign="top">
            <p>&nbsp;</p>
            <p><? print $MSG_1025; ?>
              </b></font></p>
            <table width="91%" border="0" cellspacing="0" cellpadding="6" align="center">
              <tr>
                <td align="center" height="44"><b><? print $MSG_1027; ?></b></font></td>
              </tr>
            </table>
            <table width="85%" border="0" cellspacing="0" cellpadding="0" align="center" height="42">
              <tr>
                <td"height="51" align="center"><A HREF="<?=$SETTINGS['siteurl']?>"><?=$MSG_30_0185?></A></td>
              </tr>
            </table>
            <p>&nbsp;</p><p>
            </p>
          </td>
        </tr>
      </table>

</td>
  </tr>
</table>
<?include_once "footer.php";?>
