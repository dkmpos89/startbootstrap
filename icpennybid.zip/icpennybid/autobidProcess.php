<?php

include_once "./includes/config.inc.php";

//$uid=isset($_REQUEST['uid'])?$_REQUEST['uid']:"";

$TIME = mktime(date("H") + $SETTINGS['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));
$NOW = date("YmdHis", $TIME);

//if ($uid!="")
//{

$query="select BPPENNYAUTOBID_autobids.* from BPPENNYAUTOBID_autobids INNER JOIN BPPENNYAUTOBID_auctions ON BPPENNYAUTOBID_autobids.auction_id = BPPENNYAUTOBID_auctions.id WHERE closed=0";//where bidder_id='".$uid."'";
$result1 = mysql_query($query);

//$TPL_auotobids = array();

//echo $num_auotobids;

$query="select count(BPPENNYAUTOBID_autobids.id) as autobids_sum from BPPENNYAUTOBID_autobids INNER JOIN BPPENNYAUTOBID_auctions ON BPPENNYAUTOBID_autobids.auction_id = BPPENNYAUTOBID_auctions.id WHERE closed=0";//where bidder_id='".$_SESSION["BPPENNYAUTOBID_LOGGED_IN"]."'";
$result = mysql_query($query);
$autobids_sum= mysql_result($result, 0, "autobids_sum");

global $out_param,$out_ids,$out_balance;

$out_param="";
$out_ids="";
$out_balance="";

//echo $autobids_sum."fff";
//echo $autobids_sum;
if($autobids_sum!="0")
{
while ($row=mysql_fetch_array($result1,MYSQL_ASSOC))
{
	$select="SELECT id,bidwhen FROM BPPENNYAUTOBID_bids WHERE bid= (SELECT MAX(bid) FROM BPPENNYAUTOBID_bids where bidder ='".$row["bidder_id"]."' AND auction='".$row["auction_id"]."') AND bidder ='".$row["bidder_id"]."' AND auction='".$row["auction_id"]."'";
	$q_result = mysql_query($select);
	
	
	$user_id=$row["bidder_id"];
	$id_bid=mysql_result($q_result, 0, "id");
	$bidwhen= mysql_result($q_result, 0, "bidwhen");
	$auction_id=$row["auction_id"];
	$time_since_last_bid=strtotime($NOW)-strtotime($bidwhen);
	$bid_value=get_next_bid($auction_id);
	
	//echo $bid_value."  time_since_last_bid".$time_since_last_bid."  ".$SETTINGS["aoutobid_step"];
	
	if($time_since_last_bid>=$SETTINGS["aoutobid_step"])
	{
				if($row['remained_bids']>0 && $row['max_amount']>$bid_value) {

					if ($user_id!=get_current_bidder_id($auction_id)) {//echo "in here";

						if (do_bid($auction_id,$user_id,$bid_value)) {

							mysql_query("UPDATE BPPENNYAUTOBID_autobids SET remained_bids=remained_bids-1 WHERE id='".$row['id']."'");	
							//echo "kk".$out_ids."kk";
						}

					}

				}
	}
	
	//echo "ll".$out_ids."ll";
	if($out_ids != "")
	{
		$out_param = $out_ids."---".$out_balance;
	}
	echo $out_param;//."lll";
	
	//echo $select;//$bidwhen
	/*if($auction_id != "") $out_auction_id .= ($auction_id . "___");
	if($bidwhen != "") $out_bidwhen .= ($bidwhen . "___");
	if($time_since_last_bid != "") $out_time_since_last_bid .= ($time_since_last_bid . "___");
	if($user_id != "") $out_user_id .= ($user_id . "___");*/
}

//$out_auction_id = substr($out_auction_id, 0, -3); 
//$out_bidwhen = substr($out_bidwhen, 0, -3); 
//$out_time_since_last_bid = substr($out_time_since_last_bid, 0, -3);
//$out_user_id= substr($out_user_id, 0, -3);

/*$out_param = $out_auction_id."---".$out_bidwhen."---".$out_time_since_last_bid."---".$out_user_id;
	echo $out_param;*/
}
//}

function get_next_bid($auction_id) {

	

	if (intval($auction_id)>0) {

		$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id));

		$result_bids = mysql_query("select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($auction_id) . " GROUP BY auction, bidder ORDER BY maxbid DESC");

		$customincrement = mysql_result($result, 0, "increment");

		$max_bid = mysql_result($result_bids, 0, "maxbid");

		$minimum_bid = mysql_result($result, 0, "minimum_bid");

		if($max_bid == 0) {

			$MAX_BID = $minimum_bid;



			$max_bid = $minimum_bid;

		}else

		{

			$MAX_BID = $max_bid;

		}

		/* Get bid increment for current bid and calculate minimum bid */

		

		$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";

		

		//echo "<div style='display:none;'>sql:<br>";

		//echo "$query</div>";

		

		$result_incr = mysql_query($query);

		if(mysql_num_rows($result_incr) != 0)

		{

			$increment = mysql_result($result_incr, 0, "increment");

		}

		if($customincrement > 0)

		{	

			$increment = $customincrement;

		}

		

		if( $atype == 2)//$max_bid == 0 ||

		{

			$next_bid = $minimum_bid;

		}else

		{	

			$next_bid = $max_bid + $increment;

		}

		return $next_bid;

	} else {

		return 0;

	}

}





function do_bid($auction_id,$user_id,$bid_value) {

global $out_param,$out_ids,$out_balance;

	//$bid_sum - cost of bid

	

	if (intval($auction_id)>0 && intval($user_id)>0 && $bid_value>0) {

        $TIME = mktime(date("H") + $GLOBALS['SETTINGS']['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));

		$NOW = date("YmdHis", $TIME);

        $sql="SELECT ends,bid_value,closed FROM BPPENNYAUTOBID_auctions WHERE id='".$auction_id."'";

        $result1=mysql_query($sql);

        $ends = mysql_result($result1, 0, "ends");

        $closed=mysql_result($result1, 0, "closed");

		

		$result_b = mysql_query("SELECT id, balance FROM BPPENNYAUTOBID_users WHERE id='" .$user_id. "'");

		$bal_row = mysql_fetch_array($result_b);

		$balance = $bal_row['balance'];

		

		if ($closed==0) {

			

		

			if ($balance>0) {

				if ((strtotime($ends)-strtotime($NOW)>=0) && (strtotime($ends)-strtotime($NOW)<=15)) {

					//$new_ends=date("YmdHis",strtotime($NOW)+32);

					//mysql_query("UPDATE BPPENNYAUTOBID_auctions SET jump30=1 WHERE id='".$auction_id."'");

					//echo "UPDATE auctions SET ends='".$new_ends."' WHERE auction_id='".$auction_id."'";

					$new_ends=date("YmdHis",strtotime($ends)+15-(strtotime($ends)-strtotime($NOW))+1);

					mysql_query("UPDATE BPPENNYAUTOBID_auctions SET ends='".$new_ends."', jump30=0 WHERE id='".$auction_id."'");

					

				}

				

				if (strtotime($ends)-strtotime($NOW)>=0) {

					$insert = "INSERT INTO BPPENNYAUTOBID_bids(auction, bidder, bid, bidwhen)

							   VALUES('" .$auction_id. "','" .$user_id. "','" .converttonum($bid_value). "','" .$NOW. "')";

						

					

					mysql_query($insert);

	

					

					

					$balance -= 1;

					$update = "UPDATE BPPENNYAUTOBID_users SET balance=".$balance."

								  WHERE id=".$user_id;

					

					mysql_query($update);
					
					if($out_ids != "") $out_ids .= "___";
					if($out_balance != "") $out_balance .= "___";
					
					$out_ids .= $user_id;
					$out_balance .= $balance;
//echo "hhh".$out_ids."hhh".$out_balance."hhh";
					return 1;

				}else {

					return 3;

				}

			} else {

				return 2;	

			}

		} else {

			return 3;

		}

	} else {

		return 4;

	}

}



function converttonum($convertnum){

	$bits = explode(",",$convertnum); // split input value up to allow checking

   

	$first = strlen($bits[0]); // gets part before first comma (thousands/millions)

	$last = strlen($bits[1]); // gets part after first comma (thousands (or decimals if incorrectly used by user)

   

	if ($last <3){ // checks for comma being used as decimal place

		$convertnum = str_replace(",",".",$convertnum);

	}

	else{ // assume comma is a thousands seperator, so remove it

		$convertnum = str_replace(",","",$convertnum);

	}

   

	return $convertnum; 

}



function get_current_bid($auction_id) {

	$sql = "SELECT bid 

              FROM BPPENNYAUTOBID_bids

              WHERE auction=".$auction_id." ORDER BY bid DESC";

	$result = mysql_query($sql);

	if ($row1=mysql_fetch_array($result)) {

		return $row1['bid'];

	} else {

		return "";

	}

}



function get_current_bidder_id($auction_id) {

	$sql = "SELECT b.bid, b.bidder, COUNT(bid) AS bid_count,u.nick

              FROM BPPENNYAUTOBID_bids b

			  INNER JOIN BPPENNYAUTOBID_users u ON b.bidder=u.id

              WHERE b.auction=".$auction_id." GROUP BY b.bid ORDER BY b.bid DESC ";

	$result = mysql_query($sql);

	if ($row1=mysql_fetch_array($result)) {

		return $row1['bidder'];

	} else {

		return "";

	}

}



//AUTOBID IN AJAX!

function autobidProcessing($auction_id=0) {

	if (intval($auction_id)>0) {

		//do { commented for testing

			$sql="SELECT

					BPPENNYAUTOBID_autobids.id,

					BPPENNYAUTOBID_autobids.bidder_id,

					BPPENNYAUTOBID_autobids.remained_bids,

					BPPENNYAUTOBID_autobids.max_amount,

					BPPENNYAUTOBID_users.balance

				FROM BPPENNYAUTOBID_autobids

				INNER JOIN BPPENNYAUTOBID_users ON BPPENNYAUTOBID_autobids.bidder_id=BPPENNYAUTOBID_users.id

				WHERE

					BPPENNYAUTOBID_autobids.auction_id='".$auction_id."'";

			$result=mysql_query($sql);

			//$return_flag=false;

			$bid_flag=false;

			while($row=mysql_fetch_array($result)) {

				if ($row['remained_bids']>0 && $row['max_amount']>get_next_bid($auction_id)) {

					if ($row['bidder_id']!=get_current_bidder_id($auction_id)) {

						if (do_bid($auction_id,$row['bidder_id'],get_next_bid($auction_id))) {

							mysql_query("UPDATE BPPENNYAUTOBID_autobids SET remained_bids=remained_bids-1 WHERE id='".$row['id']."'");

							$bid_flag=true;

						}

					}

				}

			}

		//} while ($bid_flag);

	}

}



function user_balance($user_id) {

	$sql="SELECT balance FROM BPPENNYAUTOBID_users WHERE id='".intval($user_id)."'";

	$result=mysql_query($sql);

	return mysql_result($result,0,"balance");

}



?>

