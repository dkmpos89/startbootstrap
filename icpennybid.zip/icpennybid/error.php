<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
require('./includes/config.inc.php');
require("header.php");
include_once phpa_include("template_error_php.html");
include_once "./footer.php";
?>
