


$(document).ready(function () {
  $('[data-toggle=offcanvas1]').click(function () {
    $('.row-offcanvas1').toggleClass('active')
  });
});







$(document).ready(function(){
  $(".toggle-search1").click(function(){
    $(".text-ser1").slideToggle();
  });
});



