<?php


include './includes/config.inc.php';
include $include_path.'auction_types.inc.php';
include $include_path.'dates.inc.php';
include $include_path."membertypes.inc.php";

$auction_id = $_REQUEST['param'];
$TIME = mktime(date("H") + $SETTINGS['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));
//echo "<br />";
$NOW = date("YmdHis", $TIME);

if($auction_id != ""){
	
	// find won bid - the highest ( and unique - in current version all bids are unique )
	$sql = "SELECT bid, bidder, COUNT(bid) AS bid_count FROM BPPENNYAUTOBID_bids WHERE auction=".intval($auction_id)." GROUP BY bid HAVING bid_count = 1 ORDER BY bid DESC ";
	$result_check_winner = mysql_query($sql);
	if ($row = mysql_fetch_array($result_check_winner)){
		$won_bid = $row['bid'];
	}else{
		$won_bid = "";
	}
	
	// find other unique bids
	$unique = array();	
	while ($row = mysql_fetch_array($result_check_winner)){
		$unique[] = $row['bid'];
	}
			
			
	// pepare list of bids
	$sql = "SELECT
			b.id, b.bidder, b.bid, b.auction, b.bidwhen,
			u.nick
		FROM
			BPPENNYAUTOBID_bids b INNER JOIN BPPENNYAUTOBID_users u ON b.bidder=u.id
			
		WHERE
			
			b.auction = '".intval($auction_id)."'
		ORDER BY
			b.bid DESC LIMIT 10";
	
	$result = mysql_query($sql);
	$idcheck= "";
	if ($result) {
		$tplv = "";
		$bgColor = "#EBEBEB";
		$bgColorWon = "#0000cd";
		$bgColorUnique = "#ffff00";
		$bgColorNone = "#cd0000";
		$tplv .= "<table width='100%' border=0 cellpadding=4 cellspacing=1>
                            <tr class='titTable5' style='background:#fffdd4;'>
                                <td align=CENTER>".$MSG_116."</td>
                                <td align=CENTER>".$MSG_5180."</td>";
		while ($row=mysql_fetch_array($result)) {
	
			$bid = $row['bid'];
			//$bidwhen_date = date("Y-m-d h:i:s");
			$hour = substr($row["bidwhen"],8,2)+$SETTINGS['timecorrection'];
			
			$h_time = mktime($hour,date("i"),date("s"),date("m"), date("d"),date("Y"));
			$ampm = date("A",$h_time);
			
			if($hour>24) $hour-=24;
			
			if($hour>12)
			{
				$hour-=12;
			}
			
			if(strlen($hour)==1)$hour = "0".$hour;
		
			
			if($bgColor == "#EBEBEB") {
				$bgColor = "#fffdd4";
			} else {
				$bgColor = "#EBEBEB";
			}
			$tplv .= "<tr VALIGN=MIDDLE BGCOLOR=\"$bgColor\">"; 			
			if($won_bid == $bid) {
				$tplv .= "<td align='center' BGCOLOR='".$bgColorWon."'><font color='#ffffff'><b>".$bid."</b></font></td>";	
			}else{
				$tplv .= "<td align='center' ><font color='#ffffff'><b style='color:#333333'>".$bid."</b></td>";	
			}/*else{
				$tplv .= "<td align='center' BGCOLOR='".$bgColorNone."'><font color='#ffffff'><b>".$bid."</b></td>";	
			}*/
			if ($_SESSION[BPPENNYAUTOBID_LOGGED_IN]==$row['bidder']) {
				$style="style='font-weight:bold;'";
			} else {
				$style="";
			}
			if($won_bid == $bid) {
				$tplv .= "<td align='center' ".$style." BGCOLOR='".$bgColorWon."'><font color='#ffffff'><b>".$row['nick']."</b></font></td>";	
			}else{
				$tplv .= "<td align='center'".$style." ><font color='#ffffff'><b style='color:#333333'>".$row['nick']."</b></td>";	
			}
			
			$tplv .= "</tr>";
		}
		$TPL_auctions_list_value = $tplv;	
	} else {
		$auctions_count = 0;
		$TPL_auctions_list_value = "<tr ALIGN=CENTER><td COLSPAN=5>&nbsp;</td></tr>";  
	}
	$TPL_auctions_list_value.="</table>";
}
echo $TPL_auctions_list_value;
?>