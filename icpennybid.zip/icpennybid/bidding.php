<?
include_once "./includes/config.inc.php";
$aid=isset($_REQUEST['aid'])?$_REQUEST['aid']:"";

$current_bidder=explode("-",get_current_bidder_id($aid));
$current_bidder_id=$current_bidder[0];
$current_bidder_nick=$current_bidder[1];

if ($current_bidder_id!="") {
	$winner_txt=($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]==$current_bidder_id) ? "You are the winner for now" : $current_bidder_nick." is winning for now!";
} else {
	$winner_txt="";
}
$blink=($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]==$current_bidder_id) ? "0":"1";
echo print_money(get_current_bid($aid))."-".get_next_bid($aid)."-".$winner_txt."-".$blink."-".get_time($aid);

function get_next_bid($auction_id) {
	
	if (intval($auction_id)>0) {
		$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id));
		$result_bids = mysql_query("select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($auction_id) . " GROUP BY auction, bidder ORDER BY maxbid DESC");

		$customincrement = mysql_result($result, 0, "increment");
		$max_bid = mysql_result($result_bids, 0, "maxbid");
		$minimum_bid = mysql_result($result, 0, "minimum_bid");
		if($max_bid == 0) {
			$MAX_BID = $minimum_bid;
			//// Added by Yosi 22 Jul 2009 - consider if auction starts with some value
			$max_bid = $minimum_bid;
		}else
		{
			$MAX_BID = $max_bid;
		}
		/* Get bid increment for current bid and calculate minimum bid */
		
		$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";
		
		//echo "<div style='display:none;'>sql:<br>";
		//echo "$query</div>";
		
		$result_incr = mysql_query($query);
		if(mysql_num_rows($result_incr) != 0)
		{
			$increment = mysql_result($result_incr, 0, "increment");
		}
		if($customincrement > 0)
		{	
			$increment = $customincrement;
		}
		
		if($max_bid == 0 || $atype == 2)
		{
			$next_bid = $minimum_bid;
		}else
		{	
			$next_bid = $max_bid + $increment;
		}
		return $next_bid;
	} else {
		return 0;
	}
}


function do_bid($auction_id,$user_id,$bid_value) {
	global $bid_sum,$NOW;
	//$bid_sum - cost of bid
	
	if (intval($auction_id)>0 && intval($user_id)>0 && $bid_value>0) {
		
		$result_b = mysql_query("SELECT id, balance FROM BPPENNYAUTOBID_users WHERE id='" .$user_id. "'");
		$bal_row = mysql_fetch_array($result_b);
		$balance = $bal_row['balance'];
		
			
		if ($balance>$bid_sum) {
			$insert = "INSERT INTO BPPENNYAUTOBID_bids(auction, bidder, bid, bidwhen)
					   VALUES('" .$auction_id. "','" .$user_id. "','" .converttonum($bid_value). "','" .$NOW. "')";
				
			
			mysql_query($insert);
			
			$balance -= $bid_sum;
			$update = "UPDATE BPPENNYAUTOBID_users SET balance=".$balance."
						  WHERE id=".$user_id;
			
			mysql_query($update);
			return true;
		} else {
			return false;	
		}
	} else {
		return false;
	}
}

function converttonum($convertnum){
	$bits = explode(",",$convertnum); // split input value up to allow checking
   
	$first = strlen($bits[0]); // gets part before first comma (thousands/millions)
	$last = strlen($bits[1]); // gets part after first comma (thousands (or decimals if incorrectly used by user)
   
	if ($last <3){ // checks for comma being used as decimal place
		$convertnum = str_replace(",",".",$convertnum);
	}
	else{ // assume comma is a thousands seperator, so remove it
		$convertnum = str_replace(",","",$convertnum);
	}
   
	return $convertnum; 
}

function get_current_bid($auction_id) {
	$sql = "SELECT bid 
              FROM BPPENNYAUTOBID_bids
              WHERE auction=".$auction_id." ORDER BY bid DESC";
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return $row1['bid'];
	} else {
		return "";
	}
}

function get_current_bidder_id($auction_id) {
	$sql = "SELECT b.bid, b.bidder, COUNT(bid) AS bid_count,u.nick
              FROM BPPENNYAUTOBID_bids b
			  INNER JOIN BPPENNYAUTOBID_users u ON b.bidder=u.id
              WHERE b.auction=".$auction_id." GROUP BY b.bid ORDER BY b.bid DESC ";
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return $row1['bidder']."-".$row1['nick'];
	} else {
		return "";
	}
}

function get_time($auction_id) {
	$sql = "SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id);
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return strtotime($row1['ends'])-time();
	} else {
		return "";
	}
}

?>