<?php
include "./includes/config.inc.php";
$aid=isset($_REQUEST['aid'])?$_REQUEST['aid']:"";
$uid=isset($_REQUEST['uid'])?$_REQUEST['uid']:"";

if ($aid!="" && $uid!=0) {
    $buy_seat=buy_seat($aid,$uid);
	if ($buy_seat==1) {
		echo "Purchase was completed successfully!";		
	} else if ($buy_seat==2) {
             echo "Insufficient bids in your account!";
	} else if ($buy_seat==3) {
	    echo "Error! Please try later.";
	} 
}
 	

function buy_seat($auction_id,$user_id) {
	global $SETTINGS;
	$sql="SELECT title,Seat_Number,Seat_Price,closed,started,starts,ends FROM BPPENNYAUTOBID_auctions WHERE id='".$auction_id."'";
	$result1=mysql_query($sql);
	$started=mysql_result($result1, 0, "started");
	$closed=mysql_result($result1, 0, "closed");
	$starts=mysql_result($result1, 0, "starts");
	$title=mysql_result($result1, 0, "title");
	$ends=mysql_result($result1, 0, "ends");
	$seat_price=mysql_result($result1, 0, "Seat_Price");
	$seats_number=mysql_result($result1, 0, "Seat_Number");
	
	$result_b = mysql_query("SELECT id, balance FROM BPPENNYAUTOBID_users WHERE id='" .$user_id. "'");
	$bal_row = mysql_fetch_array($result_b);
	$balance = $bal_row['balance'];
	
	$sql1="SELECT COUNT(*) as seats_sold FROM BPPENNYAUTOBID_auctions_signed WHERE auction_id=".$auction_id;
	
        $result1=mysql_query($sql1);
	$seats_sold = mysql_result($result1,0,"seats_sold");
	
	$sql2="SELECT * FROM BPPENNYAUTOBID_auctions_signed WHERE auction_id=".$auction_id." and user_id=".$user_id;
        $result2=mysql_query($sql2);
	$is_signed=mysql_num_rows($result2);
     
	if ($seats_number > $seats_sold && $started==0 && $is_signed==0) {
		if ($balance>=$seat_price) {
			$sql="INSERT INTO BPPENNYAUTOBID_auctions_signed SET
			user_id='".$user_id."',
			auction_id='".$auction_id."'";
			@mysql_query($sql);
			
			$balance -= $seat_price;
			$update = "UPDATE BPPENNYAUTOBID_users SET balance=".$balance."
						  WHERE id=".$user_id;
			
			@mysql_query($update);
			
                     
                        
			if (get_free_seats($auction_id)==0) { 
				$duration_sec=strtotime($ends)-strtotime($starts);
				$start_time=date("YmdHis");
				$update = "UPDATE BPPENNYAUTOBID_auctions SET started=1,
							starts='".$start_time."',
							ends='".date("YmdHis",(time()+$duration_sec))."'
						  WHERE id=".$auction_id;
				//echo $update;		  
				@mysql_query($update);
				$sql_e="SELECT
						a.nick,
						a.name,
						a.email
						FROM BPPENNYAUTOBID_auctions_signed asi
						INNER JOIN BPPENNYAUTOBID_users a ON asi.user_id=a.id
						WHERE asi.auction_id='".$auction_id."'";
				//echo $sql_e;
				$result_e=mysql_query($sql_e);
				while ($row_e=mysql_fetch_assoc($result_e)) {
					MySendMail($row_e['email'],$row_e['nick'],$title,$auction_id,"mail_started.EN.inc.php");
				}
			}
			return 1;
		} else {
			return 2;
		}
	} else {
		return 3;
	}
	
	 	 	
}
function get_free_seats($auction_id) {
	$sql="SELECT Seat_Number,Seat_Price,closed,started FROM BPPENNYAUTOBID_auctions WHERE id='".$auction_id."'";
	$result1=mysql_query($sql);
	$seats_number=mysql_result($result1, 0, "Seat_Number");

	$sql1="SELECT COUNT(*) as seats_sold FROM BPPENNYAUTOBID_auctions_signed WHERE auction_id=".$auction_id;
	$result1=mysql_query($sql1);
	$seats_sold = mysql_result($result1,0,"seats_sold");

	return $seats_number-$seats_sold;
}


function MySendMail($mail_to, $user_name, $auc_title, $auction_id, $file){
	global $include_path;
	global $SETTINGS;
	global $TIME;
	$now = date("Y/m/d H:i:s",$TIME);
	$CHARSET = "iso-8859-1";
	include_once($include_path.$file);	
}

?>
