<?php
include_once "./includes/config.inc.php";
$aid=isset($_REQUEST['aid'])?$_REQUEST['aid']:"";
$uid=isset($_REQUEST['uid'])?$_REQUEST['uid']:"";


if ($aid!="" && $uid!=0) {
    if (get_current_bidder_id($aid)!=$uid) {
        if (do_bid($aid,$uid,get_next_bid($aid))==1) {
			//autobidProcessing($aid);
			echo user_balance($uid)."-".$aid;
		}
	} else {
		echo user_balance($uid)."-".$aid;
	}
}

function get_next_bid($auction_id) {
	
	if (intval($auction_id)>0) {
		$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id));
		$result_bids = mysql_query("select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($auction_id) . " GROUP BY auction, bidder ORDER BY maxbid DESC");

		$customincrement = mysql_result($result, 0, "increment");
		$max_bid = mysql_result($result_bids, 0, "maxbid");
		$minimum_bid = mysql_result($result, 0, "minimum_bid");
		if($max_bid == 0) {
			$MAX_BID = $minimum_bid;

			$max_bid = $minimum_bid;
		}else
		{
			$MAX_BID = $max_bid;
		}
		/* Get bid increment for current bid and calculate minimum bid */
		
		$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";
		
		//echo "<div style='display:none;'>sql:<br>";
		//echo "$query</div>";
		
		$result_incr = mysql_query($query);
		if(mysql_num_rows($result_incr) != 0)
		{
			$increment = mysql_result($result_incr, 0, "increment");
		}
		if($customincrement > 0)
		{	
			$increment = $customincrement;
		}
		
		if( $atype == 2)//$max_bid == 0 ||
		{
			$next_bid = $minimum_bid;
		}else
		{	
			$next_bid = $max_bid + $increment;
		}
		return $next_bid;
	} else {
		return 0;
	}
}


function do_bid($auction_id,$user_id,$bid_value) {

	//$bid_sum - cost of bid
	
	if (intval($auction_id)>0 && intval($user_id)>0 && $bid_value>0) {
        $TIME = mktime(date("H") + $GLOBALS['SETTINGS']['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));
		$NOW = date("YmdHis", $TIME);
        $sql="SELECT ends,bid_value,closed,w_seat FROM BPPENNYAUTOBID_auctions WHERE id='".$auction_id."'";
        $result1=mysql_query($sql);
        $ends = mysql_result($result1, 0, "ends");
        $closed=mysql_result($result1, 0, "closed");
        $w_seat=mysql_result($result1, 0, "w_seat");
		
		$result_b = mysql_query("SELECT id, balance FROM BPPENNYAUTOBID_users WHERE id='" .$user_id. "'");
		$bal_row = mysql_fetch_array($result_b);
		$balance = $bal_row['balance'];
		
		if($closed==0){
			if(($balance>0 && $w_seat==1)||($w_seat==2)) {//echo ((strtotime($ends)-strtotime($NOW))<=$GLOBALS['SETTINGS']["extension_time"])."Gg";
				if((strtotime($ends)-strtotime($NOW)>=0) && ((strtotime($ends)-strtotime($NOW))<=$GLOBALS['SETTINGS']["extension_time"])) {
					$new_ends=date("YmdHis",strtotime($ends)+$GLOBALS['SETTINGS']["extension_time"]-(strtotime($ends)-strtotime($NOW))+1);
					mysql_query("UPDATE BPPENNYAUTOBID_auctions SET ends='".$new_ends."', jump30=0 WHERE id='".$auction_id."'");
				}
 
                // added 02.11.2011 - IC
				$result_check = mysql_query("SELECT COUNT(*) as cnt FROM BPPENNYAUTOBID_bids WHERE auction = ".$auction_id." AND bid = ".converttonum($bid_value));
				if($row_check = mysql_fetch_array($result_check)){
					if($row_check['cnt'] <= 0){
                        // now we can add new bid
						if(strtotime($ends)-strtotime($NOW)>=0) {
							$insert = "INSERT INTO BPPENNYAUTOBID_bids(auction, bidder, bid, bidwhen)
									   VALUES('" .$auction_id. "','" .$user_id. "','" .converttonum($bid_value). "','" .$NOW. "')";
							mysql_query($insert);
							
							if ($w_seat==1) {
								$balance -= 1;
								$update = "UPDATE BPPENNYAUTOBID_users SET balance=".$balance." WHERE id=".$user_id;
								mysql_query($update);
							}
							return 1;
						}else {
							return 3;
						}						
					}					
				}
				return 5; // error - such bif already exists
			} else {
				return 2;	
			}
		} else {
			return 3;
		}
	} else {
		return 4;
	}
}

function converttonum($convertnum){
	$bits = explode(",",$convertnum); // split input value up to allow checking
   
	$first = strlen($bits[0]); // gets part before first comma (thousands/millions)
	$last = strlen($bits[1]); // gets part after first comma (thousands (or decimals if incorrectly used by user)
   
	if ($last <3){ // checks for comma being used as decimal place
		$convertnum = str_replace(",",".",$convertnum);
	}
	else{ // assume comma is a thousands seperator, so remove it
		$convertnum = str_replace(",","",$convertnum);
	}
   
	return $convertnum; 
}

function get_current_bid($auction_id) {
	$sql = "SELECT bid 
              FROM BPPENNYAUTOBID_bids
              WHERE auction=".$auction_id." ORDER BY bid DESC";
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return $row1['bid'];
	} else {
		return "";
	}
}

function get_current_bidder_id($auction_id) {
	$sql = "SELECT b.bid, b.bidder, COUNT(bid) AS bid_count,u.nick
              FROM BPPENNYAUTOBID_bids b
			  INNER JOIN BPPENNYAUTOBID_users u ON b.bidder=u.id
              WHERE b.auction=".$auction_id." GROUP BY b.bid ORDER BY b.bid DESC ";
	$result = mysql_query($sql);
	if ($row1=mysql_fetch_array($result)) {
		return $row1['bidder'];
	} else {
		return "";
	}
}

//AUTOBID IN AJAX!
function autobidProcessing($auction_id=0) {
	if (intval($auction_id)>0) {
		//do { commented for testing
			$sql="SELECT
					BPPENNYAUTOBID_autobids.id,
					BPPENNYAUTOBID_autobids.bidder_id,
					BPPENNYAUTOBID_autobids.remained_bids,
					BPPENNYAUTOBID_autobids.max_amount,
					BPPENNYAUTOBID_users.balance
				FROM BPPENNYAUTOBID_autobids
				INNER JOIN BPPENNYAUTOBID_users ON BPPENNYAUTOBID_autobids.bidder_id=BPPENNYAUTOBID_users.id
				WHERE
					BPPENNYAUTOBID_autobids.auction_id='".$auction_id."'";
			$result=mysql_query($sql);
			//$return_flag=false;
			$bid_flag=false;
			while($row=mysql_fetch_array($result)) {
				if ($row['remained_bids']>0 && $row['max_amount']>get_next_bid($auction_id)) {
					if ($row['bidder_id']!=get_current_bidder_id($auction_id)) {
						if (do_bid($auction_id,$row['bidder_id'],get_next_bid($auction_id))) {
							mysql_query("UPDATE BPPENNYAUTOBID_autobids SET remained_bids=remained_bids-1 WHERE id='".$row['id']."'");
							$bid_flag=true;
						}
					}
				}
			}
		//} while ($bid_flag);
	}
}

function user_balance($user_id) {
	$sql="SELECT balance FROM BPPENNYAUTOBID_users WHERE id='".intval($user_id)."'";
	$result=mysql_query($sql);
	return mysql_result($result,0,"balance");
}

?>
