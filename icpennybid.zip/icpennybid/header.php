<?
//---added by Shevy May 2010 autobid with step

$query="SELECT aoutobid_step FROM BPPENNYAUTOBID_settings";
$result = mysql_query($query);
$aoutobid_step= mysql_result($result, 0, "aoutobid_step");


$ip=$_SERVER['REMOTE_ADDR'];
//close if accecrd more then 500 times
$select="select count(ip) as ip from Count_ip where ip='".$ip."' and count>3000";
$result = mysql_query($select);
$ip_count= mysql_result($result, 0, "ip");

//echo $shevy."dd";

if($ip_count!=0)
{
//echo "<script>alert('Access to demo from your IP address has been suspended.');</script>";
echo "<script>document.location.href='Access_denied.php'</script>";
exit();
}
/*$query="select count(id) as autobids_sum from BPPENNYAUTOBID_autobids where bidder_id='".$_SESSION["BPPENNYAUTOBID_LOGGED_IN"]."'";
$result = mysql_query($query);
$autobids_sum= mysql_result($result, 0, "autobids_sum");
*/

//---eof added by Shevy May 2010
if(!defined("INCLUDED")) exit("Access denied");

$prefix = str_replace("http://", "", $prefix);
if ( file_exists($prefix.'./includes/config.inc.php'))
  require($prefix.'./includes/config.inc.php');
else
  exit ("Access forbbiden");

#// Atuomatically login user is necessary ("Remember me" option
if(!isset($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]) && isset($_COOKIE['BPPENNYAUTOBID_RM_ID'])) {
	$query = "SELECT userid FROM BPPENNYAUTOBID_rememberme WHERE hashkey='".addslashes($_COOKIE['BPPENNYAUTOBID_RM_ID'])."'";
	$res = mysql_query($query);
	if(!$res){
		MySQLError($query);
		exit;
	}elseif(mysql_num_rows($res) > 0){
		$REMEMBER = mysql_fetch_array(mysql_query("SELECT id,email,nick,name FROM BPPENNYAUTOBID_users WHERE id=".intval(mysql_result($res,0,"userid"))));
		mysql_error();
		$_SESSION["BPPENNYAUTOBID_LOGGED_IN"] = $REMEMBER['id'];
		$_SESSION["BPPENNYAUTOBID_LOGGED_EMAIL"] = $REMEMBER['email']; 
		$_SESSION["BPPENNYAUTOBID_LOGGED_NAME"] = $REMEMBER['name'];
		$_SESSION["BPPENNYAUTOBID_LOGGED_IN_USERNAME"] = $REMEMBER['nick'];
	}
}



include_once $prefix."includes/ips.inc.php";
//-- Function definition section
include_once $prefix."includes/dates.inc.php";

include_once $prefix."maintenance.php";
include_once $prefix."includes/banners.inc.php";

// flag to enable style editor
$editstyle=isset($_SESSION["BPPENNYAUTOBID_ADMIN_USER"]) && !isset($_GET['thepage']);
$editstyle=$editstyle && $prefix=="";



if (!isset($SETTINGS['theme']) || empty($SETTINGS['theme'])) $SETTINGS['theme']='default';
$htmlheader="themes/".$SETTINGS['theme']."/header.php.html";

if (!file_exists($htmlheader)) {
	$htmlheader="../../themes/".$SETTINGS['theme']."/header.php.html";
}
$catids="";
function drawCategories($parent_id, $catlistids="",$level=0,$selected="") {
     global $USERLANG;
	 global $catids;
	 $result = mysql_query("SELECT 
	 			BPPENNYAUTOBID_categories.cat_id,
	 			BPPENNYAUTOBID_cats_translated.cat_name 
	 		FROM BPPENNYAUTOBID_categories 
     		INNER JOIN BPPENNYAUTOBID_cats_translated ON BPPENNYAUTOBID_categories.cat_id=BPPENNYAUTOBID_cats_translated.cat_id
     		WHERE BPPENNYAUTOBID_cats_translated.cat_name!='' AND BPPENNYAUTOBID_categories.parent_id='".$parent_id."' AND BPPENNYAUTOBID_cats_translated.lang='".$USERLANG."' ORDER BY BPPENNYAUTOBID_categories.cat_name");
     while ($line = mysql_fetch_array($result)) {
	     if($catids!="") { $catids .= "<br/>"; }
		 $spaces="";
		 for($i=0;$i<$level;$i++) $spaces .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	     $catids .= "<option value='".$line['cat_id']."' ".($selected==$line['cat_id'] ? " selected ":"").">".$spaces.$line["cat_name"]."</option>";
		 
		 drawCategories($line["cat_id"], $catids,$level+1,$selected);
     }
     return $catids;
}
$catsubids="";
function subCategoriesList($parent_id, $catlistids="") {
global $catsubids;
     $result = mysql_query("SELECT cat_id FROM BPPENNYAUTOBID_categories WHERE parent_id='".$parent_id."' ORDER BY cat_name");
     while ($line = mysql_fetch_array($result)) {
	     if($catsubids!="") { $catsubids .= ", "; }
	     $catsubids .= $line["cat_id"];
		 subCategoriesList($line["cat_id"], $catsubids);
     }
     return $catsubids;
}


include($htmlheader);
?>


<script src="js/ajax.js" type="text/javascript"></script>
<script type="text/javascript">

//added by Shevy May 2010

function updateAutobids()
{
	//var user_id = "<?= $_SESSION["BPPENNYAUTOBID_LOGGED_IN"] ?>";
	//if (user_id!="")
	//{
		abc_runAjax_autobid("autobidProcess.php");//"uid="+user_id
	//}
}	

function processResponseAutobid(txt)
{
	/*if(txt!="")
	{
	alert(txt+"not empty");	
	}*/
	
	var user_id = "<?= $_SESSION["BPPENNYAUTOBID_LOGGED_IN"] ?>";
	var sss1 = txt.split("---");
	if (sss1.length==2) {
		//alert('in'+txt+"stuff");
		var arr_ids = sss1[0].split('___');
		var arr_balance = sss1[1].split('___');
		//alert('in here'+arr_ids);
		for(j = 0; j < numOfElements; j++)
		{
		if (arr_ids[j] == user_id ) {
			document.getElementById("balance").innerHTML=arr_balance[j];
			
		}
		}
	}
}


function processResponseInsertAutobid()
{
	//stam
}

setInterval("updateAutobids()", 1000);

// eof added by Shevy May 2010

</script>