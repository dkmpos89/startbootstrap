<?
require('./includes/config.inc.php');

if(!isset($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]))
{
	Header("Location: user_login.php");
	exit;
}


function add_to_history($amount,$payment_type, $description){
	$query = "INSERT INTO BPPENNYAUTOBID_payments (
			user_id, amount, payment_date, payment_type, description
			) VALUES (
				".intval($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]).",
				".floatval($amount).",
				'".date("Y-m-d h:i:s")."',
				'".$payment_type."',
				'".$description."'					
			)							
		";
	$result = mysql_query($query);									
}


$query = "SELECT			  
			w.auction,
			w.winner,
			w.bid
		  FROM
			BPPENNYAUTOBID_winners w, BPPENNYAUTOBID_auctions a
		  WHERE
			w.auction=a.id AND
			   (a.closed='1' OR a.closed='-1') AND a.suspended=0 AND
			  w.winner='$_SESSION[BPPENNYAUTOBID_LOGGED_IN]'
		  ORDER BY w.closingdate DESC";
$res = @mysql_query($query);
if(!$res)
{
	MySQLError($query);
	exit;
}
else
{
	while($row = mysql_fetch_array($res))
	{
		$query = "SELECT title,ends,sold FROM BPPENNYAUTOBID_auctions WHERE id='$row[auction]'";
		$r = @mysql_query($query);
		if(!$r)
		{
			MySQLError($query);
			exit;
		}
		$AUCTIONS[$row[auction]] = stripslashes(mysql_result($r,0,"title"));
		$AUCTIONS_ENDS[$row[auction]] = stripslashes(mysql_result($r,0,"ends"));
		$sold[$row[auction]]=mysql_result($r,0,"sold");
		
		$BID[$row[auction]] = $row['bid'];
	}
}
$submit_btn=isset($_POST['submit_btn']) ? $_POST['submit_btn'] :"";
$amount=isset($_POST['amount']) ? $_POST['amount'] :"";

require("header.php");

include_once phpa_include("template_buying_php.html");
include_once "./footer.php";

?>
