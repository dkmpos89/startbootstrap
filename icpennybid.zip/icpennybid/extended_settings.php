<?php
require('../includes/config.inc.php');include_once "loggedin.inc.php";


		
         if($_POST["act"]==$MSG_530)
         {
         
			#// Update data				
				$query = "update BPPENNYAUTOBID_settings set					
				aoutobid_step='".$_POST[count]."'";						
				$res = mysql_query($query);
                                //echo $res."+++";
                                if(!$res)
                                {					
					print "Error: $query<BR>".mysql_error();					
					exit;				
				}else
                                {					
					$ERR = $MSG_542;					
					//$SETTINGS = $_POST;				
				}								
		
         }
         $sql1="select * from BPPENNYAUTOBID_settings";
			$res = @mysql_query($sql1);
			
		if(!$res)
		{
			print "Error: $query<BR>".mysql_error();
			exit;
		}
		elseif(mysql_num_rows($res) > 0)
		{
			$SETTINGS = mysql_fetch_array($res);
		}
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666"
	alink="#000066" leftmargin="0" topmargin="0" marginwidth="0"
	marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td background="images/bac_barint.gif">
		<table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr>
				<td width=31><img src="images/i_auc.gif" width="21" height="19"></td>
				<td class=white>AUCTIONS&nbsp;&gt;&gt;&nbsp;extended settings
                                
                                </td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
		<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0
			BGCOLOR="#FFFFFF">
			<TR>
				<TD align="center"><BR>
				<FORM NAME=conf ACTION=<?=basename($_SERVER['SCRIPT_NAME'])?>
					METHOD=POST>
				<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1"
					BGCOLOR="#546f95">
					<TR>
						<TD ALIGN=CENTER class=title>Extended Settings</TD>
					</TR>
					<TR>
						<TD>
						<TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
						<?
						if(isset($ERR))
						{
							?>
							<TR BGCOLOR=yellow>
								<TD COLSPAN="2" ALIGN=CENTER><B> <? print $ERR; ?> </B></TD>
							</TR>
							<?
						}
						?>
							<TR VALIGN="TOP">
								<TD COLSPAN="2"><IMG SRC="../images/transparent.gif" WIDTH="1"
									HEIGHT="5">
                                                                                    <div>
                                                                Here you can set the duration seconds for the frequency every autobid is placed.</div></TD>
							</TR>
							<TR VALIGN="TOP">
								<TD WIDTH=169></TD>
								<TD WIDTH="365"> <BR>
								Seconds &nbsp; &nbsp;<INPUT TYPE="text" NAME="count" SIZE="45" MAXLENGTH="4"
								VALUE="<?=$SETTINGS["Count_Down"]?>">
     
     
    <!-- <br/>	
      Minutes
      <SELECT name='duration_minutes' >
         <OPTION value='00'>0</OPTION>
         <OPTION value='01'>1</OPTION>
         <OPTION value='02'>2</OPTION>
         <OPTION value='03'>3</OPTION>
         <OPTION value='04'>4</OPTION>
         <OPTION value='05'>5</OPTION>
         <OPTION value='06'>6</OPTION>
         <OPTION value='07'>7</OPTION>
         <OPTION value='08'>8</OPTION>
         <OPTION value='09'>9</OPTION>
         <OPTION value='10'>10</OPTION>
         <OPTION value='11'>11</OPTION>
         <OPTION value='12'>12</OPTION>
         <OPTION value='13'>13</OPTION>
         <OPTION value='14'>14</OPTION>
         <OPTION value='15'>15</OPTION>
         <OPTION value='16'>16</OPTION>
         <OPTION value='17'>17</OPTION>
         <OPTION value='18'>18</OPTION>
         <OPTION value='19'>19</OPTION>
         <OPTION value='20'>20</OPTION>
         <OPTION value='21'>21</OPTION>
         <OPTION value='22'>22</OPTION>
         <OPTION value='23'>23</OPTION>
         <OPTION value='12'>24</OPTION>
         <OPTION value='13'>25</OPTION>
         <OPTION value='14'>26</OPTION>
         <OPTION value='15'>27</OPTION>
         <OPTION value='16'>28</OPTION>
         <OPTION value='17'>29</OPTION>
         <OPTION value='18'>30</OPTION>
        
      </SELECT>
      &nbsp;
     Seconds
      <SELECT name='duration_Seconds'>
         <OPTION value='00' selected>00</OPTION>
         <OPTION value='05'>05</OPTION>
         <OPTION value='10'>10</OPTION>
         <OPTION value='15'>15</OPTION>
         <OPTION value='20'>20</OPTION>
         <OPTION value='25'>25</OPTION>
         <OPTION value='30'>30</OPTION>
         <OPTION value='35'>35</OPTION>
         <OPTION value='40'>40</OPTION>
         <OPTION value='45'>45</OPTION>
         <OPTION value='50'>50</OPTION>         
         <OPTION value='55'>55</OPTION>
      </SELECT>-->
                                                                </TD>
							</TR>
							
							
							<TR>
                                                            
								<TD WIDTH=169><INPUT TYPE="submit" NAME="act"
									VALUE="<? print $MSG_530; ?>"></TD>
								<TD WIDTH="365"></TD>
							</TR>
						</TABLE>
						</TD>
					</TR>
				</TABLE>
				</FORM>
				</TD>
			</TR>
		</TABLE>
		</TD>
	</TR>
</TABLE>
</BODY>
</HTML>
