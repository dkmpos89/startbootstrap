<?

require("includes/config.inc.php");

switch($_GET["show"]) {
	case "aboutus":
	$TITLE = $MSG_5074;
	$CONTENT = stripslashes($SETTINGS["about_us"]);
	break;
	case "terms":
	$TITLE = $MSG_5086;
	$CONTENT = stripslashes($SETTINGS["terms_cons"]);
	break;
	case "howitworks":
	$TITLE = $MSG_31_0048;
	$CONTENT = stripslashes($SETTINGS["how_it_works"]);
	break;
        case "faq":
	$TITLE = "FAQ";
	$CONTENT = stripslashes($SETTINGS["faq_page"]);
	break;
}

include_once "header.php";
include_once phpa_include("template_contents_php.html");
include_once "footer.php";
?>

