<?
include_once "./includes/config.inc.php";
#// Run cron according to SETTINGS
if($SETTINGS['cron'] == 2)
{
	include_once "cron.php";
}
include_once $include_path . "auction_types.inc.php";
include_once $include_path . "dates.inc.php";
$TIME = mktime(date("H") + $SETTINGS['timecorrection'], date("i"), date("s"), date("m"), date("d"), date("Y"));
$NOW = date("YmdHis", $TIME);


#// ################################################
#// Is the seller logged in?
if(!isset($_SESSION['BPPENNYAUTOBID_LOGGED_IN']))
{
	$REDIRECT_AFTER_LOGIN = "index.php";
	$_SESSION['REDIRECT_AFTER_LOGIN'] = $REDIRECT_AFTER_LOGIN;
	Header("Location: user_login.php");
	exit();
}



if(!$id) $id = $_REQUEST[id];


if(!$bid) $bid = $_REQUEST[bid];


$auction_type = $_POST['auction_type'];


$type = $_POST['form_type'];


$TPL_id = $id;
/** first check if valid auction ID passed */
$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($id));
// SQL error
if(!$result)
{
	MySQLError($query);
	exit();
}
$Data = mysql_fetch_array($result);
$n = mysql_num_rows($result);
$TPL_title = htmlspecialchars($Data['title']);
$TPL_id_value = $id;
$TPL_auctions_list_value = "";
$query = "select bid,id from BPPENNYAUTOBID_bids where auction=\"" . intval($id) . "\" ORDER BY id DESC";
$result___ = mysql_query($query);
if(mysql_num_rows($result___) > 0)
{
	$ARETHEREBIDS = "<A HREF=\"" . $SETTINGS['siteurl'] . "item.php?id=$id&history=view#history\">$MSG_105</A>";
	$CURRENTBID_ID = mysql_result($result___, 0, "id");
}else
{
	unset($TPL_BIDS_value);
}
# // ###############################
// $ITEM = mysql_fetch_array($result);
// such auction does not exist, so exit
if($n == 0)
{
	include_once ("header.php");
	$TPL_errmsg = $ERR_606;
	include_once (phpa_include("template_bid_php.html"));
	include_once ("footer.php");
	exit();
}


# // ###############################    
# check if the user has enough money on his account
$bid_sum = 0;
//echo "<pre>Data<br>";
//print_r($Data);
//echo "</pre>";
// Retrieve bid value (one bid cost)
if(preg_match("#^(\+?((([0-9]+(\.)?)|([0-9]*\.[0-9]+))([eE][+-]?[0-9]+)?))$#", $Data['bid_value']))
{
	$bid_value = $Data['bid_value'];
}else
	$bid_value = 2;
if($_POST['bid_type'] == 'simple')
{
	$bid_sum = $bid_value;
}
$query = "SELECT id, balance FROM BPPENNYAUTOBID_users WHERE nick='" . addslashes($_SESSION['BPPENNYAUTOBID_LOGGED_IN_USERNAME']) . "'";


//echo "bid_sum = $bid_sum<br>sql: $query";
$result_b = mysql_query($query);
$bal_row = mysql_fetch_array($result_b);
$balance_ = $bal_row['balance'];
$user_id_ = $bal_row['id'];
// the user has not enough money    
if($balance_ < 1)
{
	include_once ("header.php");
	$TPL_errmsg = $ERR_32_0001;
	$bidH = $bid_sum;
	// Show list of bids
	$auction_id = $id;
	include_once ("bid_list.php");
	include_once (phpa_include("template_bid_php.html"));
	include_once ("footer.php");
	exit();
}
$auctiondate = $Data['starts'];
$auctionends = $Data['ends'];
$item_title = $Data["title"];
$item_description = $Data["description"];
// check if auction isn't closed    
$AuctionIsClosed = false;
$closed = intval($Data["closed"]);
$c = $Data["ends"];
if(mktime(substr($c, 8, 2), substr($c, 10, 2), substr($c, 12, 2), substr($c, 4, 2), substr($c, 6, 2), substr($c, 0, 4)) <= $TIME) $AuctionIsClosed = true;
if(($closed == 1) || ($AuctionIsClosed) || ($Data['suspended'] == 1))
{
	include_once ("header.php");
	$TPL_errmsg = $ERR_614;
	// Show list of bids
	$auction_id = $id;
	include_once ("bid_list.php");
	include_once (phpa_include("template_bid_php.html"));
	include_once ("footer.php");
	exit();
}
$insert = "";
// Check if the user pressed F5: if no - processing the bid, if yes - not processing
if($_POST['f5_num'] != $_SESSION['f5_num1'])
{
	// Insert records of each bid (one - if simple, multiple - if 'range')
//	if($_POST['bid_type'] == 'simple')
//	{
//		$insert = "INSERT INTO BPPENNYAUTOBID_bids(auction, bidder, bid, bidwhen)
//               VALUES($id, $user_id_, " . converttonum($_POST['bid']) . ", '$NOW')";
//		

//		mysql_query($insert);
//	}
//	//update user's balance    
//	$balance_ -= 1;
//	$update = "UPDATE BPPENNYAUTOBID_users SET balance=$balance_
//                  WHERE nick LIKE '" . addslashes($_SESSION['BPPENNYAUTOBID_LOGGED_IN_USERNAME']) . "' AND id=$user_id_";
//	mysql_query($update);

do_bid($id,$user_id_,$_POST['bid']);

//autobidProcessing($id);
	// Save current F5 control number for next check
	$_SESSION['f5_num1'] = $_POST['f5_num'];
}



/**
 * NOTE: AUCTION AUTOEXTENSION
 */

$EXTSETTINGS = @mysql_fetch_array(@mysql_query("SELECT * FROM BPPENNYAUTOBID_auctionextension"));

if($EXTSETTINGS['status'] == 'enabled')

{

	$__END = mktime(substr($auctionends, 8, 2), substr($auctionends, 10, 2), substr($auctionends, 12, 2), substr($auctionends, 4, 2), substr($auctionends, 6, 2), substr($auctionends, 0, 4));

	if(($__END - $TIME) <= $EXTSETTINGS['timebefore'])

	{

		$auctionends = date("YmdHis", mktime(substr($auctionends, 8, 2), substr($auctionends, 10, 2), substr($auctionends, 12, 2) + $EXTSETTINGS['extend'], substr($auctionends, 4, 2), substr($auctionends, 6, 2), substr($auctionends, 0, 4)));

	}

	$query = "UPDATE BPPENNYAUTOBID_auctions set ends='$auctionends' WHERE id=" . intval($id);

	if(!mysql_query($query))

	{

		MySQLError($query);

		exit();

	}

}

        
// Generate new F5 control number
$f5_num = getRandomInt(20);
// Check for winner - find maximum bid
$check = "SELECT bid, bidder, COUNT(bid) AS bid_count
              FROM BPPENNYAUTOBID_bids
              WHERE auction=$id GROUP BY bid ORDER BY bid DESC ";
$check_result = mysql_query($check);
$winner_bid = 0;
$winner_bid_count = 0;
$winner_id = 0;
if($check_row = mysql_fetch_array($check_result))
{
	$winner_bid = $check_row['bid'];
	$winner_bid_count = $check_row['bid_count'];
	if($winner_bid_count == 1) $winner_id = $check_row['bidder'];
}
// Find the current winner of the auction


while($check_row = mysql_fetch_array($check_result))
{
	// Find out if the bid is unique        


	if($check_row['bid_count'] == 1)
	{
		// If this unique bid is the highest - it is a winner


		if($check_row['bid'] > $winner_bid)
		{
			$winner_id = $check_row['bidder'];
			$winner_bid = $check_row['bid'];
		}
	}
}
$MSG_WINNER = "";
$is_winner = false;
if($winner_id == $_SESSION['BPPENNYAUTOBID_LOGGED_IN'])
{
	$is_winner = true; // Current user is the winner
}
// Show message about current bid if it's winner bid, its state etc...
switch($_POST['bid_type'])
{
	case "simple":
		$result3 = mysql_query($check);
		$is_unique = false;
		while($row3 = mysql_fetch_array($result3))
		{
			if($row3['bid_count'] == 1 && $row3['bid'] == $_POST['bid'])
			{
				$is_unique = true;
				break;
			}
		}
		if($_POST['bid'] == $winner_bid && $is_winner)
		{ //This bid is winner
		$MSG_WINNER = $MSG_31_0053;
		}else
		{
			if($is_unique == true)
			{
				$MSG_WINNER = $MSG_31_0054;
				if($is_winner == true)
				{
					$MSG_WINNER .= str_replace("<winner_bid>", $winner_bid, $MSG_31_0057);
				}
			}else
			{
				$MSG_WINNER = $MSG_31_0055;
				if($is_winner == true)
				{
					$MSG_WINNER .= str_replace("<winner_bid>", $winner_bid, $MSG_31_0057);
				}
			}
		}
		break;
	default:
	break;
}


#########################  Next Bid    #########################################################
//$query = "select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($id) . " GROUP BY auction, bidder ORDER BY maxbid DESC";
//

//$result_bids = mysql_query($query);
//$customincrement = mysql_result($result, 0, "increment");
//$max_bid = mysql_result($result_bids, 0, "maxbid");
//

////echo '$max_bid='.$max_bid;
//$minimum_bid = mysql_result($result, 0, "minimum_bid");
//if($max_bid == 0)
//{
//	$MAX_BID = $minimum_bid;
//	//// Added by Yosi 22 Jul 2009 - consider if auction starts with some value
//	$max_bid = $minimum_bid;
//}else
//{
//	$MAX_BID = $max_bid;
//}
///* Get bid increment for current bid and calculate minimum bid */
//

//$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";
//

////echo "<div style='display:none;'>sql:<br>";
////echo "$query</div>";
//

//$result_incr = mysql_query($query);
//if(mysql_num_rows($result_incr) != 0)
//{
//	$increment = mysql_result($result_incr, 0, "increment");
//}
//if($customincrement > 0)
//{	
//	$increment = $customincrement;
//}
//if($max_bid == 0 || $atype == 2)
//{
//	$next_bid = $minimum_bid;
//}else
//{	
//	$next_bid = $max_bid + $increment;
//}
//$TPL_next_bid_value = $next_bid;

$TPL_next_bid_value = get_next_bid($id);
##################################################################
//if($is_winner==false){
//   $MSG_WINNER .= $MSG_31_0056;
//}
$auction_type = $_POST['auction_type'];
$type = $_POST['form_type'];
$TPL_id = $id;
// Show list of bids
$auction_id = $id;

header("Location: item.php?id=".$id."&history=view#history");

//
//include_once ("bid_list.php");
//include_once "header.php";
//include_once phpa_include("template_bid_result_php.html");
//include_once "footer.php";
//exit();


function get_HOW_MANY($auction_id)

{

	$how_many = "&nbsp;";

	if(isset($_SESSION["BPPENNYAUTOBID_LOGGED_IN"]))

	{

		$sql = "SELECT asi.offers

                FROM BPPENNYAUTOBID_auctions_signed asi

                INNER JOIN BPPENNYAUTOBID_auctions a ON asi.auction_id=a.id

                WHERE asi.user_id=" . $_SESSION["BPPENNYAUTOBID_LOGGED_IN"] . " AND

                   asi.auction_id=" . $auction_id . " AND a.auction_type>1";

		$res = mysql_query($sql);

		if($res)

		{

			if(mysql_num_rows($res) > 0)

			{

				$row1 = mysql_fetch_array($res);

				$how_many = "Your number of offers available for this auction are: " . $row1['offers'];

			}

		}

	}

	return $how_many;

}


//--------------------------------------------------------------------------
// gets random integer
//--------------------------------------------------------------------------
function getRandomInt($length = 20)
{
	$template = "1234567890abcdefghijklmnopqrstuvwxyz";
	//$template = "1234567890";
	settype($template, "string");
	settype($length, "integer");
	settype($rndstring, "string");
	settype($a, "integer");
	settype($b, "integer");
	for($a = 0; $a <= $length; $a++)
	{
		$b = rand(0, strlen($template) - 1);
		$rndstring .= $template[$b];
	}
	return $rndstring;
}
function get_next_bid($auction_id) {

	

	if (intval($auction_id)>0) {

		$result = mysql_query("SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=" . intval($auction_id));

		$result_bids = mysql_query("select max(bid) AS maxbid, bidder FROM BPPENNYAUTOBID_bids WHERE auction=" . intval($auction_id) . " GROUP BY auction, bidder ORDER BY maxbid DESC");



		$customincrement = mysql_result($result, 0, "increment");

		$max_bid = mysql_result($result_bids, 0, "maxbid");

		$minimum_bid = mysql_result($result, 0, "minimum_bid");

		if($max_bid == 0) {

			$MAX_BID = $minimum_bid;

			//// Added by Yosi 22 Jul 2009 - consider if auction starts with some value

			$max_bid = $minimum_bid;

		}else

		{

			$MAX_BID = $max_bid;

		}

		/* Get bid increment for current bid and calculate minimum bid */

		

		$query = "SELECT increment FROM BPPENNYAUTOBID_increments WHERE " . "((low <= $MAX_BID AND high >= $MAX_BID) OR " . "(low < $MAX_BID AND high < $MAX_BID)) ORDER BY increment DESC";

		

		//echo "<div style='display:none;'>sql:<br>";

		//echo "$query</div>";

		

		$result_incr = mysql_query($query);

		if(mysql_num_rows($result_incr) != 0)

		{

			$increment = mysql_result($result_incr, 0, "increment");

		}

		if($customincrement > 0)

		{	

			$increment = $customincrement;

		}

		

		if($max_bid == 0 || $atype == 2)

		{

			$next_bid = $minimum_bid;

		}else

		{	

			$next_bid = $max_bid + $increment;

		}

		return $next_bid;

	} else {

		return 0;

	}

}



function autobidProcessing($auction_id=0) {

	if (intval($auction_id)>0) {

		//do {

			$sql="SELECT

					BPPENNYAUTOBID_autobids.id,

					BPPENNYAUTOBID_autobids.bidder_id,

					BPPENNYAUTOBID_autobids.remained_bids,

					BPPENNYAUTOBID_autobids.max_amount,

					BPPENNYAUTOBID_users.balance

				FROM BPPENNYAUTOBID_autobids

				INNER JOIN BPPENNYAUTOBID_users ON BPPENNYAUTOBID_autobids.bidder_id=BPPENNYAUTOBID_users.id

				WHERE

					BPPENNYAUTOBID_autobids.auction_id='".$auction_id."'";

			$result=mysql_query($sql);

			//$return_flag=false;

			$bid_flag=false;

			while($row=mysql_fetch_array($result)) {

				if ($row['remained_bids']>0 && $row['max_amount']>get_next_bid($auction_id)) {

					if ($row['bidder_id']!=get_current_bidder_id($auction_id)) {

						if (do_bid($auction_id,$row['bidder_id'],get_next_bid($auction_id))) {

							mysql_query("UPDATE BPPENNYAUTOBID_autobids SET remained_bids=remained_bids-1 WHERE id='".$row['id']."'");

							$bid_flag=true;

						}

					}

				}

			}

		//} while ($bid_flag);

	}

}





function do_bid($auction_id,$user_id,$bid_value) {

	global $NOW;

	

	

	if (intval($auction_id)>0 && intval($user_id)>0 && $bid_value>0) {

		

		$result_b = mysql_query("SELECT id, balance FROM BPPENNYAUTOBID_users WHERE id='" .$user_id. "'");

		$bal_row = mysql_fetch_array($result_b);

		$balance = $bal_row['balance'];

		

		$sql="SELECT ends,bid_value,closed,w_seat FROM BPPENNYAUTOBID_auctions WHERE id='".$auction_id."'";

        $result1=mysql_query($sql);

        $ends = mysql_result($result1, 0, "ends");

		$closed = mysql_result($result1, 0, "closed");

		$w_seat=mysql_result($result1, 0, "w_seat");
		

		if ($closed==0) {	

			if (($balance>0 && $w_seat==1)||($w_seat==2)) {
				if ((strtotime($ends)-strtotime($NOW)>=0) && (strtotime($ends)-strtotime($NOW)<=$GLOBALS['SETTINGS']['extension_time'])) {
					//$new_ends=date("YmdHis",strtotime($NOW)+32);
					//mysql_query("UPDATE BPPENNYAUTOBID_auctions SET jump30=1 WHERE id='".$auction_id."'");
					//echo "UPDATE auctions SET ends='".$new_ends."' WHERE auction_id='".$auction_id."'";
					$new_ends=date("YmdHis",strtotime($ends)+$GLOBALS['SETTINGS']['extension_time']-(strtotime($ends)-strtotime($NOW))+1);
					mysql_query("UPDATE BPPENNYAUTOBID_auctions SET ends='".$new_ends."', jump30=0 WHERE id='".$auction_id."'");
					
				}
				if (strtotime($ends)-strtotime($NOW)>=0) {
					$insert = "INSERT INTO BPPENNYAUTOBID_bids(auction, bidder, bid, bidwhen)

							   VALUES('" .$auction_id. "','" .$user_id. "','" .converttonum(get_next_bid($auction_id)). "','" .$NOW. "')";

						

					

					mysql_query($insert);

					

	

					if ($w_seat==1) {

						$balance -= 1;

						$update = "UPDATE BPPENNYAUTOBID_users SET balance=".$balance."

									  WHERE id=".$user_id;

						

						mysql_query($update);
					}
					return true;
				} else {
					return false;
				}

			} else {

				return false;	

			}

		} else {

			return false;

		}

	} else {

		return false;

	}

}



function converttonum($convertnum){

	$bits = explode(",",$convertnum); // split input value up to allow checking

   

	$first = strlen($bits[0]); // gets part before first comma (thousands/millions)

	$last = strlen($bits[1]); // gets part after first comma (thousands (or decimals if incorrectly used by user)

   

	if ($last <3){ // checks for comma being used as decimal place

		$convertnum = str_replace(",",".",$convertnum);

	}

	else{ // assume comma is a thousands seperator, so remove it

		$convertnum = str_replace(",","",$convertnum);

	}

   

	return $convertnum; 

} 



function get_current_bidder_id($auction_id) {

	$sql = "SELECT bid, bidder, COUNT(bid) AS bid_count

              FROM BPPENNYAUTOBID_bids

              WHERE auction=".$auction_id." GROUP BY bid ORDER BY bid DESC ";

	$result = mysql_query($sql);

	if ($row1=mysql_fetch_array($result)) {

		return $row1['bidder'];

	} else {

		return 0;

	}

}


?>