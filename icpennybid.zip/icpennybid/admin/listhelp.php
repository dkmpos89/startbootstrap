<?#//v.3.0.0

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";

//-- Set offset and limit for pagination

$limit = 20;
if(!$offset) $offset = 0;

include_once "./header.php";

if ($act == "delete") {
	$query = "DELETE FROM BPPENNYAUTOBID_help WHERE topic = '" . $topic . "';";
	$result = mysql_query($query);
	if(!$result){
		print "$ERR_001<BR>$query<BR>".mysql_error();
		include_once "./footer.php";
		exit;
	}
}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<BODY>
<BR>
<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#296FAB" ALIGN="CENTER">
			<TR>
				<TD ALIGN=CENTER class=title>
					<? print $MSG_912; ?>
				</TD>
			</TR>
			<TR>
				<TD>
					<TABLE WIDTH=650 CELLPADDING=3 CELLSPACING=1 BORDER=0 ALIGN="CENTER">
						<?
						$query = "select count(topic) as topics from BPPENNYAUTOBID_help";
						$result = mysql_query($query);
						if(!$result){
							print "$ERR_001<BR>$query<BR>".mysql_error();
							exit;
						}
						if (mysql_num_rows($result)) {
							$num_usrs = mysql_result($result,0,"topics");
						} else {
							$num_usrs = 0;
						}
						print "<TR BGCOLOR=#FFFFFF><TD COLSPAN=3><B>
				$num_usrs $MSG_913</B></TD></TR>";?>
						<TR BGCOLOR="#999999">
							<TD ALIGN=CENTER> <FONT COLOR="#FFFFFF">
								<B>
								<? print $MSG_914; ?>
								</B>  </TD>
							<TD ALIGN=CENTER> <FONT COLOR="#FFFFFF">
								<B>
								<? print $MSG_915; ?>
								</B>  </TD>
							<TD ALIGN=LEFT> <FONT COLOR="#FFFFFF">
								<B>
								<? print $MSG_297; ?>
								</B>  </TD>
						<TR>
<?
$query = "select topic,helptext from BPPENNYAUTOBID_help order by topic limit $offset, $limit";
$result = mysql_query($query);
if(!$result){
	print "Database access error: abnormal termination<BR>$query<BR>".mysql_error();
	exit;
}
$num_topics = mysql_num_rows($result);
$i = 0;
$bgcolor = "#FFFFFF";
while($i < $num_topics){
	
	if($bgcolor == "#FFFFFF"){
		$bgcolor = "#EEEEEE";
	}else{
		$bgcolor = "#FFFFFF";
	}
	
	$topic = stripslashes(mysql_result($result,$i,"topic"));
	$helptext = stripslashes(mysql_result($result,$i,"helptext"));
	
	print "<TR BGCOLOR=$bgcolor>
					<TD>
						$topic
						</TD>
						<TD>
						$helptext
						</TD>
						<TD ALIGN=LEFT>
						<A HREF=\"addhelp.php?act=edit&topic=".urlencode($topic)."&offset=$offset\" class=\"nounderlined\">$MSG_298</A><BR>
						<A HREF=\"listhelp.php?act=delete&topic=".urlencode($topic)."&offset=$offset\" class=\"nounderlined\">$MSG_299</A><BR>
						<TR>";
	
	$i++;
}
print "<TR BGCOLOR=#FFFFFF><TD COLSPAN=3><BR><CENTER><A HREF=\"addhelp.php\">$MSG_917</A></CENTER><BR>";
print "</TABLE>
			   </TD></TR></TABLE>";



//-- Build navigation line
print "<TABLE WIDTH=600 BORDER=0 CELLPADDING=4 CELLSPACING=0 ALIGN=CENTER>
			   <TR ALIGN=CENTER BGCOLOR=#FFFFFF>
			   <TD COLSPAN=2>";

print "<SPAN CLASS=\"navigation\">";
$num_pages = ceil($num_topics / $limit);
$i = 0;
while($i < $num_pages ){
	
	$of = ($i * $limit);
	
	if($of != $offset){
		print "<A HREF=\"listhelp.php?offset=$of\" CLASS=\"navigation\">".($i + 1)."</A>";
		if($i != $num_pages) print " | ";
	}else{
		print $i + 1;
		if($i != $num_pages) print " | ";
	}
	
	$i++;
}
print "</SPAN></TR></TABLE>";



	  ?>
	  	<TR BGCOLOR=#FFFFFF ALIGN=CENTER>
	  	<TD>
		<BR>
		<BR>
		<CENTER>
			<A HREF="admin.php" CLASS="links">Admin Home</A>
		</CENTER>
		<BR>
		</TD>
		</TR>
		</TABLE></TABLE>
