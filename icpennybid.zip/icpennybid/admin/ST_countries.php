<?#//v.3.0.0

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
include $include_path."domains.inc.php";

?>
<HTML>
<HEAD>
<TITLE>Untitled Document</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<STYLE type="text/css">
<!--
.bluelink {  font: 10pt Verdana, Arial, Helvetica, sans-serif; color: 000066; text-decoration: none}
-->
</STYLE></HEAD>

<BODY bgcolor="#FFFFFF">
<CENTER>
  <P><B>
  <FONT face="Verdana, Arial, Helvetica, sans-serif" size="4" color="#000066">
  <?=$MSG_5157?></FONT></B> </P>
   <P align="center"><A href="javascript:window.close()" class="bluelink">Close</A></P>

  <TABLE width="352" border="0" cellspacing="0" cellpadding="0">
      <?
	  	while(list($k,$v) = each($DOMAINS))
		{
	  ?>
    	<TR>
    	  <TD WIDTH=10%>
		  <FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">
		  <?=$k?>
		  </TD>
		  <TD>
		  <FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">
		  <?=$v?>
		  </TR>
		<?
		}
	   ?>
      </TD>
    </TR>
  </TABLE>
  </CENTER>
 <P align="center"><A href="javascript:window.close()" class="bluelink">Close</A></P>

</BODY>
</HTML>
