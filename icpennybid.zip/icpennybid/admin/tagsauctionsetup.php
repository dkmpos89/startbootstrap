<?#//v.3.0.0

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

	include_once "../includes/config.inc.php";
	include_once $include_path."tags.inc.php";
?>
<HTML>
<HEAD>
<TITLE><? print $SETTINGS[sitename]?></TITLE>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>

<BODY bgcolor="#FFFFFF">
<CENTER>
  <P><B>
  	<FONT face="Verdana, Arial, Helvetica, sans-serif" size="4" color="#000066">
	<?=$MSG_5388?></B> </P>
        <CENTER>
          <P align="center"><A href="javascript:window.close()"><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">Close</A></P>
        </CENTER>

  <TABLE width="100%" border="0" cellspacing="0" cellpadding="0">
    <TR>
      <TD>
        <P><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">
		  <?=$MSG_5392?>
          </P>
        <table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor=#dddddd>
          <tr bgcolor="#eeeeee">
            <td width="13%">
              <div align="center">
			  	<FONT FACE="Verdana,Helvetica,Arial" SIZE=2><B><?=$MSG_5389?></B>
			</div>
            </td>
            <td width="87%">
              <div align="center">
			  	<FONT FACE="Verdana,Helvetica,Arial" SIZE=2><B><?=$MSG_5390?></B>
			  </div>
            </td>
          </tr>
		  <?
		  	reset($AUCTION_CONFIRMATION);
			while(list($k,$v) = each($AUCTION_CONFIRMATION))
			{
		  ?>
          <tr VALIGN=TOP BGCOLOR=#ffffff>
            <td width="13%">
			  <FONT FACE="Verdana,Helvetica,Arial" SIZE=2><?=$k?>
            </td>
            <td width="87%">
			  <FONT FACE="Verdana,Helvetica,Arial" SIZE=2><?=$v?>
			</td>
          </tr>
		<?
			}
		?>
        </table>
        <P><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2"> </P>
        <CENTER>
          <P align="center"><A href="javascript:window.close()"><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">Close</A></P>
        </CENTER>
        </TD>
    </TR>
  </TABLE>
  </CENTER>
</BODY>
</HTML>
