<?#//v.3.2.1
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
require('../includes/config.inc.php');
include_once "loggedin.inc.php";
//-- Set offset and limit for pagination
$limit = 30;
if(!$_GET[offset]) {
  $offset = 0;
} else {
  $offset = $_GET[offset];
}
$PAGES = ceil($TOTALUSERS / $limit);
#// Set return script name
$_SESSION['RETURN_LIST'] = 'listclosedauctions.php';
$_SESSION['RETURN_LIST_OFFSET'] = intval($_GET['offset']);


?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_auc.gif" ></td>
          <td class=white><?=$MSG_239?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_5226?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95" ALIGN="CENTER">
<TR>
  <TD ALIGN=CENTER class=title><? print $MSG_5226; ?></TD>
</TR>
<TR>
  <TD><TABLE WIDTH=100% CELPADDING=0 CELLSPACING=1 BORDER=0 ALIGN="CENTER" CELLPADDING="3">
      <?
		//$query = "SELECT 
		//		FROM BPPENNYAUTOBID_auctions a
		//		  INNER JOIN BPPENNYAUTOBID_winners w ON a.id = w.winner
		//		WHERE
		//			(auction_type='1' AND closed='1') OR
		//			((auction_type='2' OR auction_type='3') AND (closed = '2'))
		//		ORDER BY ends DESC limit $offset, $limit";
	        
            $query = "SELECT 
				a.bid, a.winner, a.closingdate, a.bid, 
				b.title, b.id, b.pict_url,
				c.nick
			
			FROM BPPENNYAUTOBID_auctions b
			    LEFT OUTER JOIN BPPENNYAUTOBID_winners a ON a.auction = b.id
				LEFT OUTER JOIN BPPENNYAUTOBID_users c ON a.winner = c.id
			WHERE
					(b.auction_type='1' AND b.closed='1') OR
					((b.auction_type='2' OR b.auction_type='3') AND (b.closed = '2'))
			ORDER BY a.closingdate DESC limit $offset, $limit";
			  
      $result = mysql_query($query);
      if(!$result){
      	print "$ERR_001<BR>$query<BR>".mysql_error();
      	exit;
      }
      $num_auctions = mysql_num_rows($result);
      print "<TR BGCOLOR=#FFFFFF><TD COLSPAN=7><B>
				$num_auctions $MSG_311</B> 
				</TD></TR>";
	?>
      <TR BGCOLOR="#FFCC00">
        <TD ALIGN=CENTER> <B> <? print $MSG_312; ?> </B>  </TD>
        <TD ALIGN=CENTER> <B> <? print $MSG_313; ?> </B>  </TD>
        <TD ALIGN=CENTER> <B> <? print $MSG_314; ?> </B>  </TD>
        <TD ALIGN=LEFT> <B> <? print $MSG_317; ?> </B>  </TD>
        <TD ALIGN=LEFT> <B> <? print $MSG_297; ?> </B>  </TD>
      </tr>
        <?
					//BPPENNYAUTOBID_users u,
					//BPPENNYAUTOBID_categories c,
					//BPPENNYAUTOBID_durations d

			//$query = "SELECT
			//	  a.id, a.closed, a.title, a.starts, a.description, a.suspended, 
			//	  d.description as duration,				  
			//	  u.nick as nick
			//	FROM BPPENNYAUTOBID_auctions a
			//	  INNER JOIN BPPENNYAUTOBID_durations d  ON a.duration = d.days
			//	  INNER JOIN BPPENNYAUTOBID_winners w ON a.id = w.winner
			//	  INNER JOIN BPPENNYAUTOBID_users u ON w.winner = u.id
			//	WHERE
			//		(auction_type='1' AND closed='1') OR
			//		((auction_type='2' OR auction_type='3') AND (closed = '2'))
			//	ORDER BY ends DESC limit $offset, $limit";
                
            $query = "SELECT 
				a.bid, a.winner, a.closingdate, a.bid, 
				b.title, b.id, b.pict_url, b.closed, b.starts, b.description, b.suspended, 
				c.nick
			FROM BPPENNYAUTOBID_auctions b
			    LEFT OUTER JOIN BPPENNYAUTOBID_winners a ON a.auction = b.id
				LEFT OUTER JOIN BPPENNYAUTOBID_users c ON a.winner = c.id
			WHERE
					(b.auction_type='1' AND b.closed='1') OR
					((b.auction_type='2' OR b.auction_type='3') AND (b.closed = '2'))
			ORDER BY a.closingdate DESC limit $offset, $limit";
                
                
					$result = mysql_query($query);
					if(!$result){
						print "Database access error: abnormal termination<BR>$query<BR>".mysql_error();
						exit;
					}
					$num_auction = mysql_num_rows($result);
					$i = 0;
					$bgcolor = "#FFFFFF";
					while($i < $num_auction) {
						if($bgcolor == "#FFFFFF"){
							$bgcolor = "#EEEEEE";
						}else{
							$bgcolor = "#FFFFFF";
						}
						$id = mysql_result($result,$i,"id");
						
						#// ============================== Added on May 26, 2003 ========================================
						$query = "SELECT id FROM BPPENNYAUTOBID_winners WHERE auction='$id'";
						$res_w = @mysql_query($query);
						if(!$res_w) {
							print "$query<BR>".mysql_error();
							exit;
						} elseif(@mysql_num_rows($res_w) > 0) {
							$HASWINNERS = TRUE;
						} else {
							$HASWINNERS = FALSE;
						}
						#// =============================================================================================
						
						$title = stripslashes(mysql_result($result,$i,"title"));
						$nick = mysql_result($result,$i,"nick");
						$tmp_date = mysql_result($result,$i,"starts");
						//$duration = mysql_result($result,$i,"duration");
						//$category = mysql_result($result,$i,"cat_name");
						$description = strip_tags(stripslashes(mysql_result($result,$i,"description")));
						$suspended = mysql_result($result,$i,"suspended");
						$day = substr($tmp_date,6,2);
						$month = substr($tmp_date,4,2);
						$year = substr($tmp_date,0,4);
						$date = "$day/$month/$year";
						
						print "<TR BGCOLOR=$bgcolor>
					<TD>";
						if($suspended == 1) {
							print "<FONT COLOR=red><B>$title</B>";
						} else {
							print $title;
						}
						print "
						</TD>
						<TD>
						".$nick."
						
						</TD>
						<TD>
						".$date."
						
						</TD>
						<TD>
						$description
						
						</TD>
						<TD ALIGN=LEFT>
						<A HREF=\"editauction.php?id=$id&offset=$offset\" class=\"nounderlined\">$MSG_298</A><BR>
						<A HREF=\"deleteauction.php?id=$id&offset=$offset\" class=\"nounderlined\">$MSG_299</A><BR>
						<BR>
						</TD>
						<TR>";
						$i++;
					}
					
/*						<A HREF=\"excludeauction.php?id=$id&offset=$offset\" class=\"nounderlined\">";
						if($suspended == 0) {
							print $MSG_300;
						} else {
							print $MSG_310;
						}
						if($HASWINNERS) {
							print "<BR><A HREF=\"viewwinners.php?id=$id&offset=$offset\" class=\"nounderlined\">$MSG__0163</A>";
						}
						print "</A>*/				
					?>
					</TABLE>
					<?
					//-- Build navigation line
					print "<TABLE WIDTH=100% BORDER=0 CELLPADDING=4 CELLSPACING=0 ALIGN=CENTER>
			   <TR ALIGN=CENTER BGCOLOR=#FFFFFF>
			   <TD COLSPAN=2>";
					print "<SPAN CLASS=\"navigation\">";
					$num_pages = ceil($num_auctions / $limit);
					$i = 0;
					while($i < $num_pages ){
						$of = ($i * $limit);
						if($of != $offset){
							print "<A HREF=\"listclosedauctions.php?offset=$of\" CLASS=\"navigation\">".($i + 1)."</A>";
							if($i != $num_pages) print " | ";
						}else{
							print $i + 1;
							if($i != $num_pages) print " | ";
						}
						$i++;
					}
					print "</SPAN></TR></TD></table>";
					
	  ?>
    </td></tr>
	</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>