<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";

#//
$ERR = "";

#//
if($_POST[action] == "update" && basename($HTTP_REFERER) == basename($PHP_SELF))
{
	$query = " UPDATE BPPENNYAUTOBID_settings SET
				   usersauth='".addslashes($_POST['usersauth'])."'";
	$res_ = @mysql_query($query);
	if(!$res_)
	{
		print "Error: $query<BR>".mysql_error();
		exit;
	}
	else
	{
		$SETTINGS['usersauth'] = $_POST['usersauth'];
		$ERR = $MSG_25_0155;
	}
}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_gra.gif" width="19" height="19"></td>
          <td class=white><?=$MSG_25_0008?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_25_0151?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD align="center">
<BR>
<FORM NAME=conf ACTION="<?=basename($PHP_SELF)?>" METHOD="POST"  ENCTYPE="multipart/form-data">
	<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95">
		<TR>
			<TD ALIGN=CENTER class=title>
				<? print $MSG_25_0151; ?>
				</TD>
		</TR>
		<TR>
	<TD>
		<TABLE WIDTH=100% CELLPADDING=4 ALIGN="CENTER" BGCOLOR="#FFFFFF">
		  <?
		  if($ERR != "")
		  {
		?>
		  <TR>
			<TD COLSPAN="2" ALIGN=CENTER bgcolor="yellow"><B>
			  <? print $ERR; ?>
			  </B></TD>
		  </TR>
		  <?
		  }
		?>
		  <tr valign="TOP">
			<td colspan="2"><img src="../images/transparent.gif" width="1" height="5"></td>
		  </tr>

		  <tr valign="TOP">
			<td width="100%"> 
			  <? print $MSG_25_0152; ?>
			  <br><br>
			  &nbsp;&nbsp;<input type="radio" name="usersauth" value="y"
					 <? if($SETTINGS['usersauth'] == 'y') print " CHECKED";?>
					 >
			  
			  <? print $MSG_25_0153; ?>
			  
			  <BR>
			  &nbsp;&nbsp;<input type="radio" name="usersauth" value="n"
					 <? if($SETTINGS['usersauth'] == 'n') print " CHECKED";?>
					 >
			  
			  <? print $MSG_25_0154; ?>
			   </td>
		  </tr>
		  <TR>
			<TD WIDTH="100%">
			<BR>
			  <INPUT TYPE="hidden" NAME="action" VALUE="update">
			  <INPUT TYPE="submit" NAME="act" VALUE="<? print $MSG_530; ?>">
			</TD>
		  </TR>
		  <TR>
			<TD WIDTH="100%"> </TD>
		  </TR>
		</TABLE>
	</TD>
	</TR>
	</TABLE>
	</FORM>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>