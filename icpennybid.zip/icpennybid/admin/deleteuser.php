<?#//v.3.1.2

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once $include_path."countries.inc.php";

$username = $name;
$id = intval($_REQUEST['id']);

//-- Data check
if(!$_REQUEST[id]) {
	header("Location: listusers.php");
	exit;
}

if($_POST['action'] && strstr(basename($_SERVER['HTTP_REFERER']),basename($_SERVER['PHP_SELF']))) {
	$ERR_CODE = 1;
	
	//-- Check if the users has some auction
	$query = "select * from BPPENNYAUTOBID_auctions where user='$id'";
	
	$result = mysql_query($query);
	if(!$result) {
		print "Database access error: abnormal termination".mysql_error();
		exit;
	}
	
	$num_auctions = mysql_num_rows($result);
	if($num_auctions > 0) {
		
		$ERR = "The user is the SELLER in the following auctions:<BR>";
		$i =  0;
		while($i < $num_auctions) {
			$ERR_CODE=2;
			$ERR .= mysql_result($result,$i,"id")."<BR>";
			$i++;
		}
	}
	
	//-- Check if the user is BIDDER in some auction
	$query = "select * from BPPENNYAUTOBID_bids where bidder='$id'";
	$result = mysql_query($query);
	if(!$result) {
		print "Database access error: abnormal termination".mysql_error();
		exit;
	}
	
	$num_auctions = mysql_num_rows($result);
	if($num_auctions > 0) {
		$ERR_CODE=1;
		$ERR = "The user placed a bid in the following auctions:<BR>";
		$i =  0;
		while($i < $num_auctions){
			$ERR .= mysql_result($result,$i,"bidder")."<BR>";
			$i++;
		}
	}
	
	//-- check if user is suspended or not
	$suspend = mysql_query("select suspended from BPPENNYAUTOBID_users where id=\"$id\"");
	if(!$suspend){
		print "Database access error: abnormal termination".mysql_error();
		exit;
	}
	$myrow=mysql_fetch_array($suspend);
	$suspended = $myrow['suspended'];
	        	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
				$ERR = $ERR_9999;

			}else{
	if($ERR_CODE==1) {
		//-- delete user
		$sql="delete from BPPENNYAUTOBID_users WHERE id='$id'";
		$res=mysql_query ($sql);
		//-- delete user bids
		$decremsql = mysql_query("select * FROM BPPENNYAUTOBID_bids WHERE bidder='$id'");
		$bid_decrem = mysql_num_rows($decremsql);
		$sql="delete from BPPENNYAUTOBID_bids WHERE bidder='$id'";
		$res=mysql_query ($sql);
		//-- delete user's auctions
		$decremsql = mysql_query("select * FROM BPPENNYAUTOBID_auctions WHERE user='$id'");
		$row=mysql_fetch_array($decremsql);
		// update "categories" table - for counters
		$cat_id = $row["category"];
		$root_cat = $cat_id;
		do {
			$query = "SELECT * FROM BPPENNYAUTOBID_categories WHERE cat_id=\"$cat_id\"";
			$result = mysql_query($query);
			if ( $result ) {
				if ( mysql_num_rows($result)>0 ) {
					$R_parent_id = mysql_result($result,0,"parent_id");
					$R_cat_id = mysql_result($result,0,"cat_id");
					$R_counter = intval(mysql_result($result,0,"counter"));
					$R_sub_counter = intval(mysql_result($result,0,"sub_counter"));
					
					$R_sub_counter--;
					if ( $cat_id == $root_cat )
					--$R_counter;
					
					if($R_counter < 0) $R_counter = 0;
					if($R_sub_counter < 0) $R_sub_counter = 0;
					
					$query = "UPDATE BPPENNYAUTOBID_categories SET counter='$R_counter', sub_counter='$R_sub_counter' WHERE cat_id=\"$cat_id\"";
					if ( !mysql_query($query) )	errorLogSQL();
					
					$cat_id = $R_parent_id;
				}
			}
		} while ($cat_id!=0);
		
		$auction_decrem = mysql_num_rows($decremsql);
		$sql = "delete from BPPENNYAUTOBID_auctions WHERE user='$id'";
		$res=mysql_query ($sql);
		
		//-- Update counters
		if ($suspended == 0) {
			$query = mysql_query("update BPPENNYAUTOBID_counters set users=(users-1), bids=(bids-$bid_decrem), auctions=(auctions-$auction_decrem)");
		} else if ($suspended == 1) {
			$query = mysql_query("update BPPENNYAUTOBID_counters set users=(users-1), inactiveusers=(inactiveusers-1), bids=(bids-$bid_decrem), auctions=(auctions-$auction_decrem)");
		}
		$URL = $_SESSION["RETURN_LIST"]."?PAGE=".$_SESSION['RETURN_LIST_PAGE'];
		unset($_SESSION["RETURN_LIST"]);
		header("Location: $URL");
		exit;
	}
	if($ERR_CODE==2) {
		//-- delete user
		$sql="delete from BPPENNYAUTOBID_users WHERE id='$id'";
		$res=mysql_query ($sql);
		$suspended = mysql_result ( $res, 0, "suspended" );
		//-- delete user auctions
		$sql="delete from BPPENNYAUTOBID_auctions WHERE user='$id'";
		$res=mysql_query ($sql);
		//-- Update counters
		if ($suspended==0){
			$query = mysql_query("update BPPENNYAUTOBID_counters set users=(users-1)");
		} else if ($suspended==1) {
			$query = mysql_query("update BPPENNYAUTOBID_counters set inactiveusers=(inactiveusers-1)");
		}
		$URL = $_SESSION["RETURN_LIST"]."?PAGE=".$_SESSION['RETURN_LIST_PAGE'];
		unset($_SESSION["RETURN_LIST"]);
		header("Location: $URL");
		exit;	}
}

}
if(!$_POST['action'] || ($_POST['action'] && $ERR)) {
	$query = "select * from BPPENNYAUTOBID_users where id=".intval($id);
	$result = mysql_query($query);
	if(!$result) {
		print "Database access error: abnormal termination".mysql_error();
		exit;
	}
	
	$username = mysql_result($result,0,"name");
	
	$nick = mysql_result($result,0,"nick");
	$password = mysql_result($result,0,"password");
	$email = mysql_result($result,0,"email");
	$address = mysql_result($result,0,"address");
	
	$country = mysql_result($result,0,"country");
	$country_list="";
	while (list ($code, $descr) = each ($countries)) {
		$country_list .= "<option value=\"$descr\"";
		if ($descr == $country) {
			$country_list .= " selected";
		}
		$country_list .= ">$descr</option>\n";
	};
	
	$prov = mysql_result($result,0,"prov");
	$zip = mysql_result($result,0,"zip");
	
	$birthdate = mysql_result($result,0,"birthdate");
	$birth_day = substr($birthdate,6,2);
	$birth_month = substr($birthdate,4,2);
	$birth_year = substr($birthdate,0,4);
	$birthdate = "$birth_day/$birth_month/$birth_year";
	
	$phone = mysql_result($result,0,"phone");
	$suspended = mysql_result($result,0,"suspended");
	
	$rate_num = mysql_result($result,0,"rate_num");
	$rate_sum = mysql_result($result,0,"rate_sum");
	if ($rate_num) {
		$rate = round($rate_sum / $rate_num);
	} else {
		$rate=0;
	}
}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<STYLE TYPE="text/css">
body {
scrollbar-face-color: #aaaaaa;
scrollbar-shadow-color: #666666;
scrollbar-highlight-color: #aaaaaa;
scrollbar-3dlight-color: #dddddd;
scrollbar-darkshadow-color: #444444;
scrollbar-track-color: #cccccc;
scrollbar-arrow-color: #ffffff;
}</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_use.gif" ></td>
          <td class=white><?=$MSG_25_0010?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_045?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">

<table width="95%" border="0" cellspacing="0" cellpadding="1" bgcolor="#546f95" align="CENTER">
        <tr>
          <td align=CENTER class=title><? print $MSG_304; ?></td>
        </tr>
        <tr>
          <td><table width=100% border=0 cellpadding="4" cellspacing=0 bgcolor="#FFFFFF" celpadding=4>
                    <tr>
                      <td align=CENTER colspan=5><br>
                        <br>
                      </td>
                    </tr>
                    <table width="100%" border="0" cellpadding="5" bgcolor=#FFFFFF>
                      <?
                      if($ERR) {
?>
                      <tr>
                        <td width="204" valign="top" align="right"></td>
                        <td width="486"><? print $ERR; ?> </td>
                      </tr>
                      <?
                      }
?>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_302"; ?> </td>
                        <td width="486"><?print $username; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_003"; ?> </td>
                        <td width="486"><? print $nick; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_004"; ?> </td>
                        <td width="486"><? print $password; ?> </td>
                      </tr>
                      <tr>
                        <td width="204"  valign="top" align="right"><? print "$MSG_303"; ?> </td>
                        <td width="486"><? print $email; ?> </td>
                      </tr>
                      <tr>
                        <td width="204"  valign="top" align="right"><? print "$MSG_252"; ?> </td>
                        <td width="486"><? print $birthdate; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_009"; ?> </td>
                        <td width="486"><? print $address; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_014"; ?> </td>
                        <td width="486"><? print $country; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_012"; ?> </td>
                        <td width="486"><? print $zip; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_013"; ?> </td>
                        <td width="486"><? print $phone; ?> </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right"><? print "$MSG_300"; ?> </td>
                        <td width="486">
                        <?
                        if($suspended == 0)
                        print "$MSG_029";
                        else
                        print "$MSG_030";
                        
						?>
                        </td>
                      </tr>
                      <tr>
                        <td width="204" valign="top" align="right">&nbsp;</td>
                        <td width="486">
						<A HREF=userfeedback.php?id=<?=$id?>><?=$MSG_478?></A>
						</td>
                      </tr>
                      <tr>
                        <td width="204">&nbsp;</td>
                        <td width="486"><? print " $MSG_307"; ?> </td>
                      </tr>
                      <tr>
                        <td width="204">&nbsp;</td>
                        <td width="486"><form name=details action="deleteuser.php" method="POST">
                            <input type="hidden" name="id" value="<? echo $id; ?>">
                            <input type="hidden" name="offset" value="<? echo $_GET['offset']; ?>">
                            <input type="hidden" name="action" value="Delete">
                            <input TYPE="submit" NAME="act" value="<? print $MSG_008; ?>">
                          </form></td>
                    </table>
                  </table></td>
        </tr>
      </table>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>