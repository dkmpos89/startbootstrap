<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='style.css' />
</head>
<body>


<?
#// ################################################################
#// Alter user if the install script is already present
if(file_exists("install.php")) {
	print "<SPAN CLASS=error>$MSG_25_0024</SPAN>";
}
if($_GET['show'] == "stats") {
	include_once "./home.stats.php";
} else {
	include_once "./home.installation.php";
}
?>
</body>
</html>