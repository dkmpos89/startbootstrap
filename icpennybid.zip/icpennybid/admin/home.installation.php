
<TABLE WIDTH=95% BORDER=0 CELLPADDING=2 CELLSPACING=0 BGCOLOR="#FFFFFF" ALIGN="CENTER">
  <TR>
    <TD>
		&nbsp;
	</TD>
  </TR>
</TABLE>
<TABLE WIDTH=95% BORDER=0 CELLPADDING=1 CELLSPACING=0 BGCOLOR="#546f95" ALIGN="CENTER">
  <TR>
    <TD>
	<TABLE WIDTH="100%" BORDER="0" CELLPADDING="4" CELLSPACING="1" BGCOLOR="#546f95">
      <TR BGCOLOR="#546f95">
        <TD COLSPAN="2" ALIGN=CENTER class=title><?=$MSG_25_0025?></TD>
        </TR>
      <TR>
        <TD WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_528?>
		</TD>
        <TD WIDTH="71%" BGCOLOR=#FFFFFF>
			<B><?=$SETTINGS['siteurl']?></B>
		</TD>
      </TR>
      <TR>
        <TD WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_527?>
		</TD>
        <TD WIDTH="71%" BGCOLOR=#FFFFFF>
			<B><?=stripslashes($SETTINGS['sitename'])?></B>
		</TD>
      </TR>
      <TR>
        <TD WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_540?>
		</TD>
        <TD WIDTH="71%" BGCOLOR=#FFFFFF>
			<B><?=$SETTINGS['adminmail']?></B>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0026?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				if($SETTINGS['cron'] == '1') {
					print "<B>".$MSG_373."</B><BR>".$MSG_25_0027;
				} else {
					print "<B>".$MSG_374."</B>";
				}
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_663?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				if($SETTINGS['picturesgallery'] == '1') {
					print "<B>".$MGS_2__0066."</B><BR>".$MSG_666.": ".$SETTINGS['maxpictures']."<BR>".$MSG_671.": ".$SETTINGS['maxpicturesize'];
				} else {
					print "<B>".$MGS_2__0067."</B>";
				}
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_5008?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?	
				print "<B>".$SETTINGS['currency']."</B>";
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0035?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?	
				if($SETTINGS['timecorrection'] == 0) {
					print "<B>".$MSG_25_0036."</B>";
				} else {
					print "<B>".$SETTINGS['timecorrection'].$MSG_25_0037."</B>";
				}
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_363?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?	
				print "<B>".$SETTINGS['datesformat']."</B>";
				if($SETTINGS['datesformat'] == 'USA') {
					print " (".$MSG_382.")";
				} else {
					print " (".$MSG_383.")";
				}
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_5322?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?	
				print "<B>".$SETTINGS['defaultcountry']."</B>";
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0040?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				print "<B>".$SETTINGS['alignment']."</B>";
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MGS_2__0051?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				print "<B>".$SETTINGS['pagewidth'];
				if($SETTINGS ['pagewidthtype'] == 'perc') {
					print "%";
				} else {
					print " ".$MSG_5224;
				}
				print "</B>";
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0041?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				print $MSG_5013.":<B> ".$SETTINGS ['lastitemsnumber']."</B><BR>";
				print $MSG_25_0042.":<B> ";
				if($SETTINGS ['loginbox'] == '1') {
					print $MSG_030;
				} else {
					print $MSG_029;
				}
				print "</B><BR>";
				print $MSG_25_0043.":<B> ";
				if($SETTINGS ['newsbox'] == '1') {
					print $MSG_030."</B>";
					print " - ".$MSG_25_0044.":<B> ".$SETTINGS['newstoshow']."</B>";
				} else {
					print $MSG_029;
				}
				print "</B><BR>";
			?>
		</TD>
      </TR>
      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0045?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
				print $MSG_25_0048.":<B> ".$SETTINGS ['thumb_show']." ".$MSG_5224."</B>";
			?>
		</TD>
      </TR>

      <TR>
        <TD VALIGN=TOP WIDTH="29%" BGCOLOR=#FFFFFF>
			<?=$MSG_25_0049?>
		</TD>
        <TD VALIGN=TOP WIDTH="71%" BGCOLOR=#FFFFFF>
			<?
			if($SETTINGS ['newsletter'] == 1) {
				print "<B>".$MGS_2__0066."</B>";
			} else {
				print "<B>".$MGS_2__0067."</B>";
			}
			?>
		</TD>
      </TR>
    </TABLE>
	</TD>
  </TR>
</TABLE>
