<?#//v.3.2.2

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include "loggedin.inc.php";
include $include_path.'dates.inc.php';

$TIME = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d"),date("Y"));
$NOW = date("YmdHis",$TIME);

//-- Set offset and limit for pagination
$limit = 20;
$offset = isset($_GET['offset'])?$_GET['offset']:"";
$action = isset($_GET['action'])?$_GET['action']:"";

$_SESSION['RETURN_LIST'] = 'listauctions.php';
$_SESSION['RETURN_LIST_OFFSET'] = intval($_GET['offset']);

$aid = "";

if (isset($_POST["subMain"]))
{
  $aid = $_POST["main_auction"];
  $query = "UPDATE BPPENNYAUTOBID_auctions SET is_main_auction = 0 ";
  $result = mysql_query($query);
  $query ="UPDATE BPPENNYAUTOBID_auctions SET is_main_auction = 1 WHERE id = $aid ";
  $result = mysql_query($query);
  //echo $_POST["mainauction"];
}

$query = "SELECT id, is_main_auction
		  FROM BPPENNYAUTOBID_auctions
		  WHERE is_main_auction = 1 ";
$result = mysql_query($query);
if($row = mysql_fetch_assoc($result))
{
  $aid = $row['id'];
}

if($action == "reset")
{    
    $sql = "SELECT * FROM BPPENNYAUTOBID_auctions WHERE is_main_auction=1";
    $res = mysql_query($sql);
    if($row1 = mysql_fetch_assoc($res))
    {
        $starts = $NOW;
        $ends_time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d"),date("Y"));
        $ends = date("YmdHis", ($ends_time + ($row1['duration']*3600*24)) );
        $second_starts = $ends;
        $second_ends_time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d")+$row1['duration'],date("Y"));
        $second_ends = date("YmdHis", ($second_ends_time+$row1['second_duration']*60) );
        if($row1['auction_type']==1)
        {
            $sql = "UPDATE BPPENNYAUTOBID_auctions
                    SET
                        starts='$starts',
                        ends='$ends',
                        closed=0,
                        suspended=0
                    WHERE id=$res_id";
        }else{
            $sql = "UPDATE BPPENNYAUTOBID_auctions
                    SET
                        starts='$starts',
                        ends='$ends',
                        second_starts='$second_starts',
                        second_ends='$second_ends',
                        closed=0,
                        suspended=0
                    WHERE id=$res_id";            
        }
        if(mysql_query($sql))$ERR = $MSG_31_0062;
        else{
            print "Database access error: abnormal termination<BR>$sql<BR>".mysql_error();
            exit;
        }
    }
}
?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
    <td background="images/bac_barint.gif">
        <table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr>
            <td width="30"><img src="images/i_auc.gif" ></td>
            <td class=white><?=$MSG_239?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_31_0012; ?></td>
        </tr>
        </table>
    </td>
</tr>
<tr>
    <td align="center" valign="middle">&nbsp;</td>
</tr>
<tr>
    <td align="center" valign="middle">
        <TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95" ALIGN="CENTER">
        <TR>
            <TD ALIGN=CENTER class=title><? echo $MSG_31_0012; ?></TD>
        </TR>
        <TR>
            <TD ALIGN=CENTER class=title><? echo $ERR; ?></TD>
        </TR>
        <TR>
            <TD ALIGN=CENTER class=title>
                <?
                $query = "SELECT
                            a.id,
                            a.title,
                            a.starts,
                            a.description,
                            a.auction_type
                            
                          FROM
                            BPPENNYAUTOBID_auctions a  

                          WHERE
                            a.auction_type = 1 AND 
                            
                            a.closed=0 AND
                            a.suspended=0
                          ORDER BY a.title";// limit $offset, $limit";
                $result = mysql_query($query);
                if(!$result)
                {
                    print "Database access error: abnormal termination<BR>$query<BR>".mysql_error();
                    exit;
                }
                $num_auction = mysql_num_rows($result);
                ?>
                <form action="mainauction.php" method="post">
                    <p>
                    <select name="main_auction">
                    <option value ="">-- select --</option>
                    <?
                    $k = 0;
                    while($k < $num_auction)
                    {
                        $auction_value = mysql_result($result,$k,"id");
                        $title = stripslashes(mysql_result($result,$k,"title"));
                        if($aid == $auction_value)
                        {
                            $atitle = $title;
                            $d = stripslashes(mysql_result($result,$k,"starts"));
                            $date = substr($d,6,2).
                                    substr($d,4,2).
                                    substr($d,0,4).
                                    " ".
                                    substr($d,8,2).
                                    ":".
                                    substr($d,10,2).
                                    ":".
                                    substr($d,12,2);
                            $duration = stripslashes(mysql_result($result,$k,"duration"));
                            $description = stripslashes(mysql_result($result,$k,"description"));
                        }
                        echo "
                        <option value ='$auction_value' ".(($aid == $auction_value) ? "selected" : "").">
                            $title
                        </option> ";
                        $k++;
                    }          
                    ?>
                    </select>
                    </p>
                    <br>
                    
                        <div style="text-align:center">
                            <input type=submit name="subMain" value="<?=$MSG_31_0012;?>"  class=button1 />
                        </div>
                </form>            
            </TD>
        </TR>
        <TR>
            <TD>
                <TABLE WIDTH=100% CELPADDING=0 CELLSPACING=1 BORDER=0 ALIGN="CENTER" CELLPADDING="3">
                <?
                    /*$query = "SELECT COUNT(id) AS auctions FROM BPPENNYAUTOBID_auctions WHERE suspended<>0 ";
                    $result = mysql_query($query);
                    if(!$result){
                      print "$ERR_001<BR>$query<BR>".mysql_error();
                      exit;
                    }
                    $num_auctions = mysql_result($result,0,"auctions");
                    print "<TR BGCOLOR=#FFFFFF><TD COLSPAN=7><B>
                              $num_auctions $MSG_311</B></TD></TR>";*/
                ?>
                <TR BGCOLOR="#FFCC00">
                    <TD ALIGN=CENTER> <B> <? print $MSG_312; ?> </B>  </TD>
                    <!--<TD ALIGN=CENTER> <B> <? print $MSG_313; ?> </B>  </TD>-->
                    <TD ALIGN=CENTER> <B> <? print $MSG_314; ?> </B>  </TD>
                    <TD ALIGN=CENTER> <B> <? print $MSG_315; ?> </B>  </TD>
                    <!--<TD ALIGN=LEFT> <B> <? print $MSG_316; ?> </B>  </TD>-->
                    <TD ALIGN=LEFT> <B> <? print $MSG_317; ?> </B>  </TD>
                    <TD ALIGN=LEFT> <B> <? print $MSG_297; ?> </B>  </TD>
                </TR>
                <TR BGCOLOR="#FFFFFF" >
					<TD>
                        <?=$atitle?>
					</TD>
					<TD>
						<?=$date?>
					</TD>
					<TD>
						<?=$duration?>
                    </TD>
                    <TD>
                        <?=$description?>
					</TD>
					<TD ALIGN=LEFT>
                        <? 
                        echo "
                        <A HREF=\"editauction.php?id=$aid&offset=$offset\" class=\"nounderlined\">$MSG_298</A><BR>
                        <A HREF=\"deleteauction.php?id=$aid&offset=$offset\" class=\"nounderlined\">$MSG_299</A><BR>
						<A HREF=\"excludeauction.php?id=$aid&offset=$offset&mode=activate\" class=\"nounderlined\">$MSG_300</A><BR>
                        <A HREF=\"mainauction.php?action=reset\" class=\"nounderlined\">$MSG_31_0061</A><BR>";
                        ?>
					</TD>
				<TR>
                </TABLE>
            </td>
        </tr>
	</td>
</tr>
</table>
</BODY>
</HTML>
