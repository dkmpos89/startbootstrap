<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";

unset($ERR);
$id = $_REQUEST[id];


#// Insert new template
if($_POST['action'] == "update" && strstr(basename($_SERVER['HTTP_REFERER']),basename($_SERVER['PHP_SELF']))){

	if(empty($_POST['templatename']) || empty($_POST['templatecode']))
	{
		$ERR = $ERR_047;
	}
	else
	{
		#// Handle sample image if any
		if(!empty($_FILES['sampleimage']['tmp_name']) && $_FILES['sampleimage']['tmp_name'] != 'none')
		{
			#// Create samples directory if it does not exist
			if(!file_exists($image_upload_path."aboutmesamples"))
			{
				umask();
				mkdir($image_upload_path."aboutmesamples",0777);
			}
			if(file_exists($image_upload_path."aboutmesamples/".$_FILES['sampleimage']['name']))
			{
				$ERR = $MSG__0123.$image_upload_path."aboutmesamples/".$_FILES['sampleimage']['name'].$MSG__0124;
			}
			else
			{
				@move_uploaded_file($_FILES['sampleimage']['tmp_name'],$image_upload_path."aboutmesamples/".$_FILES['sampleimage']['name']);
				chmod($image_upload_path."aboutmesamples/".$_FILES['sampleimage']['name'],0666);
				$IMAGEUPLOADED = TRUE;
				
				#// Delete the old image
				@unlink($image_upload_path."aboutmesamples/".$_POST['currentimage']);
			}
		}
		if(!$ERR)
		{
			$query = "UPDATE BPPENNYAUTOBID_aboutmetemplates SET
						  name='".addslashes($_POST['templatename'])."',";
			if($IMAGEUPLOADED)
			{
				$query .= "sample='".$_FILES['sampleimage']['name']."',";
			}
			$query .= "code='".addslashes($_POST['templatecode'])."' WHERE id=".$id;
			$res = @mysql_query($query);
			if(!$res)
			{
				print "Error: $query<BR>".mysql_error();
				exit;
			}
			else
			{
				$ERR = $MSG__0120;
				$SETTINGS = $_POST;
			}
		}
	}
}


#// Retrieve existing templates
$query = "SELECT * FROM BPPENNYAUTOBID_aboutmetemplates WHERE id=$id";
$res_ = mysql_query($query);
if(!$res_)
{
	print "$query<BR>".mysql_error();
	exit;
}
elseif(mysql_num_rows($res_) > 0)
{
	$TEMPLATE = mysql_fetch_array($res_);
}


?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<BODY>
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD>
<CENTER>
				<BR>
				<FORM NAME='conf' ACTION=<?=basename($_SERVER['PHP_SELF'])?> METHOD='POST'  ENCTYPE="multipart/form-data">

          <TABLE WIDTH="80%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#296FAB" ALIGN="CENTER">
            <TR>
							<TD ALIGN=CENTER class=title>
								<? print $MSG__0119; ?>
							</TD>
						</TR>
						<TR>
							<TD>

                <TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
                  <?
                  if(isset($ERR))
                  {
					?>
                  <TR BGCOLOR=yellow>
                    <TD ALIGN=CENTER><B>
                      <? print $ERR; ?>
                      </B></TD>
                  </TR>
                  <?
                  }
				 ?>
                  <TR VALIGN="TOP">
                    <TD WIDTH="526">
                      <div align="right"><a href="aboutmetemplates.php">Back</a>
                        </div>
                    </TD>
                  </TR>
                  <TR VALIGN="TOP">
                    <TD WIDTH="526" HEIGHT="22">
                      <table width="80%" border="0" cellspacing="0" cellpadding="4" bgcolor="#CCCCCC" align="center">
                        <tr bgcolor="#FFFFFF">
                          <td width="25%">
                            <? print $MSG__0110; ?>
                            </td>
                          <td width="75%">
                            <input type="text" name="templatename" size="45" VALUE="<?=stripslashes($TEMPLATE['name'])?>">
                          </td>
                        </tr>
                        <tr bgcolor="#FFFFFF">
                          <td width="25%" valign="top">
                            <? print $MSG__0115; ?>
                            </td>
                          <td width="75%">
                            <textarea name="templatecode" cols="65" rows="20"><?=stripslashes($TEMPLATE['code'])?></textarea>
                          </td>
                        </tr>
                        <tr bgcolor="#FFFFFF" valign=top>
                          <td width="25%">
                            <? print $MSG__0122; ?>
                            </td>
                          <td width="75%"> 
                            
                            <?
                            if(!empty($TEMPLATE['sample']))
                            {
							?>
                            <IMG SRC="../<?=$uploaded_path?>aboutmesamples/<?=$TEMPLATE['sample']?>">
							<INPUT TYPE=hidden NAME=currentimage VALUE="<?=$TEMPLATE['sample']?>">
                            <?
                            }
							?>
                            <br>
                            
                            <br>
                            <? print $MSG__0126; ?>
                             <br>
                            <input type="file" name="sampleimage" size="25">
                          </td>
                        </tr>
                        <tr bgcolor="#FFFFFF">
                          <td width="25%" valign="top">
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="id" value="<?=$id?>">
                          </td>
                          <td width="75%">
                            <input type=submit name=SubmitInsert value="<? print $MSG_530; ?>">
                          </td>
                        </tr>
                      </table>
                      
                      </TD>
                  </TR>
                  <TR VALIGN="TOP">
                    <TD WIDTH="526" HEIGHT="22">&nbsp;</TD>
                  </TR>
                  <TR>
                    <TD WIDTH="526">&nbsp; </TD>
                  </TR>
                  <TR>
                    <TD WIDTH="526"> </TD>
                  </TR>
                </TABLE>
							</TD>
						</TR>
					</TABLE>
					</FORM>
	<BR><BR>

	
	<A HREF="admin.php" CLASS="links">Admin Home</A>
	
	</CENTER>
	<BR><BR>

</TD>
</TR>
</TABLE>
</BODY>
</HTML>
