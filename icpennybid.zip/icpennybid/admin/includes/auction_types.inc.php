<?#//v.3.0.0
if(!defined("INCLUDED")) exit("Access denied");
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

	$auction_types = array (
		1 => "'Classic'"
//		2 => "Low Bid Auction 'Extended'",
//        3 => "Low Bid Auction 'Extended Reverse'"
	);
?>