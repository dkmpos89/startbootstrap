<?include_once "../includes/config.inc.php";?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?php echo $SETTINGS['sitename'];?> Administration back-end</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script language="javascript" src="../js/langs.js"></script>
</head>

<body bgcolor="#546f95" background="images/bac_hea.gif" text="#FFFFFF" link="#FFFFFF" vlink="#CCCCCC" alink="#666666" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" height="54" border="0" cellpadding="2" cellspacing="2" background="images/bac_hea.gif">
  <tr> 
    <td width="285" rowspan="2" valign="middle">
		<h2><?php echo $SETTINGS['sitename'];?></h2>
	</td>
	<td height="20">
		<div align="right"><b>Administration back-end</b><!--<img src="images/t_adm_be.gif" width="192" height="16" hspace="5">--></div>
	</td>
	<td height="20" align="right">
      <?php
			$sql="SELECT * FROM BPPENNYAUTOBID_languages WHERE is_active=1 ORDER BY id";
			$result=mysql_query($sql);
			while($row=mysql_fetch_assoc($result)) {
				echo "&nbsp;<a href='javascript:changeLang_adm(\"".$row['code']."\");'><img border=0  src='../images/flags/".$row['image']."'></a>\n";
			}
    	?>
	</td>
  </tr>
  <tr>
  	<TD>
  	<?
  		if (file_exists("../reverse/index.php")) {
  			print "<A TARGET=_top HREF=../reverse/admin/>$MSG_2_0046</A>";
  		}
  		print "&nbsp;&nbsp;&nbsp;";
  		if (file_exists("../classifieds/index.php")) {
  			print "<A TARGET=_top HREF=../classifieds/admin/>$MSG_2_0001</A>";
  		}
  	?>
	</TD> 
    <td valign="top" align=right>
		<font size="1" face="Verdana, Arial, Helvetica, sans-serif">
		<?
		  if($_SESSION['BPPENNYAUTOBID_ADMIN_LOGIN']) {
		?>
		  <?=$MSG_592?>
		  <B>
		  <?=$_SESSION['BPPENNYAUTOBID_ADMIN_USER']?>
		  </B></FONT>
		  <?
		  } else {
			print "&nbsp;";
		  }
		  if($_SESSION['BPPENNYAUTOBID_ADMIN_LOGIN']) {
		?>
		 <font color="#FFFFFF" SIZE=1> | 
		 </font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"><a href="logout.php" TARGET=content>logout</a></FONT></font>
		 
		 <?
		  }
		?>
	 </td>
  </tr>
</table>
</body>
</html>