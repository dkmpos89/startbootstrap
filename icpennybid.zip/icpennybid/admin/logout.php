<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";
unset($BPPENNYAUTOBID_ADMIN_LOGIN);
unset($BPPENNYAUTOBID_ADMIN_USER);
unset($_SESSION["BPPENNYAUTOBID_ADMIN_LOGIN"]);
unset($_SESSION["BPPENNYAUTOBID_ADMIN_USER"]);
//Header("Location: login.php");
?>
<SCRIPT Language=Javascript>
parent.location.href='index.php';
</SCRIPT>