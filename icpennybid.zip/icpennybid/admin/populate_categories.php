<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
@mysql_query("DELETE FROM BPPENNYAUTOBID_cats_translated");
$query = "delete from BPPENNYAUTOBID_categories";
$result = @mysql_query($query);
if(!$result){
	print $ERR_001;
	exit;
}
$buffer = file("./categories.txt");
$count_cat  = 0;
$counter    = 0;
$id		    = 0;
$actuals[0] = 0;
while(!preg_match("#^1@(.)*$#",$buffer[$counter])){
	$counter++;
}

while($counter < count($buffer))
{
	set_time_limit(500);
	$category    = explode("@", $buffer[$counter]);
	$category[1] = preg_replace(10,"",$category[1]);
	$category[1] = preg_replace(13,"",$category[1]);
	$id++;;
	if($category[0] != $actual){
		$actual = $category[0];
	}
	$actuals[$actual]	= $id;
	$father = $actuals[$actual - 1];
	$query = "insert into BPPENNYAUTOBID_categories (cat_id, parent_id, cat_name, deleted,
		sub_counter, counter) values($id,".intval($father).",\"$category[1]\",0,0,0)";
	$result = mysql_query($query);
	if(!$result)
	{
		print $ERR_001;
		print "<BR>$query - $actual";
		exit;
	}
	
	$counter++;
	$count_cat++;
}

include_once "util_cc1.php";
include_once "util_cc2.php";
include_once $include_path."updatecategories.inc.php";



?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<SCRIPT Language=Javascript>

function window_open(pagina,titulo,ancho,largo,x,y){
	
	var Ventana= 'toolbar=0,location=0,directories=0,scrollbars=1,screenX='+x+',screenY='+y+',status=0,menubar=0,resizable=0,width='+ancho+',height='+largo;
	open(pagina,titulo,Ventana);
	
}
</SCRIPT>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_sta.gif" ></td>
          <td class=white><?=$MSG_25_0023?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_5318?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
		<TD ALIGN=CENTER><BR>
<FORM NAME=conf ACTION=<?=basename($PHP_SELF)?> METHOD=POST>
				<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#296FAB">
					<TR>
						<TD ALIGN=CENTER class=title>
							<? print $MSG_369; ?>
						</TD>
					</TR>
					<TR>
						<TD>
							<TABLE WIDTH=100% CELLPADDING=2 BGCOLOR="#FFFFFF">
								<TR>
									<TD WIDTH=50 HEIGHT="21">&nbsp;</TD>
									<TD COLSPAN=4 HEIGHT="21"> 
										<?=$MSG_407?>
										 </TD>
								</TR>
								<TR>
									<TD WIDTH=50 HEIGHT="22"></TD>
									<TD WIDTH="302" HEIGHT="22">&nbsp; </TD>
								</TR>
								<TR>
									<TD WIDTH=50></TD>
									<TD WIDTH="302"> </TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
				</FORM>
		</TD>
		</TR>
		</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>
