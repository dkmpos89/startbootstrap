<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";
require("./header.php");
include_once $include_path.'styles.inc.php';

unset($ERR);

#//
if($_POST[action] == "update" && basename($_SERVER['HTTP_REFERER']) == basename($_SERVER['PHP_SELF']))
{
	#// Update database
	$query = "ALTER TABLE BPPENNYAUTOBID_settings ADD aboutme ENUM('y','n') DEFAULT 'n'";
	$res = @mysql_query($query);
	if(!$res)
	{
		print "Error: $query<BR>".mysql_error();
		exit;
	}
	else
	{
		Header("Location: aboutme.php");
		exit;
	}
}



?>
<link rel='stylesheet' type='text/css' href='style.css' />
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD>
<CENTER>
<BR>
<FORM NAME=conf ACTION=<?=basename($_SERVER['PHP_SELF'])?> METHOD=POST>
	<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#296FAB" ALIGN="CENTER">
		<TR>
			<TD ALIGN=CENTER class=title>
				<? print $MSG__0100; ?>
			</TD>
		</TR>
		<TR>
			<TD>

<TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
  <?
  if(isset($ERR))
  {
?>
  <TR BGCOLOR=yellow>
	<TD class=error COLSPAN="2" ALIGN=CENTER>
	  <? print $ERR; ?>
	  </TD>
  </TR>
  <?
  }
 ?>
  <TR VALIGN="TOP">
	<TD colspan="2">
	  <p>&nbsp;</p><div align="center">
		<? print $MSG__0103; ?>
		</div>
	</TD>
  </TR>
  <TR VALIGN="TOP">
	<TD WIDTH=39 HEIGHT="22">&nbsp;</TD>
	<TD WIDTH="593" HEIGHT="22">&nbsp;</TD>
  </TR>
  <TR>
	<TD colspan="2">
	  <div align="center">
		<INPUT TYPE="hidden" NAME="action" VALUE="update">
		<INPUT TYPE="submit" NAME="act" VALUE="<? print $MSG__0104; ?>">
	  </div>
	</TD>
  </TR>
  <TR>
	<TD WIDTH=39></TD>
	<TD WIDTH="593"> </TD>
  </TR>
</TABLE>
			</TD>
		</TR>
	</TABLE>
	</FORM>
	<BR><BR>

	
	<A HREF="admin.php" CLASS="links">Admin Home</A>
	
	</CENTER>
	<BR><BR>

</TD>
</TR>
</TABLE>

<!-- Closing external table (header.php) -->
<? require("./footer.php"); ?>
</BODY>
</HTML>
