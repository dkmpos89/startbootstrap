<?
include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once "../includes/countries.inc.php";
$id=isset($_GET['id'])?$_GET['id']:"";
$title=isset($_GET['title'])?$_GET['title']:"";
$action=isset($_POST['action'])?$_POST['action']:"";

if (intval($id)>0) { 
?>
<script language="Javascript" type="text/javascript" src="includes/calendar.js"></script>
<link rel='stylesheet' type='text/css' href='themes/default/style.css'/>


<form method="post" action="listallauctions.php" name="clone_frm" id='clone_frm'>
    <input type="hidden" name='aid' value='<?=$id?>'>
    <input type="hidden" name='action' value='clone'>
<div class="titTable2">
Create auction clone<span style="font-size:10px;">&nbsp;&nbsp;for auction</span>&nbsp;<?=$title?>
</div>

<div class="table2">
    <table width="100%" border="0" cellpadding="4" cellspacing="0">

        <tr>
            <td class="leftpan" align="right" valign="top" width="25%"><b>
                Starting date                            </b> </td>
            <td class="rightpan">
                <input name="a_starts" id="pubdate_input" value="<?= date("Y-m-d H:i:s")?>" size="20" maxlength="19" type="text">
                <a href="javascript:pubdate_cal.popup()"><img src="../includes/img/calendar.gif" alt="Click Here to Pick up the date" border="0" width="16" height="16"></a>
                <script language="JavaScript">
                var pubdate_cal = new xar_base_calendar(document.getElementById("pubdate_input"), "."); pubdate_cal.year_scroll = true; pubdate_cal.time_comp = true;
                </script>
            </td>
        </tr>
        <tr>
            <td class="leftpan" align="right" valign="top" width="25%"><b>Duration</b> </td>
            <td class="rightpan"><select name="duration">
              <option value="0">0 days</option>  <option value="1">1 day</option>  <option value="2">2 days</option>  <option value="3">3 days</option>  <option value="4">4 days</option>  <option value="7">1 week</option>  <option value="7">7 days</option>  <option value="9">9 days</option>  <option value="11">11 days</option>  <option value="14">2 weeks</option>  <option value="15">15 days</option>  <option value="18">18 days</option>  <option value="19">19 days</option>  <option value="20">20 days</option>  <option value="21">3 weeks</option>  <option value="24">24 days</option>  <option value="26">26 days</option>  <option value="28">4 weeks</option>  <option value="30">1 months</option>  <option value="60">2 months</option>  <option value="90">3 months</option>  <option value="120">4 months</option>
            </select>
                &nbsp;
                hours
                <select name="duration_hours">
                   <option value="00">0</option>
                   <option value="01">1</option>
                   <option value="02">2</option>
                   <option value="03">3</option>
                   <option value="04">4</option>
                   <option value="05">5</option>
                   <option value="06">6</option>
                   <option value="07">7</option>
                   <option value="08">8</option>
                   <option value="09">9</option>
                   <option value="10">10</option>
                   <option value="11">11</option>
                   <option value="12" selected="selected">12</option>
                   <option value="13">13</option>
                   <option value="14">14</option>
                   <option value="15">15</option>
                   <option value="16">16</option>
                   <option value="17">17</option>
                   <option value="18">18</option>
                   <option value="19">19</option>
                   <option value="20">20</option>
                   <option value="21">21</option>
                   <option value="22">22</option>
                   <option value="23">23</option>
                </select>
                &nbsp;
                minutes
                <select name="duration_minutes">
                   <option value="00" selected="selected">00</option>
                   <option value="05">05</option>
                   <option value="10">10</option>
                   <option value="15">15</option>
                   <option value="20">20</option>
                   <option value="25">25</option>
                   <option value="30">30</option>
                   <option value="35">35</option>
                   <option value="40">40</option>
                   <option value="45">45</option>
                   <option value="50">50</option>         
                   <option value="55">55</option>
                </select>
            </td>
        </tr>
    </table>
    </div>
    <div style="text-align: center;">
        <input type="button" value="Submit" class="button" onclick="submit_clone()" >&nbsp;&nbsp;&nbsp;<input name="" type="button" value="Cancel" class="button" onclick="window.close()">
    </div>

</form>
<script>
function submit_clone() {
    document.getElementById("clone_frm").submit();
    
}
</script>
<? } ?>