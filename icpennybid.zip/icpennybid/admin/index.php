<?
	include_once "../includes/config.inc.php";
?>

<html>
<head>
<title>Admin area </title>

</head>

<frameset rows="54,*" frameborder="NO" border="0" framespacing="0">
  <frame src="header.php" name="header" frameborder="no" scrolling="NO" noresize marginwidth="0" marginheight="0" id="header" >
  <frameset cols="216,*" frameborder="NO" border="0" framespacing="0"> 
    <frame CLASS=TA src="bar.php" name="bar" frameborder="no" scrolling="auto" marginwidth="0" marginheight="0" id="bar">
    <frame src="home.php" name="content" frameborder="no" marginwidth="0" marginheight="0" id="content">
</frameset>
</frameset>
<noframes><body>

</body></noframes>
</html>
