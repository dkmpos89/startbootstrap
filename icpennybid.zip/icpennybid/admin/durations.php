<?php

require('../includes/config.inc.php');
include_once "loggedin.inc.php";

Function ToBeDeleted($index){
	Global $delete;
	
	$i = 0;
	while($i < count($_POST['delete'])){
		if($_POST['delete'][$i] == $index) return true;
		
		$i++;
	}
	return false;
}

if($_POST['act'] && !$$ERR && basename($_SERVER['HTTP_REFERER']) == basename($_SERVER['PHP_SELF'])){	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
		$ERR = $ERR_9999;
	}else{
		$rebuilt_durations = array();
		$rebuilt_days      = array();	
		$i = 0;	
		while($i < count($_POST['new_durations']) && strlen($_POST['new_durations'][$i]) != 0){	
		
			if(!ToBeDeleted($_POST['new_days'][$i]) && strlen($_POST['new_durations'][$i]) != 0){	
				$rebuilt_durations[$i]         = $_POST['new_durations'][$i];	
				
				$rebuilt_days[$i]              = $_POST['new_days'][$i];	
			}	else {
				$rebuilt_durations[$i] = "";
			}
			$i++;	
		}		
		
		$query = "delete from BPPENNYAUTOBID_durations";	
		$result = mysql_query($query);	
		if(!$result) {	
			print $ERR_001." - ".mysql_error();	
		}		
		$i = 0;	
		
		while($i < count($rebuilt_durations)){	
			if (strlen($rebuilt_durations[$i])!=0){
			$query = "insert into	
	                        		  BPPENNYAUTOBID_durations	
	                        		  values($rebuilt_days[$i],	
	                        		  \"$rebuilt_durations[$i]\")";	
			$result = mysql_query($query);	
			// print $query."<BR>";	
			if(!$result) {	
				print $ERR_001." - ".mysql_error();	
			}	
			}
			$i++;	
		}	
			
		$MSG = "$MSG_123";	}
}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<SCRIPT Language=javascript>
function selectAll(formObj, isInverse)  {
   for (var i=0;i < formObj.length;i++)  {
      fldObj = formObj.elements[i];
      if (fldObj.type == 'checkbox' && fldObj.name.substring(0,6)=='delete') { 
         if(isInverse)
            fldObj.checked = (fldObj.checked) ? false : true;
         else fldObj.checked = true; 
       }
   }
}
</SCRIPT>

<STYLE TYPE="text/css">
body {
scrollbar-face-color: #aaaaaa;
scrollbar-shadow-color: #666666;
scrollbar-highlight-color: #aaaaaa;
scrollbar-3dlight-color: #dddddd;
scrollbar-darkshadow-color: #444444;
scrollbar-track-color: #cccccc;
scrollbar-arrow-color: #ffffff;
}</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_set.gif" width="21" height="19"></td>
          <td class=white><?=$MSG_25_0007?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_069?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD COLSPAN=3>
<FORM NAME=conf ACTION=durations.php METHOD=POST>
<BR>
<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95" ALIGN="CENTER">
		<TR>
				<TD ALIGN=CENTER class=title>
						<? print $MSG_069; ?>
				</TD>
		</TR>
		<TR>
			<TD>
				<TABLE WIDTH=100% CELLPADDING=2 BGCOLOR="#FFFFFF">
					<TR>
						<TD WIDTH=50></TD>
						<TD COLSPAN=2> 							<?
								print $MSG_122;
								if($ERR){
									print "<FONT COLOR=red><BR><BR>".$ERR."</font>";
								}else{
									if($MSG){
										print "<FONT COLOR=red><BR><BR>".$MSG."</font>";
									}else{
										print "<BR><BR>";
									}
								}
							?>
						</TD>
					</TR>
					<TR>
						<TD WIDTH=50></TD>
						<TD BGCOLOR="#EEEEEE">
							<B>
							<? print $MSG_097; ?>
							</B> </TD>
						<TD BGCOLOR="#EEEEEE">
							<B>
							<? print $MSG_087; ?>
							</B> </TD>
						<TD BGCOLOR="#EEEEEE">
							<B>
							<? print $MSG_088; ?>
							</B> </TD>
					</TR>
					<?
					//--
					$query = "select * from BPPENNYAUTOBID_durations order by days";
					$result = mysql_query($query);
					if(!$result) {
						print $ERR_001." - ".mysql_error();
						exit;
					}
					$num = mysql_num_rows($result);
					$i = 0;

					while($i < $num){
						$days                  = mysql_result($result,$i,"days");
						$description = mysql_result($result,$i,"description");
						print "<TR>
							 <TD WIDTH=50></TD>
							 <TD>
							 <INPUT TYPE=text NAME=new_days[] VALUE=\"$days\" SIZE=5>
							 </TD>
							 <TD>
							 <INPUT TYPE=text NAME=new_durations[] VALUE=\"$description\" SIZE=25>
							 </TD>
							 <TD align=center>
							 <INPUT TYPE=checkbox NAME=delete[] VALUE=\"$days\">
							 </TD>
							 </TR>";
								$i++;
							}
							print "<TR>
									 <TD WIDTH=50>
									  Add
									 </TD>
									 <TD>
									  Days <INPUT TYPE=\"text\" NAME=\"new_days[]\" SIZE=\"5\" maxlength=\"5\" value=\"0\">
									 </TD>
									 <TD>
									 <INPUT TYPE=text NAME=\"new_durations[]\" SIZE=25>
									 </TD>
									 <TD align=center>
									 <a href=\"javascript: void(0)\" onclick=\"selectAll(document.forms[0],1)\">$MSG_30_0102</A>
									 </TD>
									 </TR>";
							?>
					<TR>
						<TD WIDTH=50></TD>
						<TD>
							<INPUT TYPE="submit" NAME="act" VALUE="<? print $MSG_089; ?>">
						</TD>
					</TR>
					<TR>
						<TD WIDTH=50></TD>
						<TD> </TD>
					</TR>
				</TABLE>
			</TD>
		</TR>
</TABLE>
</FORM>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>