<?php
require('../includes/config.inc.php');
include_once "loggedin.inc.php";
$prefix="../";
#//
$ERR = "";

#//
$query = "SELECT * FROM BPPENNYAUTOBID_settings";
$res = @mysql_query($query);
if(!$res) {
	print "Error: $query<BR>".mysql_error();
	exit;
} elseif(mysql_num_rows($res) > 0) {
	$HOME_SETTINGS = mysql_fetch_array($res);
	$SETTINGS=array_merge($SETTINGS,$HOME_SETTINGS);
}
if(file_exists(realpath(phpa_uploaded()."settings.ini"))) {
	$INI_SETTINGS=parse_ini_file(realpath(phpa_uploaded()."settings.ini"));
	$SETTINGS=array_merge($SETTINGS,$INI_SETTINGS);
}
#//
if($_POST['action'] == "update")
{	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
		$ERR = $ERR_9999;
	}else{

		if($_FILES['logo']['tmp_name']){
		
		#// Handle logo upload
		
		$inf = GetImageSize ($_FILES['logo']['tmp_name']);
		
		if ( $inf[2]<1 || $inf[2]>3 ) {
		
			print $ERR_602;
		
			exit;
		
		}
		
		if(!empty($_FILES['logo']['tmp_name']) && $_FILES['logo']['tmp_name'] != "none") {
		
			//		$TARGET = $image_upload_path.$_FILES['logo']['name'];
		
			$TARGET = realpath(phpa_uploaded())."/".$_FILES['logo']['name'];
		
			@move_uploaded_file($_FILES['logo']['tmp_name'],$TARGET);
		
			chmod($TARGET,0666);
		
			$LOGOUPLOADED = TRUE;
		
		}
			
		
		}		
				
		#// Handle logo upload		
		if(!empty($_FILES['background']['tmp_name']) && $_FILES['background']['tmp_name'] != "none") {		
		//		$TARGET = $image_upload_path.$_FILES['background']['name'];		
		$TARGET = realpath(phpa_uploaded())."/".$_FILES['background']['name'];		
		@move_uploaded_file($_FILES['background']['tmp_name'],$TARGET);		
		chmod($TARGET,0666);		
		$BACKUPLOADED = TRUE;		
		}		
				
		$query = " UPDATE BPPENNYAUTOBID_settings SET		
				   loginbox=".$_POST['loginbox'].",		
				   newsbox=".$_POST['newsbox'].",		
				   newstoshow=".$_POST['newstoshow'].",";		
		$INI_SETTINGS[loginbox]=$_POST['loginbox'];		
		$INI_SETTINGS[newsbox]=$_POST['newsbox'];		
		$INI_SETTINGS[newstoshow]=$_POST['newstoshow'];		
		if($LOGOUPLOADED) {		
		$query .= "logo='".$_FILES['logo']['name']."', ";		
		$INI_SETTINGS[logo]=$_FILES['logo']['name'];		
		}		
		if($BACKUPLOADED) {		
		$query .= "background='".$_FILES['background']['name']."', ";		
		$INI_SETTINGS[background]=$_FILES['background']['name'];		
		}		
		$query .= "		
					featureditemsnumber=".intval($_POST['featureditemsnumber']).",		
					featuredcolumns=".intval($_POST['featuredcolumns']).",		
					lastitemsnumber=".intval($_POST['lastitemsnumber']).",		
					catfeatureditemsnumber=".intval($_POST['catfeatureditemsnumber']).",		
					catthumbnailswidth=".intval($_POST['catthumbnailswidth']).",		
					higherbidsnumber=".intval($_POST['higherbidsnumber']).",		
					show_closed_auctions=".intval($_POST['show_closed_auctions']).",		
							
					endingsoonnumber=".intval($_POST['endingsoonnumber']).",		
					thimbnailswidth=".intval($_POST['thimbnailswidth']).",		
					pagewidth=".intval($_POST['pagewidth']).",		
					pagewidthtype='".$_POST['pagewidthtype']."',		
					alignment='".$_POST['alignment']."';";			
		$INI_SETTINGS[brepeat]=$_POST['brepeat'];		
		$INI_SETTINGS[featureditemsnumber]=intval($_POST['featureditemsnumber']);		
		$INI_SETTINGS[featuredcolumns]=intval($_POST['featuredcolumns']);		
		$INI_SETTINGS[show_closed_auctions]=intval($_POST['show_closed_auctions']);		
				
		$INI_SETTINGS[lastitemsnumber]=intval($_POST['lastitemsnumber']);		
		$INI_SETTINGS[catfeatureditemsnumber]=intval($_POST['catfeatureditemsnumber']);		
		$INI_SETTINGS[catthumbnailswidth]=intval($_POST['catthumbnailswidth']);		
		$INI_SETTINGS[higherbidsnumber]=intval($_POST['higherbidsnumber']);		
		$INI_SETTINGS[endingsoonnumber]=intval($_POST['endingsoonnumber']);		
		$INI_SETTINGS[thimbnailswidth]=intval($_POST['thimbnailswidth']);		
		$INI_SETTINGS[pagewidth]=intval($_POST['pagewidth']);		
		$INI_SETTINGS[pagewidthtype]=$_POST['pagewidthtype'];		
		$INI_SETTINGS[alignment]=$_POST['alignment'];		
		$initxt="";		
		foreach($INI_SETTINGS as $k=>$v)		
		$initxt.="$k=$v\r\n";		
		$fp=fopen(realpath(phpa_uploaded())."/"."settings.ini","w");		
		fwrite($fp,$initxt);		
		fclose($fp);		
		$res_ = @mysql_query($query);		
		if(!$res_) {		
		print "Error: $query<BR>".mysql_error();		
		exit;		
		} else {		
		$SETTINGS=array_merge($SETTINGS,$INI_SETTINGS);		
		$ERR = $MSG_5019;		
		}
	}
}

?>
<html>
<head>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0"><table width="100%" border="0" cellpadding="0" cellspacing="0">
    <tr>
        <td background="images/bac_barint.gif">
            <table width="100%" border="0" cellspacing="5" cellpadding="0">
                <tr>
                    <td width="30"><img src="images/i_gra.gif" width="19" height="19"></td>
                    <td class=white><?=$MSG_25_0009?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_5005?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td align="center" valign="middle">&nbsp;</td>
    </tr>
    <tr>
        <td align="center" valign="middle">
            <table border=0 width=100% cellpadding=0 cellspacing=0 bgcolor="#FFFFFF">
                <tr>
                    <td align="center"> <br>
                        <form name=conf action="<?=basename($PHP_SELF)?>" method="POST"  enctype="multipart/form-data">
                            <table width="95%" border="0" cellspacing="0" cellpadding="1" bgcolor="#546f95">
                                <tr>
                                    <td align=CENTER class=title><? print $MSG_5005; ?></td>
                                </tr>
                                <tr>
                                    <td>
                                        <table width=100% cellpadding=2 align="CENTER" bgcolor="#FFFFFF">
                                            <?
                                            if($ERR != "") {
											?>
                                            <tr>
                                                <td colspan="2" align=CENTER bgcolor="yellow"><b><? print $ERR; ?> </b></td>
                                            </tr>
                                            <?
                                            }
											?>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td width=169> 
                                                    <?=$MSG_1056?>
                                                     </td>
                                                <td width="393"> 
                                                    <?=$MSG_1057?>
                                                     <br>
                                                    <select name="alignment">
                                                        <option value="left" <?if($SETTINGS['alignment'] == "left") print " SELECTED"?>>Left</option>
                                                        <option value="center" <?if($SETTINGS['alignment'] == "center") print " SELECTED"?>>Center</option>
                                                        <option value="right" <?if($SETTINGS['alignment'] == "right") print " SELECTED"?>>Right</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td> 
                                                    <?=$MGS_2__0051?>
                                                     </td>
                                                <td> 
                                                    <?=$MGS_2__0052?>
                                                     <br>
                                                    <input name="pagewidth" type="text" id="pagewidth" size="5" maxlength="5" value=<?=$SETTINGS['pagewidth']?>>
&nbsp;
                                                    <select name="pagewidthtype" id="pagewidthtype">
                                                        <option value='perc' <?if($SETTINGS['pagewidthtype'] == 'perc') print " SELECTED";?>>%</option>
                                                        <option value='fix' <?if($SETTINGS['pagewidthtype'] == 'fix') print " SELECTED";?>>
                                                        <?=$MGS_2__0053?>
                                                        </option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td width=169> <? print $MSG_5013; ?> </td>
                                                <td width="393">  <? print $MSG_5014; ?> <br>
                                                    <input type="text" size=5 name=lastitemsnumber value="<?=$SETTINGS['lastitemsnumber']?>">
                                                </td>
                                            </tr>
                                           <!--   <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                          <tr valign="TOP">
                                                <td width=169> <? print $MSG_5015; ?> </td>
                                                <td width="393">  <? print $MSG_5016; ?> <br>
                                                    <input type="text" size=5 name=higherbidsnumber value="<?=$SETTINGS['higherbidsnumber']?>">
                                                </td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td width=169> <? print $MSG_5017; ?> </td>
                                                <td width="393">  <? print $MSG_5018; ?> <br>
                                                    <input type="text" size=5 name=endingsoonnumber value="<?=$SETTINGS['endingsoonnumber']?>">
                                                </td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>-->
                                            <tr valign="TOP">
                                                <td width=169> <? print $MSG_532; ?> </td>
                                                <td width="393">  <? print $MSG_537; ?> <br>
                                                    <input type="radio" name="loginbox" value="1"
					 <? if($SETTINGS['loginbox'] == 1) print " CHECKED";?>
					 >
                                                     <? print $MSG_030; ?> 
                                                    <input type="radio" name="loginbox" value="2"
					 <? if($SETTINGS['loginbox'] == 2) print " CHECKED";?>
					 >
                                                     <? print $MSG_029; ?>  </td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
                                            <tr valign="TOP">
                                                <td width=169 height="61"> <? print $MSG_533; ?> </td>
                                                <td width="393" height="61">  <? print $MSG_538; ?> <br>
                                                    <input type="radio" name="newsbox" value="1"
					 <? if($SETTINGS['newsbox'] == 1) print " CHECKED";?>
					 >
                                                     <? print $MSG_030; ?> 
                                                    <input type="radio" name="newsbox" value="2"
					 <? if($SETTINGS['newsbox'] == 2) print " CHECKED";?>
					 >
                                                     <? print $MSG_029; ?> <br>
                                                    <? print $MSG_554; ?> <br>
                                                    <input type="text" name="newstoshow" size="5" maxlength="10" value="<?=$SETTINGS['newstoshow']?>">
                                                     </td>
                                            </tr>
											<tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
											<!--Show closed auctions -->
											<tr valign="TOP">
                                                <td width=169 height="61"> <? print $MSG_33_0000; ?> </td>
                                                <td width="393" height="61">  <? print $MSG_33_0001; ?> <br>
                                                    <input type="radio" name="show_closed_auctions" value="1"
													<? if($SETTINGS['show_closed_auctions'] == 1) print " CHECKED";?>
													>
                                                     <? print $MSG_030; ?> 
                                                    <input type="radio" name="show_closed_auctions" value="2"
													<? if($SETTINGS['show_closed_auctions'] == 2) print " CHECKED";?>
													>
                                                     <? print $MSG_029; ?> <br>
                                                 </td>
                                            </tr>
											<!-- end show closed auctions-->
											<tr valign="TOP">
                                                <td colspan="2" bgcolor="eeeeee"><img src="../images/transparent.gif" width="1" height="5"></td>
                                            </tr>
											
                                            <tr>
                                                <td width=169>
                                                    <input type="hidden" name="action" value="update">
                                                </td>
                                                <td width="393">
                                                    <input type="submit" name="act" value="<? print $MSG_530; ?>">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width=169></td>
                                                <td width="393"> </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>
