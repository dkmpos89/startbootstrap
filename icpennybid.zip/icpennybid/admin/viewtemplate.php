<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";

#// REtrieve template from the database
$query = "SELECT code FROM BPPENNYAUTOBID_aboutmetemplates WHERE id=$_GET[id]";
$res = mysql_query($query);
if(!$res)
{
	print "$query<BR>".mysql_error();
	exit;
}
elseif(mysql_num_rows($res) > 0)
{
	print stripslashes(mysql_result($res,0,"code"));
}
else
{
	print "Unable to retrieve template.";
}
?>
