<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";
include_once $include_path.'time.inc.php';

unset($ERR);

#//
if($_POST[action] == "update" && basename($_SERVER['HTTP_REFERER']) == basename($_SERVER['PHP_SELF']))
{
	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
		$ERR = $ERR_9999;
	}else{
	#// Update database
	$query = "update BPPENNYAUTOBID_settings SET
				  faq='".addslashes($_POST[faq])."',
				  faq_page='".addslashes($_POST["faq_page"])."'";
	$res = @mysql_query($query);
	if(!$res)
	{
		print "Error: $query<BR>".mysql_error();
		exit;
	}
	else
	{
		$ERR = $MSG_5079;
		$SETTINGS = $_POST;
	}
	}
}


#//
$query = "SELECT faq, faq_page FROM BPPENNYAUTOBID_settings";
$res = @mysql_query($query);
if(!$res)
{
	print "Error: $query<BR>".mysql_error();
	exit;
}
elseif(mysql_num_rows($res) > 0)
{
	$SETTINGS = mysql_fetch_array($res);
}
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='style.css' />
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_con.gif" ></td>
          <td class=white><?=$MSG_25_0018?>&nbsp;&gt;&gt;&nbsp;FAQ</td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD align="center">
<BR>
<FORM NAME=conf ACTION=<?=basename($_SERVER['PHP_SELF'])?> METHOD=POST>
	<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95">
		<TR>
			<TD ALIGN=CENTER class=title>
				FAQ
				</TD>
		</TR>
		<TR>
			<TD>

<TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
  <?
  if(isset($ERR))
  {
  ?>
  <TR BGCOLOR=yellow>
	<TD class=error COLSPAN="2" ALIGN=CENTER><? //print $ERR; ?>FAQ Settings updated</TD>
  </TR>
  <?
  }
  ?>
  <TR VALIGN="TOP">
	<TD WIDTH=109 HEIGHT="22">
	  Activate FAQ page?</TD>
	<TD WIDTH="375" HEIGHT="22">
	  Activate this option if you want a FAQ link to appear in the footer of your pages<BR>
	  <INPUT TYPE="radio" NAME="faq" VALUE="y" <?if($SETTINGS[faq] == "y") print " CHECKED"?>>
	  <? print $MSG_030; ?>
	  <INPUT TYPE="radio" NAME="faq" VALUE="n" <?if($SETTINGS[faq] == "n") print " CHECKED"?>>
	  <? print $MSG_029; ?>
	  </TD>
  </TR>
   <tr>
     <td align="right" width="25%" valign="top" class="leftpan"><b>
            <?=$MSG_018;?>
            </b> </td>
        <td class="rightpan">
		<script type="text/javascript" src="scripts/wysiwyg.js" ></script>
        <textarea id="faq_page" name="faq_page"  style="width:90%; height: 100px;"><?=stripslashes($SETTINGS["faq_page"])?></textarea>
		<script>generate_wysiwyg('faq_page');</script>
        </td>
    </tr>
  <TR VALIGN="TOP">
	<TD WIDTH=109 HEIGHT="22">&nbsp;</TD>
	<TD WIDTH="375" HEIGHT="22">&nbsp;</TD>
  </TR>
  <TR>
	<TD WIDTH=109>
	  <INPUT TYPE="hidden" NAME="action" VALUE="update">
	</TD>
	<TD WIDTH="375">
	  <INPUT TYPE="submit" onclick="updateTextArea('faq_page');" NAME="act" VALUE="<? print $MSG_530; ?>">
	</TD>
  </TR>
  <TR>
	<TD WIDTH=109></TD>
	<TD WIDTH="375"> </TD>
  </TR>
</TABLE>
			</TD>
		</TR>
	</TABLE>
	</FORM>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>