<?

reset($LANGUAGES);
while(list($k,$v) = each($LANGUAGES)){
	include_once "../includes/messages.".$k.".inc.php";
	$result = mysql_query ( "SELECT distinct c.cat_id, t.cat_name FROM BPPENNYAUTOBID_categories c, BPPENNYAUTOBID_cats_translated t WHERE c.parent_id='0' AND c.deleted=0 AND c.cat_id=t.cat_id AND t.lang='".$k."' ORDER BY cat_name" );
	//echo "SELECT distinct c.cat_id, t.cat_name FROM BPPENNYAUTOBID_categories c, BPPENNYAUTOBID_cats_translated t WHERE c.parent_id='0' AND c.deleted=0 AND c.cat_id=t.cat_id AND t.lang='".$k."' ORDER BY cat_name";
	$output = "<SELECT NAME=\"id\">\n";
	$output.= "<OPTION VALUE=\"\">$MGS_2__0038</OPTION>\n";
	$output.= "<OPTION VALUE=\"\"></OPTION>\n";

	if ($result)
		$num_rows = mysql_num_rows($result);
	else
		$num_rows = 0;

	$i = 0;
	while($i < $num_rows){
		$category_id = mysql_result($result,$i,"cat_id");
		$cat_name = mysql_result($result,$i,"cat_name");
		$output .= "	<OPTION VALUE=\"$category_id\">$cat_name</OPTION>\n";
		$i++;
	}

	$output.= "	<OPTION VALUE=\"\"></OPTION>\n";
	$output.= "	<OPTION VALUE=\"0\">$MSG_292</OPTION>\n";
	$output.= "</SELECT>\n";

	$handle = fopen ( "../includes/categories_select_box.".$k.".inc.php" , "w" );
	fputs ( $handle, $output );
	fclose ($handle);
}

 $catid=""
function drawCategories($parent_id, $catlistids="",$level=0) {
global $catid;
     $result = mysql_query("SELECT cat_id,cat_name FROM BPPENNYAUTOBID_categories WHERE parent_id='".$parent_id."' ORDER BY cat_name");
     while ($line = mysql_fetch_array($result)) {
	     if($catid!="") { $catid .= "<br/>"; }
		 $spaces="";
		 for($i=0;$i<$level;$i++) $spaces .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	     $catid .= $spaces.$line["cat_name"];
		 
		 drawCategories($line["cat_id"], $catid,$level+1);
     }
     return $catid;
}
//echo drawCategories(0);

?>