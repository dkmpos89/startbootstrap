<HTML>
<HEAD>
<TITLE>Untitled Document</TITLE>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<STYLE type="text/css">
<!--
.bluelink {  font: 10pt Verdana, Arial, Helvetica, sans-serif; color: 000066; text-decoration: none}
-->
</STYLE></HEAD>

<BODY bgcolor="#FFFFFF">
<CENTER>
  <P><B><FONT face="Verdana, Arial, Helvetica, sans-serif" size="4" color="#000066">Categories
    table</FONT></B> </P>
  <TABLE width="352" border="0" cellspacing="0" cellpadding="0">
    <TR>
      <TD>
        <P><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">To edit
          the categories table you have to navigate the categories hierarchy.<BR>
          Use the <IMG src="../images/plus.gif" width="11" height="11"> symbol
          to browse the subcategories tree under a specific category.</FONT></P>
        <P><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">In each
          level you'll be able to add a new category, edit the categories description
          and delete one or more categories.</FONT></P>
        <P><FONT face="Verdana, Arial, Helvetica, sans-serif" size="2">Note: only
          a category under which (or under its subcategories) there are no active
          auctions can be deleted. The DELETE checkbox only appear for those categories
          which can be deleted.<BR>
          Deleting a category will automatically delete all the subcategories.<BR>
          Deleted categories will be only &quot;marked&quot; as delete and will
          be available anyway for closed auction.</FONT></P>
        <P align="center"><A href="javascript:window.close()" class="bluelink">Close</A></P>
        <CENTER>
        </CENTER>
        </TD>
    </TR>
  </TABLE>
  </CENTER>
</BODY>
</HTML>
