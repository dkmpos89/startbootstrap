<?

include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once $include_path."countries.inc.php";

$username = $name;
//-- Data check
if(!$_REQUEST[id]) {
	$URL = $_SESSION["RETURN_LIST"]."?offset=".$_SESSION['RETURN_LIST_OFFSET'];
    unset($_SESSION["RETURN_LIST"]);
    header("Location: $URL");
    exit;
}

/*
*        If script is called to actually make modifications
*        (ie on first invocation this script just displays some HTML
*         on the second it tries to modify the database).
*/

if($_POST['action'] && strstr(basename($_SERVER['HTTP_REFERER']),basename($_SERVER['PHP_SELF']))) {
    
    $query="";
    if(isset($_POST["ntxt"])) {
        foreach($_POST["ntxt"] as $k=>$v) {
            if(empty($v) && isset($txt[$k]) && !empty($txt[$k])) {
                $query.=",txt$k=\"".urldecode($txt[$k])."\"";
            } else $query.=",txt$k=\"$v\"";
            
        }
    }
    if(isset($_POST["nnum"])) {
        foreach($_POST["nnum"] as $k=>$v) {
            if(empty($v) && isset($num[$k]) && !empty($num[$k])) {
                $query.=",num$k=\"".$num[$k]."\"";
            } else $query.=",num$k=\"$v\"";
        }
    }
	
    //echo "111 ";
    //print_r($_POST);
    
    // Check that all the fields are not NULL
    //print_r($_POST);
	
	if ($_POST["id"] && $_POST["title"] && $_POST["date"] && isset($_POST["duration"]) &&
        $_POST["description"] && $_POST["country"])
    {	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
		echo $ERR = $ERR_9999;
	}else{
         
         //if (isset($_POST["uploaded"])&& $_POST["uploaded"]!="") echo "<script>alert('ok');</script>";
        //echo "222 ";
        
       /*removed 28 may
         $DATE = explode("/",$_POST["date"]);
        if($SETTINGS[datesformat] == "USA") {
          $tmp_day          = $DATE[1];
          $tmp_month        = $DATE[0];
          $tmp_year         = $DATE[2];
        } else {
          $tmp_day          = $DATE[0];
          $tmp_month        = $DATE[1];
          $tmp_year         = $DATE[2];
        }*/

        /*
        *         Check the input values for validity.
        */
        
        /*removed 28 may
        if(strlen($tmp_year) == 2) {
            $tmp_year = "19".$tmp_year;
        }
        */
        /*removed 28 may
        if (!preg_match("^[0-9]{2}/[0-9]{2}/[0-9]{4}$",$_POST["date"]) &&
        !preg_match("^[0-9]{2}/[0-9]{2}/[0-9]{2}$",$_POST["date"])) { //date check
          echo $ERR = "ERR_700";
        } else
        */
        
        /*if (!1==1) { //date check
          echo $ERR = "ERR_700";
        }*/ /*elseif ($_POST["quantity"] < 1) { // 1 or more items being sold
          echo $ERR = "ERR_701";
        //} else if ($_POST["current_bid"] > $_POST["min_bid"] && $_POST["current_bid"] != 0) {    // bid > min_bid
        //  echo $ERR = "ERR_702";

        // bid_value must be valid float number
        }*/   if (!preg_match("#^(\+?((([0-9]+(\.)?)|([0-9]*\.[0-9]+))([eE][+-]?[0-9]+)?))$#",$_POST["item_value"])) { 
            echo $ERR = "Worth must be a positive number!";
        } else {
            /*
            #// Retrieve auction's data
            $query = "SELECT * from BPPENNYAUTOBID_auctions where id='".$_POST["id"]."'";
            $res = @mysql_query($query);
            if(!$res) {
                MySQLError($query);
                exit;
            } elseif(mysql_num_rows($res) == 0) {
                print $ERR_606;
                exit;
            } else {
                $AUCTION = mysql_fetch_array($res);
                $T = mktime(substr($AUCTION['starts'], 8, 2),
                    substr($AUCTION['starts'], 10, 2),
                    substr($AUCTION['starts'], 12, 2),
                    $tmp_month,
                    $tmp_day,
                    $tmp_year);
				$a_ends = $T+($_POST[duration]*24*60*60);
                $a_ends = date("YmdHis", $a_ends);
                
            }

			//echo "111 ";
            $time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),$tmp_month, $tmp_day,$tmp_year);
            $date = date("YmdHis",$time);
            */
            
            
            //time update
           
            $time = mktime(substr($_POST["date"], 11, 2),
            substr($_POST["date"], 14, 2),
            substr($_POST["date"], 17, 2),
            substr($_POST["date"], 5, 2),
            substr($_POST["date"], 8, 2),
            substr($_POST["date"], 0, 4));
            
            //$t = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),substr($_POST["date"], 4, 2), substr($_POST["date"], 6, 2),substr($_POST["date"], 0, 4));
            $a_starts = date("YmdHis",$time);
            
            // auction ends
            //$a_ends = $time+$_POST["duration"]*24*60*60;
            //$a_ends = date("YmdHi", $a_ends)."01";  // we want auction end time will be at first second

			$a_ends = $time + $_POST["duration"] * 24 * 60 * 60+$_POST["duration_hours"]*60*60+$_POST["duration_minutes"]*60;
			$a_ends = date("YmdHis", $a_ends); // we want auction end time will be at first second
			
            //exit;
            // second phase starts & ends
           $a_starts_second = $a_ends;
           $time_second = mktime( substr($a_starts_second, 8, 2), 
           substr($a_starts_second, 10, 2),
           substr($a_starts_second, 12, 2),
           substr($a_starts_second, 4, 2),
           substr($a_starts_second, 6, 2),
           substr($a_starts_second, 0, 4));
           $a_ends_second = $time_second + $_POST["second_duration"]*60;
           $a_ends_second = date("YmdHis", $a_ends_second);
            
            
       #// upload or delete main image      
        
        $imgname="no_change";
         if (isset($_POST["delete_img"]) && $_POST["delete_img"]=="delete") $imgname="";
         //if (isset($_POST["uploaded"]) && $_POST["uploaded"]!="")
         if (isset($_POST["file_upl"]))
         {
                $target = "../uploaded/";
                $now =date("Y-m-d-H-i-s");
                $filename="auction_".$now.".".substr(basename( $_FILES['uploaded']['name']),strlen(basename( $_FILES['uploaded']['name']))-3);
                //echo basename($_FILES['uploaded']['name']);
                //$filename="a_".$now.".". $_FILES['uploaded']['name'];
                $target = $target.$filename;
                // echo "<script>alert('hi');</script>";
                //echo $target;
                if(move_uploaded_file($_FILES['uploaded']['tmp_name'],$target))
                  {
                     //echo "all right";
                     chmod("$target",0766);
                     $imgname=$filename;
                      //echo $imgname;
                  } 
                else {
                     //echo $target;
                     //echo "Sorry, there was a problem uploading your file.";
                     $imgname="";
                     }
        
         }
        
        
        
        
        
            
        #// Create pictures gallery if any
        //echo $SETTINGS['picturesgallery']."==".count($UPLOADED_PICTURES)."==".$GALLERY_UPDATED;
        $auction_id=$_POST["id"];

        $UPLOADED_PICTURES=$_SESSION["UPLOADED_PICTURES"];
        $UPLOADED_PICTURES_SIZE=$_SESSION["UPLOADED_PICTURES_SIZE"];
        $GALLERY_UPDATED=$_SESSION["GALLERY_UPDATED"];
        if($SETTINGS['picturesgallery'] == 1 && @count($UPLOADED_PICTURES)> 0 && $GALLERY_UPDATED)  {
          #// Create dirctory
          umask();
          if(!is_dir("../".$uploaded_path.$auction_id)) {
            //echo "1. ".$uploaded_path.$auction_id;
            //exit;
            mkdir("../".$uploaded_path.$auction_id,0777);
        } else {
           //echo "2. ".$uploaded_path.$auction_id;
          // exit;
          if ($dir = @opendir("../".$uploaded_path.$auction_id)) {
             while (($file = readdir($dir)) !== false) {
                if (!is_dir("../".$uploaded_path.$auction_id."/".$file))
                   @unlink("../".$uploaded_path.$auction_id."/".$file);
              }
              @closedir($dir);
           }
          }
           #// Copy files
          while(list($k,$v) = each($UPLOADED_PICTURES)) {
          //echo "<br>3. ../".$uploaded_path.session_id()."/".$v."==../".$uploaded_path.$auction_id."/".$v;
          @copy("../".$uploaded_path.session_id()."/$v","../".$uploaded_path.$auction_id."/".$v);
          @chmod("../".$uploaded_path.$auction_id."/".$v,0777);
          @unlink("../".$uploaded_path.session_id()."/$v");
           }
    
           #// Delete files, using dir (to eliminate eventual odd files)
          if ($dir = @opendir($uploaded_path.session_id())) {
            while (($file = readdir($dir)) !== false) {
              if (!is_dir($uploaded_path.session_id()."/".$file))
                 @unlink($uploaded_path.session_id()."/".$file);
            }
            @closedir($dir);
          }
          @rmdir($uploaded_path.session_id());
       }
        #// Unset gallery variables
        unset($UPLOADED_PICTURES);
        unset($UPLOADED_PICTURES_SIZE);
        unset($GALLERY_UPDATED);
        unset($_SESSION["UPLOADED_PICTURES"]);
        unset($_SESSION["UPLOADED_PICTURES_SIZE"]);
        unset($_SESSION["GALLERY_UPDATED"]);
            
            
            
            
            
            
			//echo "222 ";
            $sql="UPDATE BPPENNYAUTOBID_auctions SET title=\"".AddSlashes($_POST["title"])."\",
                starts=\"".AddSlashes($a_starts)."\",
                ends=\"".AddSlashes($a_ends)."\",
                duration=\"".AddSlashes($_POST["duration"])."\",
                second_starts=\"".AddSlashes($a_starts_second)."\",
                second_ends=\"".AddSlashes($a_ends_second)."\",
                description=\"".AddSlashes($_POST["description"])."\",
                location=\"".AddSlashes($_POST["country"])."\",
                item_value=\"". AddSlashes($_POST["item_value"])."\"
                WHERE id=".AddSlashes($_POST["id"])."";
            
            $res=mysql_query ($sql);
            
            if (!$res) {
                print "Database error on update: " . mysql_error();
                exit;
            } else {
                if ($imgname!="no_change") {
                  $sql2="UPDATE BPPENNYAUTOBID_auctions SET pict_url='".$imgname."' where id='".AddSlashes($_POST["id"])."'";
                  $res2=mysql_query ($sql2);
                }
				//echo "333 ";
                $updated = 1;
            }
                
                $URL = $_SESSION["RETURN_LIST"]."?offset=".$_SESSION['RETURN_LIST_OFFSET'];
                unset($_SESSION["RETURN_LIST"]);
                header("Location: $URL");
                exit;
        }
    }
    } else {
        // COUNTRIES
        
        $country_list="";
        while (list ($code, $descr) = each ($countries)) {
            $country_list .= "<option value=\"$descr\"";
            if ($descr == $country) {
                $country_list .= " selected";
            }
            $country_list .= ">$descr</option>\n";
        }
        // NICKS (usernames)
        
        $userid_list = ""; // empty string to begin HTML list
        $userid_query = "select id, nick from BPPENNYAUTOBID_users";
        $res_q = mysql_query($userid_query);
        if(!$res_q) {
            print "Database access error: abnormal termination".mysql_error();
            exit;
        }
        while($row = mysql_fetch_array($res_q)) {
            $userid_list .= "<option value='".$row['id']."'";
            if ($row['id'] == $userid) {
                $userid_list .= " selected ";
            }
            $userid_list .= ">".$row['nick']."</option>\n";
        }
        
        
        // DURATIONS
        
        $dur_list = ""; // empty string to begin HTML list
        $dur_query = "select days, description from BPPENNYAUTOBID_durations";
        $res_d = mysql_query($dur_query);
        if(!$res_d) {
            print "Database access error: abnormal termination".mysql_error();
            exit;
        }
        for ($i = 0; $i < mysql_num_rows($res_d); $i++) {
            $row = mysql_fetch_row($res_d);
            // 0 is days, 1 is description
            // Append to the list
            $dur_list .= "<option value=\"$row[0]\"";
            // If this Durations # of days coresponds to the duration of this
            // auction, select it
            if ($row[0] == $duration) {
                $dur_list .= " selected ";
            }
            $dur_list .= ">$row[1]</option>\n";
        }
        
        $ERR = "ERR_112";
    }
    
}

if(!$_POST["action"] || ($_POST["action"] && !$updated)) {
    
    /*
    *        Make a large SQL query getting values from the "auctions"
    *        table and corresponding values that are indexed in other tables
    *         and displaying them both (and allowing the admin to change
    *        only the proper indexed values.
    */
    $query = "SELECT a.id,  
                a.title, a.starts, a.description, a.item_value, a.bid_value,
                a.category,  a.duration as duration, d.description as
                dur_description, a.second_duration, a.suspended, a.current_bid,
                a.quantity, a.reserve_price, a.buy_now, a.location, a.minimum_bid, a.pict_url, a.auction_type
                FROM BPPENNYAUTOBID_auctions a, 
				BPPENNYAUTOBID_durations d
                WHERE 
                d.days = a.duration
                AND a.id='".$_REQUEST["id"]."'";
				//echo $query;
    $result = mysql_query($query);
    //u.id = a.user   AND 
    if(!$result) {
        print "Database access error: abnormal termination".mysql_error();
        exit;
    }
    
    $id = mysql_result($result,0,"id");
    $title = stripslashes(mysql_result($result,0,"title"));
    $tmp_date = mysql_result($result,0,"starts");
    $duration = mysql_result($result,0,"duration");
    $category = mysql_result($result, 0, "category");
    $cat_description = stripslashes(mysql_result($result,0,"cat_name"));
    $description = stripslashes(mysql_result($result,0,"description"));
    $img_url=stripslashes(mysql_result($result,0,"pict_url"));
    $suspended = mysql_result($result,0,"suspended");
    $current_bid = mysql_result($result,0,"current_bid");
    $min_bid = mysql_result($result,0,"minimum_bid");
    $quantity = mysql_result($result,0,"quantity");
    $reserve_price = mysql_result($result,0,"reserve_price");
    $buy_now = mysql_result($result,0,"buy_now");
    $country = mysql_result($result, 0, "location");
    $item_value = mysql_result($result, 0, "item_value");
    $bid_value = mysql_result($result, 0, "bid_value");
    $auction_type = mysql_result($result, 0, "auction_type");
    $second_duration = mysql_result($result, 0, "second_duration");
    
    
    
    
    /*take out image gallery*/
        unset($_SESSION["GALLERY_UPDATED"]);
        unset($_SESSION["UPLOADED_PICTURES"]);
        unset($_SESSION["UPLOADED_PICTURES_SIZE"]);
        if(is_dir($image_upload_path.$id)) {
          umask();
          if(!file_exists($image_upload_path.session_id())) {
            umask();
            mkdir($image_upload_path.session_id(),0777);
          }
          #// Move uploaded file into TMP directory
          $dir=@opendir($image_upload_path.$id);
          while ($file=readdir($dir)) {
            if(!is_dir($image_upload_path.$id."/".$file)) {
              $isz=@getimagesize($image_upload_path.$id."/".$file);
              if(is_array($isz)) {
                copy($image_upload_path.$id."/".$file,
                $image_upload_path.session_id()."/".$file);
                chmod($image_upload_path.session_id()."/".$file,0777);
                #//Populate arrays
                $UPLOADED_PICTURES[] = $file;
                $UPLOADED_PICTURES_SIZE[] = filesize($image_upload_path.session_id()."/".$file);
              }
            }
          }
          $_SESSION["UPLOADED_PICTURES"] = $UPLOADED_PICTURES;
          $_SESSION["UPLOADED_PICTURES_SIZE"] = $UPLOADED_PICTURES_SIZE;
          $_SESSION["GALLERY_UPDATED"]=true;
          
        }
    
    
    
    
    /*
    *         For all list-like items we create drop-down
    *        lists and select the index listed in the auction table.
    *        for this auction.
    */
    // NICKS (usernames)
    
    $userid_list = ""; // empty string to begin HTML list
    $userid_query = "select id, nick from BPPENNYAUTOBID_users";
    $res_q = mysql_query($userid_query);
    if(!$res_q) {
        print "Database access error: abnormal termination".mysql_error();
        exit;
    }
    while($row = mysql_fetch_array($res_q)) {
        $userid_list .= "<option value='".$row['id']."'";
        if ($row['id'] == $userid) {
            $userid_list .= " selected ";
        }
        $userid_list .= ">$row[1]</option>\n";
    }
    
    // DURATIONS
    $dur_list = ""; // empty string to begin HTML list
    $dur_query = "SELECT days, description FROM BPPENNYAUTOBID_durations";
    $res_d = mysql_query($dur_query);
    if(!$res_d) {
        print "Database access error: abnormal termination".mysql_error();
        exit;
    }
    for ($i = 0; $i < mysql_num_rows($res_d); $i++) {
        $row = mysql_fetch_row($res_d);
        // 0 is days, 1 is description
        // Append to the list
        $dur_list .= "<option value=\"$row[0]\"";
        // If this Durations # of days coresponds to the duration of this
        // auction, select it
        if ($row[0] == $duration) {
            $dur_list .= " selected ";
        }
        $dur_list .= ">$row[1]</option>\n";
    }
    
    // CATEGORIES
    //$T=        "<SELECT NAME=\"category\">\n";
    //$categ = mysql_query("SELECT * FROM BPPENNYAUTOBID_categories_plain");
    //if($categ) {
    //    while($categ_result=mysql_fetch_array($categ)) {
    //        $T.=
    //        "        <OPTION VALUE=\"".
    //        $categ_result['cat_id'].
    //        "\" ".
    //        (($categ_result['cat_id']==$category)?"SELECTED":"")
    //        .">".$categ_result['cat_name']."</OPTION>\n";
    //    }
    //}
    //$T.="</SELECT>\n";
    $T= "<INPUT TYPE='hidden' NAME='category' ";
    $categ = mysql_query("SELECT * FROM BPPENNYAUTOBID_categories_plain LIMIT 1");
    if($categ)
	{
        while($categ_result=mysql_fetch_array($categ))
		{
            $T.="VALUE='".$categ_result['cat_id']."' >";
        }
    }    
    $TPL_categories_list = $T;
    
    $country_list="";
    while (list ($code, $descr) = each ($countries)) {
        $country_list .= "<option value=\"$descr\"";
        if ($descr == $country) {
            $country_list .= " selected";
        }
        $country_list .= ">$descr</option>\n";
    }
    
    $date = mysql_result($result,0,"starts");
    
    $tmp_day = substr($date,6,2);
    $tmp_month = substr($date,4,2);
    $tmp_year = substr($date,0,4);
    $tmp_hour = substr($date,8,2);
    $tmp_minute = substr($date,10,2);
    $tmp_second = substr($date,12,2);
    $date = "$tmp_year-$tmp_month-$tmp_day $tmp_hour:$tmp_minute:$tmp_second";
    //if($SETTINGS[datesformat] == "USA") {
     // $date = "$tmp_month/$tmp_day/$tmp_year";
   // } else {
    //  $date = "$tmp_day/$tmp_month/$tmp_year";
   // }
}
$query = "select * from BPPENNYAUTOBID_durations order by days";
	$res = mysql_query($query);
	if(!$res)
	{
		MySQLError($query);
		exit();
	}
	$TPL_start_date = $a_starts;
	$TPL_durations_list = "<SELECT NAME=\"duration\">\n";
	while($row = mysql_fetch_assoc($res))
	{
		$TPL_durations_list .= "  <OPTION VALUE='" . $row["days"] . "' " . (($row["days"] == $duration) ? "SELECTED" : "") . ">" . $row["description"] . "</OPTION>";
	}
	$TPL_durations_list .= "</SELECT>\n";
	//Duration hours & minutes
	$TPL_durations_list .= "
      &nbsp;
      $MSG_31_0071
      <SELECT name='duration_hours'>
         <OPTION value='00'>0</OPTION>
         <OPTION value='01'>1</OPTION>
         <OPTION value='02'>2</OPTION>
         <OPTION value='03'>3</OPTION>
         <OPTION value='04'>4</OPTION>
         <OPTION value='05'>5</OPTION>
         <OPTION value='06'>6</OPTION>
         <OPTION value='07'>7</OPTION>
         <OPTION value='08'>8</OPTION>
         <OPTION value='09'>9</OPTION>
         <OPTION value='10'>10</OPTION>
         <OPTION value='11'>11</OPTION>
         <OPTION value='12' selected>12</OPTION>
         <OPTION value='13'>13</OPTION>
         <OPTION value='14'>14</OPTION>
         <OPTION value='15'>15</OPTION>
         <OPTION value='16'>16</OPTION>
         <OPTION value='17'>17</OPTION>
         <OPTION value='18'>18</OPTION>
         <OPTION value='19'>19</OPTION>
         <OPTION value='20'>20</OPTION>
         <OPTION value='21'>21</OPTION>
         <OPTION value='22'>22</OPTION>
         <OPTION value='23'>23</OPTION>
      </SELECT>
      &nbsp;
      $MSG_31_0072
      <SELECT name='duration_minutes'>
         <OPTION value='00' selected>00</OPTION>
         <OPTION value='05'>05</OPTION>
         <OPTION value='10'>10</OPTION>
         <OPTION value='15'>15</OPTION>
         <OPTION value='20'>20</OPTION>
         <OPTION value='25'>25</OPTION>
         <OPTION value='30'>30</OPTION>
         <OPTION value='35'>35</OPTION>
         <OPTION value='40'>40</OPTION>
         <OPTION value='45'>45</OPTION>
         <OPTION value='50'>50</OPTION>         
         <OPTION value='55'>55</OPTION>
      </SELECT>";
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='style.css' />

<script language="Javascript" type="text/javascript" src="includes/calendar.js"></script>
<script language=Javascript>
function window_open(pagina,titulo,ancho,largo,x,y){
    var Ventana= 'toolbar=0,location=0,directories=0,scrollbars=1,screenX='+x+',screenY='+y+',status=0,menubar=0,resizable=0,width='+ancho+',height='+largo;
    open(pagina,titulo,Ventana);
}
</script>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_auc.gif" ></td>
          <td class=white><?=$MSG_239?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_512?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95" ALIGN="CENTER">
  <TR>
    <TD ALIGN=CENTER class=title><? print $MSG_512; ?></TD>
  </TR>
  <TR>
    <TD><FORM NAME=details ACTION="<? print basename($_SERVER['PHP_SELF']); ?>" METHOD="POST" enctype="multipart/form-data">
    <TABLE WIDTH="100%" BORDER="0" CELLPADDING="5" BGCOLOR="#FFFFFF">
                <?
                if($ERR || $updated){
                    print "<TR><TD></TD><TD WIDTH=486>";
                    if($$ERR) print $$ERR;
                    if($updated) print "Auction data updated";
                    print "</TD>
                </TR>";
                }
                ?>
                
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_312 *"; ?> </TD>
                  <TD WIDTH="486">
					<INPUT TYPE=text NAME=title SIZE=40 MAXLENGTH=255 VALUE="<? print $title; ?>">
					<INPUT TYPE=hidden NAME=userid VALUE="0">
                  </TD>
                </TR>
                <!--<TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_313 *"; ?> </TD>
                  <TD WIDTH="486"><SELECT NAME=userid>
                      <OPTION VALUE=""> </OPTION>
                      <?  echo $userid_list; ?>
                    </SELECT>
                  </TD>
                </TR>-->
				
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print " $MSG_314 *"; ?> </TD>
                  <TD WIDTH="486">
                        <INPUT TYPE=text NAME=date ID="date" SIZE=20 MAXLENGTH=20 VALUE="<? echo $date; ?>">
                        <a href="javascript:pubdate_cal.popup()"><img src="../includes/img/calendar.gif" width="16" height="16" border="0" alt="Click Here to Pick up the date" /></a>
                        <script language="JavaScript">
                            var pubdate_cal = new xar_base_calendar(document.getElementById("date"), "."); pubdate_cal.year_scroll = true; pubdate_cal.time_comp = true;
                        </script>
                  </TD>
                </TR>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_315 *"; ?> </TD>
                  <TD WIDTH="486"><!--<SELECT NAME=duration>
                      <OPTION VALUE=""> </OPTION>
                      <?  //echo $dur_list; ?>
                    </SELECT>-->
					<?=$TPL_durations_list ?>
                  </TD>
                </TR>
                <?php if ($auction_type==2 || $auction_type==3){?>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right">Durata (secondo phase) </TD>
                  <TD WIDTH="486"><?  echo $second_duration; ?>&nbsp;min
                  </TD>
                </TR>
                <?php }?>
                <tr><td colspan="2"><input type="hidden" id="second_duration" value="<?  echo $second_duration; ?>"></td></tr>
                <!--<TR>
                  <TD WIDTH="204"  VALIGN="top" ALIGN="right"><? print "$MSG_316 *"; ?> </TD>
                  <TD WIDTH="486"><? print $TPL_categories_list; ?> </TD>
                </TR>-->
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_317 *"; ?> </TD>
                  <TD WIDTH="486">
			<script type="text/javascript" src="scripts/wysiwyg.js" ></script>
			<TEXTAREA NAME="description" ID="description" COLS="40" ROWS="8"><? echo $description; ?></TEXTAREA>
		        <script>generate_wysiwyg('description');</script>
                  </TD>
                </TR>
                <!------------------------- item variants ------------------>
                <?
                if ($TPL_auction_variant!="") {
                ?>
                <TR>
                  <TD WIDTH="204" VALIGN="middle" ALIGN="right"><?print $MSG_25_0071;?></TD>
                  <TD WIDTH="486"><? print $TPL_auction_variant; ?> </TD>
                </TR>
                <?
                }
                ?>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_014 *"; ?> </TD>
                  <TD WIDTH="486"><SELECT NAME=country>
                      <OPTION VALUE=""> </OPTION>
                      <?  echo $country_list; ?>
                    </SELECT>
                  </TD>
                </TR>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right">Main Image </TD>
                  <TD WIDTH="486">
                      <?  if ($img_url!="") {?>
                      <table><tr>
                        <td><img height="100px"  width="100px" src="../uploaded/<?php echo $img_url;?>"></td>
                        <td valign="top"><input type="checkbox" name="delete_img" id="delete_img" value="delete" /> delete</td>
                      </tr></table>  
                        <? } else {?>
                        <input type="file" id="uploaded" size="20" name="uploaded" />
                        <input type="hidden" name="file_upl" value="file_upl">
                        <?php }?>
                        <?=$MSG_5408.$SETTINGS['maxuploadsize']." bytes";?>
                        <input type=HIDDEN name="MAX_FILE_SIZE" value="<? print $SETTINGS['maxuploadsize']; ?>" />
                  </TD>
                </TR>
                   <?
                    if($SETTINGS['picturesgallery'] == 1)
                    {
                    ?>
                    <tr>
                        <td align="right" width="25%" valign="middle" class="leftpan">&nbsp;</td>
                        <td valign="top" class="rightpan">
                            <h3><?
                            print $MSG_663."</h3>";
                            print $MSG_673."&nbsp;".$SETTINGS['maxpictures']."&nbsp;".$MSG_674;
                            if($SETTINGS['picturesgalleryfee'] == 1 )
                            {
                                print $MSG_675."&nbsp;".print_money($SETTINGS['picturesgalleryvalue'])."&nbsp;".$MSG_676;
                            }
                            ?>
                             <br>
                            [<a href="javascript:window_open('upldgallery.php','gallery',400,500,20,20)">
                            <?=$MSG_677?>
                            </a>] </td>
                    </tr>
                    <?
                    }
                    ?>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "Worth:"; ?> </TD>
                  <TD WIDTH="486">
                    <INPUT TYPE=text NAME="item_value" SIZE=40 MAXLENGTH=40 VALUE="<? echo $item_value; ?>"> <?=$SETTINGS['currency']?>
                  </TD>
                </TR>
                <!--<TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_327 *"; ?> </TD>
                  <TD WIDTH="486">
					<label>0.01 &euro;</label>
                    <INPUT TYPE=hidden readonly TYPE=text NAME="min_bid" SIZE=40 value='0.01' />
					<INPUT TYPE=hidden NAME="min_bid" SIZE=40 MAXLENGTH=40 VALUE="<? echo $quantity; ?>">
					<INPUT TYPE=hidden NAME="min_bid" SIZE=40 MAXLENGTH=40 VALUE="<? echo $reserve_price; ?>">
					<INPUT TYPE=hidden NAME="min_bid" SIZE=40 MAXLENGTH=40 VALUE="<? echo $buy_now; ?>">
                    <INPUT TYPE=hidden NAME="quantity" SIZE=40 MAXLENGTH=40 value='1' /></TD>
                    <INPUT readonly TYPE=hidden NAME="current_bid" SIZE=15 MAXLENGTH=15 VALUE="<? echo $current_bid; ?>">

                </TR>-->
                <!--<TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_319 *"; ?> </TD>
                  <TD WIDTH="486"><INPUT TYPE=text NAME="quantity" SIZE=40 MAXLENGTH=40 VALUE="<? //echo
                //$quantity; ?>">
                  </TD>
                </TR>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_320 *"; ?> </TD>
                  <TD WIDTH="486"><INPUT TYPE=text NAME="reserve_price" SIZE=40 MAXLENGTH=40 VALUE="<? //echo
                //$reserve_price; ?>">
                  </TD>
                </TR>
                <TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_497 *"; ?> </TD>
                  <TD WIDTH="486"><INPUT TYPE=text NAME="buy_now" SIZE=40 MAXLENGTH=40 VALUE="<? echo
                $buy_now; ?>">
                  </TD>
                </TR>-->
                <!--<TR>
                  <TD WIDTH="204" VALIGN="top" ALIGN="right"><? print "$MSG_300"; ?> </TD>
                  <TD WIDTH="486">
                  <?
                  /*if($suspended == 0)
                  print "$MSG_029";
                  else
                  print "$MSG_030";*/
                  ?>
                  </TD>
                </TR>-->
                <TR>
                  <TD WIDTH="204">&nbsp;</TD>
                  <TD WIDTH="486"><BR>
                    <BR>
                    <INPUT TYPE="submit" onclick="updateTextArea('description');" NAME="act" VALUE="<? print $MSG_089; ?>">
                  </TD>
                </TR>
              <tr>
              <td colspan="2">
              <INPUT TYPE="hidden" NAME="id" VALUE="<?=$_GET[id];?>">
              <INPUT TYPE="hidden" NAME="offset" VALUE="<?=$_GET[offset]; ?>">
              <INPUT TYPE="hidden" NAME="action" VALUE="update">
              </td>
              </tr>
            </TABLE> </FORM>
            </TD>
        </TR>
      </TABLE>
      </TD>
  </TR>
</TABLE>
</BODY>
</HTML>