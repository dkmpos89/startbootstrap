<html>
<head>
<title>BPPENNYAUTOBID</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<table width="650" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td bgcolor="#0083d7"><img src="images/logo.gif" width="325" height="34" vspace="8" hspace="8"></td>
  </tr>
  <tr> 
    <td bgcolor="#999999"><img src="images/transparent.gif" width="1" height="1"></td>
  </tr>
  <tr> 
    <td bgcolor="#eeeeee"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="3">
        <tr> 
          <td><font face="Verdana, Arial, Helvetica, sans-serif" size="2"><b><font size="4">&nbsp;<?=$MSG_5419?></font></b></font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td bgcolor="#999999"><img src="images/transparent.gif" width="1" height="1"></td>
  </tr>
  <tr> 
    <td bgcolor="#FFFFFF"> 
      <table width="100%" border="0" cellspacing="1" cellpadding="3">
        <tr> 
          <td bgcolor="<?=$BG[1]?>" width="22%"> 
            <div align="center">
			<font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<b><font color="<?=$FONT[1]?>" size="1"><?=$MSG_5343?></font></b>
			</font>
			</div>
          </td>
          <td bgcolor="<?=$BG[2]?>" width="20%"> 
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<b><font color="<?=$FONT[2]?>" size="1"><?=$MSG_5344?></font></b></font></div>
          </td>
          <td bgcolor="<?=$BG[3]?>" width="15%"> 
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<b><font color="<?=$FONT[3]?>" size="1"><?=$MSG_5345?></font></b></font></div>
          </td>
          <td bgcolor="<?=$BG[4]?>" width="19%"> 
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<b><font color="<?=$FONT[4]?>" size="1"><?=$MSG_5346?></font><font color="#999999" size="1"> </font></b></font></div>
          </td>
          <td bgcolor="<?=$BG[5]?>" width="24%"> 
            <div align="center"><font face="Verdana, Arial, Helvetica, sans-serif" size="2">
			<b><font color="<?=$FONT[5]?>" size="1"><?=$MSG_5347?></font></b></font></div>
          </td>
        </tr>

      </table>
    </td>
  </tr>
</table>
</body>
</html>
