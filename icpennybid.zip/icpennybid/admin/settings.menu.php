<?#//v.3.0.0

#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

?>
<TABLE WIDTH=100% CELLPADDING=2 CELLSPACING="0" BORDER="0">
  <TR BGCOLOR=#eeeeee>
    <TD WIDTH="3%"><B></B></TD>
    <TD WIDTH="97%"><B><FONT FACE="Tahoma, Verdana" SIZE="2">
      <? print $MSG_5432; ?>
      </FONT></B></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12">
      <A HREF="./settings.php" CLASS="links">
      <?=$MSG_526; ?>
      </A></FONT></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12"><A HREF="./batch.php" CLASS="links">
      <? print $MSG_348; ?>
      </A></FONT></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12"><A HREF="./picturesgallery.php" CLASS="links">
      <? print $MSG_663; ?>
      </A></FONT></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12"><A HREF="./paypaladdress.php" CLASS="links">
      <? print $MSG_398; ?>
      </A></FONT></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12"><A HREF="./errorhandling.php" CLASS="links">
      <? print $MSG_409; ?>
      </A></FONT></TD>
  </TR>
  <tr>
    <td width="3%">&nbsp;</td>
    <td width="97%"><font face="Tahoma, Verdana" size="2"><img src="./images/ball.gif" width="12" height="12"><a href="./https.php" class="links">
      <? print $MSG_1050; ?>
      </a></font></td>
  </tr>
  <tr>
    <td width="3%">&nbsp;</td>
    <td width="97%"><font face="Tahoma, Verdana" size="2"><img src="./images/ball.gif" width="12" height="12"><a href="./relisting.php" class="links">
      <? print $MSG__0156; ?>
      </a></font></td>
  </tr>
  <TR bgcolor="#eeeeee">
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><b><font face="Tahoma, Verdana" size="2">
      <? print $MSG__0100; ?>
      </font></b></TD>
  </TR>
  <TR>
    <TD WIDTH="3%">&nbsp;</TD>
    <TD WIDTH="97%"><FONT FACE="Tahoma, Verdana" SIZE="2"><IMG SRC="./images/ball.gif" WIDTH="12" HEIGHT="12"><A HREF="./aboutme.php" CLASS="links">
      <? print $MSG__0106; ?>
      </A></FONT></TD>
  </TR>
  <tr>
    <td width="3%">&nbsp;</td>
    <td width="97%"><font face="Tahoma, Verdana" size="2"><img src="./images/ball.gif" width="12" height="12"><a href="./aboutmetemplates.php" class="links">
      <? print $MSG__0107; ?>
      </a></font></td>
  </tr>
</TABLE>
