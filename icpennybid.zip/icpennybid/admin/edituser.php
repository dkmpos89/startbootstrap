<?
include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once "../includes/countries.inc.php";


$username = $_REQUEST['name'];
$userid = $_REQUEST['userid'];

//-- Data check
if(empty($userid)) {
  header("Location: listusers.php");
  exit;
}

#// Retrieve users signup settings
$query = "SELECT * FROM BPPENNYAUTOBID_usersettings";
$res_s = @mysql_query($query);
if(!$res_s){
  MySQLError($query);
  exit;
}else{
  $REQUESTED_FIELDS = unserialize(mysql_result($res_s,0,"requested_fields"));
  $MANDATORY_FIELDS = unserialize(mysql_result($res_s,0,"mandatory_fields"));
}

if($_POST['action'] == "update" && strstr(basename($_SERVER['HTTP_REFERER']),basename($_SERVER['PHP_SELF']))) {

	if ($_POST['name'] && $_POST['email']) {

    	
        $DATE = explode("/",$_POST['birthdate']);
        if($SETTINGS[datesformat] == "USA") {
          $birth_day = $DATE[1];
          $birth_month = $DATE[0];
          $birth_year = $DATE[2];
        } else {
          $birth_day = $DATE[0];
          $birth_month = $DATE[1];
          $birth_year = $DATE[2];
        }

        if(strlen($birth_year) == 2) {
            $birth_year = "19".$birth_year;
        }

        $credit=isset($_POST['credit'])? floatval($_POST['credit']) :"0";
        
        if ($_POST['password'] != $_POST['repeat_password']) {
          $ERR = "ERR_006";
        } elseif (strlen($_POST['email'])<5) { //Primitive mail check
          $ERR = "ERR_110";
        } elseif(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+([\.][a-z0-9-]+)+$/i",$_POST['email'])) {
          $ERR = "ERR_008";
        } elseif (!preg_match("#^[0-9]{2}/[0-9]{2}/[0-9]{4}$#",$_POST['birthdate']) &&
        !preg_match("#^[0-9]{2}/[0-9]{2}/[0-9]{2}$#",$_POST['birthdate']) && $MANDATORY_FIELDS['birthdate']=='y' &&   $REQUESTED_FIELDS['birthdate']=='y') { //Birthdate check
          $ERR = "ERR_043";
        } elseif (strlen($_POST['zip'])<4 && $MANDATORY_FIELDS['zip']=='y' && $REQUESTED_FIELDS['zip']=='y') { //Primitive zip check
          $ERR = "ERR_616";
        } elseif (strlen($_POST['phone'])<3 && $MANDATORY_FIELDS['tel']=='y' && $REQUESTED_FIELDS['tel']=='y') { //Primitive phone check
          $ERR = "ERR_617";
        } else {
            $birthdate = "$birth_year"."$birth_month"."$birth_day";
            $sql="UPDATE BPPENNYAUTOBID_users SET 
                  name=\""   .AddSlashes($_POST['name'])
            ."\", email=\""  .AddSlashes($_POST['email'])
            ."\", address=\"".AddSlashes($_POST['address'])
            ."\", city=\""   .AddSlashes($_POST['city'])
            ."\", prov=\""   .AddSlashes($_POST['prov'])
            ."\", country=\"".AddSlashes($_POST['country'])
            ."\", zip=\""    .AddSlashes($_POST['zip'])
            ."\", phone=\""  .AddSlashes($_POST['phone'])
            ."\",  reg_date=reg_date, balance=balance+".$credit." ";
            if (strlen($_POST['password']) > 0) {
                $sql .=  ", password=\"". md5($MD5_PREFIX.AddSlashes($_POST['password'])) . "\"";
            }
            $sql .=  ",reg_date=reg_date WHERE id='".AddSlashes($userid)."'";

        	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
				echo $ERR = $ERR_9999;

			}else{
            
           		$res=mysql_query ($sql);
			}
            $updated = 1;

            $URL = $_SESSION["RETURN_LIST"]."?PAGE=".$_SESSION['RETURN_LIST_PAGE'];
            unset($_SESSION["RETURN_LIST"]);
            header("Location: $URL");
            exit;
        }
    } else {
        $ERR = "ERR_112";
    }

}

if(!$_POST['action'] || ($_POST['action'] && $updated)) {
    $query = "select * from BPPENNYAUTOBID_users where id=\"$userid\"";
    $result = mysql_query($query);

    if(!$result){
        print "Database access error: abnormal termination".mysql_error();
        exit;
    }
    $username = mysql_result($result,0,"name");
    
    $nick = mysql_result($result,0,"nick");
    $password = mysql_result($result,0,"password");
    $email = mysql_result($result,0,"email");
    $address = mysql_result($result,0,"address");
    $city = mysql_result($result,0,"city");
    $prov = mysql_result($result,0,"prov");
    $suspended = mysql_result($result,0,"suspended");
    $balance = mysql_result($result,0,"balance");
    $offers = mysql_result($result,0,"offers");
    
    $country = mysql_result($result,0,"country");
    $country_list="";
    while (list ($code, $descr) = each ($countries)) {
        $country_list .= "<option value=\"$descr\"";
        if ($descr == $country) {
            $country_list .= " selected";
        }
        $country_list .= ">$descr</option>\n";
    }
    
    $prov = mysql_result($result,0,"prov");
    $zip = mysql_result($result,0,"zip");
    
    $birthdate = mysql_result($result,0,"birthdate");
    $birth_day = substr($birthdate,6,2);
    $birth_month = substr($birthdate,4,2);
    $birth_year = substr($birthdate,0,4);
    $birthdate = $SETTINGS[datesformat] == "USA" ? "$birth_month/$birth_day/$birth_year" : "$birth_day/$birth_month/$birth_year";
    
    $phone = mysql_result($result,0,"phone");
    
    $rate_num = mysql_result($result,0,"rate_num");
    $rate_sum = mysql_result($result,0,"rate_sum");
    if ($rate_num) {
        $rate = round($rate_sum / $rate_num);
    } else {
        $rate=0;
    }
}
?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<STYLE TYPE="text/css">
body {
scrollbar-face-color: #aaaaaa;
scrollbar-shadow-color: #666666;
scrollbar-highlight-color: #aaaaaa;
scrollbar-3dlight-color: #dddddd;
scrollbar-darkshadow-color: #444444;
scrollbar-track-color: #cccccc;
scrollbar-arrow-color: #ffffff;
}</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr>
          <td width="30"><img src="images/i_use.gif" ></td>
          <td class=white><?=$MSG_25_0010?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_045?></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr> 
    <td align="center" valign="middle">
      <table width="95%" border="0" cellspacing="0" cellpadding="1" bgcolor="#546f95" align="center">
        <tr>
          <td align=center colspan=5><table width="100%" border="0" cellspacing="0" cellpadding="1" bgcolor="#546f95" align="center">
              <tr>
                <td><table width="100%" border="0" cellpadding="5" align="center" cellspacing="0">
              <tr>
                <td colspan="2" valign="top" align="center" class=title><? print $MSG_511; ?></td>
              </tr>
              <?
              if($ERR || $updated) {
                print "<TR BGCOLOR=#ffffff><TD></TD><TD WIDTH=486>";
                if($$ERR) print $$ERR;
                if($updated) print "Users data updated";
                print "</TD>
                </TR>";
                }
                ?>
            <form name=details action="edituser.php" method="POST">
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_302 *"; ?> </td>
                <td width="486"><input type=text name=name size=40 maxlength=255 value="<? print $username; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_003 *"; ?> </td>
                <td width="486"> <b> <? echo $nick; ?> </b> </td>
              </tr>
              <tr>
                <td width="204" valign="top" bgcolor="#EEEEEE" >&nbsp;</td>
                <td width="486" bgcolor="#EEEEEE"> <? print "$MSG_243" ?> </td>
              </tr>
              <tr>
                <td width="204" valign="top" align="right" bgcolor="#EEEEEE"> <? print " $MSG_004 *"; ?> </td>
                <td width="486" bgcolor="#EEEEEE"><input type=text name=password size=20 maxlength=20>
                </td>
              </tr>
              <tr>
                <td width="204" valign="top" align="right" bgcolor="#EEEEEE"> <? print " $MSG_004 *"; ?> </td>
                <td width="486" bgcolor="#EEEEEE"><input type=text name=repeat_password size=20 maxlength=20>
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204"  valign="top" align="right"> <? print "$MSG_303 *"; ?> </td>
                <td width="486"><input type=text name=email size=50 maxlength=50 value="<? echo $email; ?>">
                </td>
              </tr>
              <? if($MANDATORY_FIELDS['birthdate']=='y') { //Birthdate check ?>
              <tr bgcolor="#FFFFFF">
                <td width="204"  valign="top" align="right"> <? print "$MSG_252 *"; ?> </td>
                <td width="486"><input type=text name=birthdate size=10 maxlength=10 value="<? echo $birthdate; ?>">
                </td>
              </tr>
              <? } ?>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_009 *"; ?> </td>
                <td width="486"><input type=text name=address size=40 maxlength=255 value="<? echo $address; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_010 *"; ?> </td>
                <td width="486"><input type=text name=city size=40 maxlength=255 value="<?echo $city; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_011 *"; ?> </td>
                <td width="486"><input type=text name=prov size=40 maxlength=255 value="<?echo $prov; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_014 *"; ?> </td>
                <td width="486"><select name=country>
                    <option value=""> </option>
                    <?  echo $country_list; ?>
                  </select>
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_012 *"; ?> </td>
                <td width="486"><input type=text name=zip size=15 maxlength=15 value="<? echo $zip; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_013 *"; ?> </td>
                <td width="486"><input type=text name=phone size=20 maxlength=40 value="<? echo $phone; ?>">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_300"; ?> </td>
                <td width="486"><?
                  if($suspended == 0)
                  print "$MSG_029";
                  else
                  print "$MSG_030";
                  ?>
                </td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> <? print "$MSG_435"; ?> </td>
                <td width="486"><?= $balance?></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204" valign="top" align="right"> Add Bids </td>
                <td width="486"><input type=text name='credit' size=10 maxlength=5 value=""></td>
              </tr>
              <tr bgcolor="#FFFFFF">
                <td width="204">&nbsp;</td>
                <td width="486"><br>
                  <br>
                  <input TYPE="submit" NAME="act" value="<? print $MSG_089; ?>">
                </td>
              </tr>
              <input type="hidden" name="userid" value="<?=$_GET[userid]; ?>">
              <input type="hidden" name="offset" value="<? echo $_GET[offset]; ?>">
             <input type="hidden" name="idhidden" value="<?=($_GET['userid'])?$_GET['userid']:$_POST['idhidden']?>">
             <input type="hidden" name="action" value="update">
            </form>
          </table></TD>
      </TR>
    </TABLE>
    </TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>
