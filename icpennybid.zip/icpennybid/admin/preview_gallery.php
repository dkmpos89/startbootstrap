<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
include_once "../includes/config.inc.php";
if(!defined('INCLUDED')) exit("Access denied");
$img=$_GET['img'];
//echo $img;
?>
<HTML>
<BODY TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<A HREF="Javascript:window.close()"><IMG SRC=<?="../".$uploaded_path.session_id()."/".$img?> BORDER=0></A>
</BODY>
</HTML>