<?

include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once "../includes/countries.inc.php";

$auction_id = isset($_REQUEST['aid']) ? $_REQUEST['aid'] : "";
$user_id = isset($_REQUEST['uid']) ? $_REQUEST['uid'] : "";

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<STYLE TYPE="text/css">
body {
scrollbar-face-color: #aaaaaa;
scrollbar-shadow-color: #666666;
scrollbar-highlight-color: #aaaaaa;
scrollbar-3dlight-color: #dddddd;
scrollbar-darkshadow-color: #444444;
scrollbar-track-color: #cccccc;
scrollbar-arrow-color: #ffffff;
}</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<center>
<?  

/************ SHOW BID HISTORY *******************/
$TPL_auctions_list_value = "";
// Show selected user bids

if($auction_id != ""){
	
	// find won bid
	$sql = "SELECT bid, bidder, COUNT(bid) AS bid_count FROM BPPENNYAUTOBID_bids WHERE auction=".intval($auction_id)." GROUP BY bid ORDER BY bid DESC ";
	$result_check_winner = mysql_query($sql);
	if ($row = mysql_fetch_array($result_check_winner)){
		$won_bid = $row['bid'];
	}else{
		$won_bid = "";
	}
	
	// find other unique bids
	$unique = array();	
	while ($row = mysql_fetch_array($result_check_winner)){
		$unique[] = $row['bid'];
	}
			
			
	// prepare list of bids
	$sql = "SELECT
			b.id, b.bidder, b.bid, b.auction, b.bidwhen
		FROM
			BPPENNYAUTOBID_bids b
		WHERE
			b.bidder='".$user_id."' AND
			b.auction = '".intval($auction_id)."'
		ORDER BY
			b.bid DESC";
	
	$result = mysql_query($sql);
	$idcheck= "";
	if ($result) {
		$tplv = "";
		$bgColor = "#EBEBEB";
		$bgColorWon = "#0000cd";
		$bgColorUnique = "#ffff00";
		$bgColorNone = "#cd0000";
		while ($row=mysql_fetch_array($result)) {
	
			$bid = $row['bid'];
			//$bidwhen_date = date("Y-m-d h:i:s");
			$hour = substr($row["bidwhen"],8,2)+$SETTINGS['timecorrection'];
			
			$h_time = mktime($hour,date("i"),date("s"),date("m"), date("d"),date("Y"));
			$ampm = date("A",$h_time);
			
			if($hour>24) $hour-=24;
			
			if($hour>12)
			{
				$hour-=12;
			}
			
			if(strlen($hour)==1)$hour = "0".$hour;
				
						
			//if($hour=0)$hour="00";
			$bidwhen_date = substr($row["bidwhen"],0,4).
							"-".
							substr($row["bidwhen"],4,2).
							"-".
							substr($row["bidwhen"],6,2).
							" ".
							$hour.
							":".
							substr($row["bidwhen"],10,2).
							":".
							substr($row["bidwhen"],12,2).
							" ".
							$ampm;
//			$bidwhen_date = date("Ymd h:i:s A",$row["bidwhen"]);
			
			if($bgColor == "#EBEBEB") {
				$bgColor = "#FFFFFF";
			} else {
				$bgColor = "#EBEBEB";
			}

			$tplv .= "<tr VALIGN=MIDDLE BGCOLOR=\"$bgColor\">"; 			
			if($won_bid == $bid) {
				$tplv .= "<td align='center' BGCOLOR='".$bgColorWon."'><font color='#ffffff'><b>".$bid."</b></font></td>";	
			}else{
				$tplv .= "<td align='center' BGCOLOR='".$bgColorUnique."'><font color='#ffffff'><b style='color:#000000'>".$bid."</b></td>";	
			}/*else{
				$tplv .= "<td align='center' BGCOLOR='".$bgColorNone."'><font color='#ffffff'><b>".$bid."</b></td>";	
			}*/			
			$tplv .= "<td align='center'>".$bidwhen_date."</td>"; 
			$tplv .= "</tr>";
		}
		$TPL_auctions_list_value = $tplv;	
	} else {
		$auctions_count = 0;
		$TPL_auctions_list_value = "<tr ALIGN=CENTER><td COLSPAN=6>&nbsp;</td></tr>";  
	}	
}
/************ EOF: SHOW BID HISTORY *******************/
?>
    <TABLE WIDTH=80% HEIGHT=20 BORDER=0 CELLPADDING=0 CELLSPACING=0 style="line-height:20px;text-align:center;">
        <TR valign=top>
            <TD colspan=6 Height=20 >&nbsp;</TD>
        </TR>
        <!--<TR valign=top>
            <TD WIDTH=20 BGCOLOR="#0000cd">&nbsp;</TD>
            <TD WIDTH=20 style="padding-left:3px;" >Winner</TD>
            <TD WIDTH=20 BGCOLOR="#ffff00">&nbsp;</TD>
            <TD WIDTH=150 style="padding-left:3px;">Unique but not lowest</TD>
            <TD WIDTH=20 BGCOLOR="#cd0000">&nbsp;</TD>
            <TD WIDTH=150 style="padding-left:3px;">Not unique</TD>
        </TR>-->
        <TR valign=top>
            <TD colspan=6 Height=10 >&nbsp;</TD>
        </TR>
        <TR valign=top>
            <TD colspan=6>
                <TABLE WIDTH=100% BORDER=1 style="border-collapse:collapse;" CELLPADDING=0 CELLSPACING=0>
                    <TR>
                        <TH align=CENTER>Bid</TH>
                        <TH align=CENTER><?=$MSG_171; ?></TH>
                    </TR>
                    <?
                    if($TPL_auctions_list_value != ""){ 
                        print $TPL_auctions_list_value; 
                    }else{
                    ?>
                    <TR>
                        <TD colspan=2>No bids found</TD>
                    </TR>
                    <? } ?>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
<BR><BR><BR>
<?
    echo "<center><a class='default_class_a' href='auction_users.php?aid=$auction_id'>Back</a></center>";
?>
</center>
</BODY>
</HTML>