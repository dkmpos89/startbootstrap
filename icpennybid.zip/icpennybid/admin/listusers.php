<?
require('../includes/config.inc.php');
include_once "loggedin.inc.php";

if($_GET['usersfilter'] == 'all') {
    unset($_SESSION["usersfilter"]);
    unset($Q);
} elseif(isset($_GET['usersfilter'])) {
    switch($_GET['usersfilter']) {
        case 'active':
        $Q = 0;
        break;
        case 'admin':
        $Q = 1;
        break;
        case 'confirmed':
        $Q = 8;
        break;
        case 'fee':
        $Q = 9;
        break;
        case 'sellers':
        $account = 'seller';
        break;
        case 'buyers':
        $account = 'buyer';
        break;
    }
    $usersfilter = $_GET['usersfilter'];
    $_SESSION["usersfilter"]=$usersfilter;
} elseif(!isset($_GET['usersfilter']) && isset($_SESSION['usersfilter'])) {
    switch($_SESSION['usersfilter']) {
        case 'active':
        $Q = 0;
        break;
        case 'admin':
        $Q = 1;
        break;
        case 'confirmed':
        $Q = 8;
        break;
        case 'fee':
        $Q = 9;
        break;
        case 'sellers':
        $account = 'seller';
        break;
        case 'buyers':
        $account = 'buyer';
        break;
    }
} else {
    unset($_SESSION["usersfilter"]);
    unset($Q);
}


#// Retrieve active auctions from the database
if(isset($Q)) {
    $TOTALUSERS = mysql_result(mysql_query("select count(id) as COUNT from BPPENNYAUTOBID_users WHERE suspended=$Q"),0,"COUNT");
} elseif(isset($account)) {
    $TOTALUSERS = mysql_result(mysql_query("select count(id) as COUNT from BPPENNYAUTOBID_users WHERE accounttype='$account'"),0,"COUNT");
} else {
    $TOTALUSERS = mysql_result(mysql_query("select count(id) as COUNT from BPPENNYAUTOBID_users"),0,"COUNT");
}

//-- Set offset and limit for pagination
$LIMIT = 30;
if(!$offset) $offset = 0;

if(!isset($_GET[PAGE]) || $_GET[PAGE] == 1 || !$_GET[PAGE]) {
    $OFFSET = 0;
    $PAGE = 1;
} else {
    $PAGE = $_GET[PAGE];
    $OFFSET = ($_GET[PAGE] - 1) * $LIMIT;
}
$PAGES = ceil($TOTALUSERS / $LIMIT);
$_SESSION['RETURN_LIST'] = 'listusers.php';
$_SESSION['RETURN_LIST_PAGE'] = intval($PAGE);

?>
<HTML>
<HEAD>
<SCRIPT Language=Javascript>
<!--
function SubmitFilter()
{
    document.filter.submit();
}
//-->
</SCRIPT>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<SCRIPT Language=Javascript>
function window_open(pagina,titulo,ancho,largo,x,y){
    
    var Ventana= 'toolbar=0,location=0,directories=0,scrollbars=1,screenX='+x+',screenY='+y+',status=0,menubar=0,resizable=0,width='+ancho+',height='+largo;
    open(pagina,titulo,Ventana);
    
}
</SCRIPT>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif">
        <table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_use.gif" ></td>
          <td class=white><?=$MSG_25_0010?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_045?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
  <tr> 
    <td align="center" valign="middle">
            <TABLE WIDTH="98%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95" ALIGN="CENTER">
            <TR>
            <TD ALIGN=CENTER class=title><? print $MSG_045; ?></TD>
            </TR>
            <TR>
            <TD>
                <TABLE WIDTH=100% CELPADDING=0 CELLSPACING=1 BORDER=0 ALIGN="CENTER" CELLPADDING="3" BGCOLOR=#ffffff>
                <TR>
                <TD COLSPAN=8>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="right">
                    <FORM NAME=search ACTION=userssearch.php METHOD=POST>
                    <tr>
                    <td bgcolor="#eeeeee"> 
                    <BR>
                    <?=$MSG_5022?> <INPUT TYPE=text NAME=keyword SIZE=25>
                    <input type=SUBMIT name=SUBMIT value="<?=$MSG_5023?>">
                    <?=$MSG_5024?>
                    </td>
                    </tr>
                    </FORM>
                    </table>
                </TD>
                </TR>
                <TR BGCOLOR=#FFFFFF>
                <TD COLSPAN=8>
                <TABLE WIDTH=100% CELLPADDING=1 CELLSPACING=0 BORDER=0>
    			  <FORM NAME="filter" ACTION="<?=basename($_SERVER['PHP_SELF'])?>">
                  <TR>
                    <TD WIDTH=30%> <B>
                    <?=$TOTALUSERS." ".$MSG_301?>
                    </B> </TD>
                    <TD WIDTH=20% valign="center">
                    <TD WIDTH=50% align=right>
                    <?=$MSG_5295?>
                    <SELECT NAME=usersfilter onChange="SubmitFilter()">
                    <OPTION VALUE=all>
                    <?=$MSG_5296?>
                    </OPTION>
                    <OPTION VALUE=active <?if($_SESSION['usersfilter'] == 'active') print " selected"?>>
                    <?=$MSG_5291?>
                    </OPTION>
                    <OPTION VALUE=admin <?if($_SESSION['usersfilter'] == 'admin') print " selected"?>>
                    <?=$MSG_5294?>
                    </OPTION>
                    
                    
                    </SELECT>
                    </TD>
                  </TR>
                  </FORM>
                  </TABLE>
                </TD>
                </TR>
                <TR BGCOLOR="#FFCC00">
                    <!--<TD ALIGN=CENTER width="5%"> <B> <?// print $MSG_5289; ?> </B>  </TD>-->
                    <TD ALIGN=LEFT width="10%"> <B> <? print $MSG_293; ?> </B>  </TD>
                    <TD ALIGN=LEFT width="20%"> <B> <? print $MSG_294; ?> </B>  </TD>
                    <TD ALIGN=LEFT width="10%"> <B> <? print $MSG_295; ?> </B>  </TD>
                    <TD ALIGN=LEFT width="10%"> <B> <? print $MSG_296; ?> </B>  </TD>
                    <TD ALIGN=LEFT width="10%"> <B> <? print strtoupper($MSG_25_0079); ?> </B>  </TD>
                    <TD ALIGN=LEFT width="10%"> <B> <? print strtoupper($MSG_5290); ?> </B>  </TD>
                    <TD ALIGN=LEFT width="95px"> <B> <? print $MSG_297; ?> </B>  </TD>
                </tr>
                <?
                if(isset($Q)) {
                    $query = "select * from BPPENNYAUTOBID_users WHERE suspended=$Q order by nick limit $OFFSET, $LIMIT";
                } elseif(isset($account)) {
                    $query = "select * from BPPENNYAUTOBID_users WHERE accounttype='$account' order by nick limit $OFFSET, $LIMIT";
                } else {
                    $query = "select * from BPPENNYAUTOBID_users order by nick limit $OFFSET, $LIMIT";
                }
                $result = mysql_query($query);
                if(!$result) {
                    print "Database access error: abnormal termination<BR>$query<BR>".mysql_error();
                    exit;
                }
                $num_users = mysql_num_rows($result);
                $i = 0;
                $bgcolor = "#FFFFFF";
                while($i < $num_users){
                    if($bgcolor == "#FFFFFF"){
                        $bgcolor = "#EEEEEE";
                    }else{
                        $bgcolor = "#FFFFFF";
                    }
                    $id = mysql_result($result,$i,"id");
                    $nick = mysql_result($result,$i,"nick");
                    $name = mysql_result($result,$i,"name");
                    $country = mysql_result($result,$i,"country");
                    $email = mysql_result($result,$i,"email");
                    $creditcard = mysql_result($result,$i,"creditcard");
                    $suspended = mysql_result($result,$i,"suspended");
                    $newsletter = mysql_result($result,$i,"nletter");
                    print "<TR BGCOLOR=$bgcolor>
                    <TD>$nick</TD>
                    <TD>$name</TD>
                    <TD>$country</TD>
                    <TD><A HREF=\"mailto:$email\" title='".$email."'>".substr($email, 0, 14)."...</A></TD>
                    <TD align=center>";
                    if($newsletter == 1) {
                        print "$MSG_030";
                    }
                    if($newsletter == 2) {
                        print "$MSG_029";
                    }
                    print "</TD><TD>";
                    if($suspended == 0) {
                        print "<B><FONT COLOR=green>$MSG_5291</B>";
                    }
                    if($suspended == 1) {
                        print "<B><FONT COLOR=violet>$MSG_5294</B>";
                    }
                    if($suspended == 9) {
                        print "<B><FONT COLOR=red>$MSG_5293</B>";
                    }
                    if($suspended == 10) {
                        print "<B><FONT COLOR=orange><A HREF=\"excludeuser.php?id=$id&offset=$offset\" class=\"nounderlined\">".$MSG_25_0136."</A>";
                    }
                    if($suspended == 8) {
                        print "<B><FONT COLOR=orange>$MSG_5292</B>
                               <BR>
                               <A HREF=resendemail.php?id=$id>$MSG_25_0074</A>
									";
				}
				if($suspended == 1) {
				print "
									<B><FONT COLOR=violet>$MSG_5294</B>
                               ";
                    }
                    print "</TD>";
                    print "<TD ALIGN=LEFT>
                    &raquo;<A HREF=\"edituser.php?userid=$id&offset=$offset\" class=\"nounderlined\">$MSG_298</A><BR>
                    &raquo;<A HREF=\"deleteuser.php?id=$id&offset=$offset\" class=\"nounderlined\">$MSG_299</A><BR>
                    &raquo;<A HREF=\"excludeuser.php?id=$id&offset=$offset\" class=\"nounderlined\">";
                    if($suspended == 0) {
                        print $MSG_300;
                    } else {
                        print $MSG_310;
                    }
                    print "</A><BR>
                    
                    &raquo;<A HREF=\"viewuserips.php?id=$id&offset=$offset\" class=\"nounderlined\">$MSG_2_0004</A><BR>
                    &raquo;<A HREF=\"payments_history.php?id=$id\" class=\"nounderlined\">$MSG_31_0020</A><BR>
                    </TD>
                    </TR>";
                    $i++;
                }
                ?>
                </TABLE>
                <center class=white>
                <?=$MSG_5117?>
                &nbsp;&nbsp;
                <?=$PAGE?>
                <?=$MSG_5118?>
                &nbsp;&nbsp;
                <?=$PAGES?>
                <BR>
                <?
                $PREV = intval($PAGE - 1);
                $NEXT = intval($PAGE  + 1);
                ?>
                <?
                if($PAGES > 1) {
                    if($PAGE > 1) {
                ?>
    		  	<A HREF="<?=basename($_SERVER[PHP_SELF])?>?PAGE=<?=$PREV?>"><U><SPAN CLASS=white>
                <?=$MSG_5119?>
                </SPAN></U></a> &nbsp;&nbsp;
                <?
                }
                ?>
                <?
                $LOW = $PAGE - 5;
                if($LOW <= 0) $LOW = 1;
                $COUNTER = $LOW;
                while($COUNTER <= $PAGES && $COUNTER < ($PAGE+6)) {
                if($PAGE == $COUNTER) {
                    print "<B>$COUNTER</B>&nbsp;&nbsp;";
                } else {
					print "<A HREF=\"".basename($_SERVER[PHP_SELF])."?PAGE=$COUNTER\"><U><SPAN CLASS=white>$COUNTER</SPAN></U></A>&nbsp;&nbsp;";
                }
                $COUNTER++;
                }
                ?>
                &nbsp;&nbsp;
                <?
                if($PAGE < $PAGES) {
                ?>
      			<A HREF="<?=basename($_SERVER[PHP_SELF])?>?PAGE=<?=$NEXT?>"><U><SPAN CLASS=white>
                  <?=$MSG_5120?>
                  </SPAN></U></A> 
                <?
                    }
                }
                ?>
                </center>
                </TD>
              </TR>
            </TABLE>
            <BR>
          </TD>
        </TR>
      </TABLE>
    </td>
  </tr>
</table>
</BODY>
</HTML>