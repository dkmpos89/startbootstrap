<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
?>

<TABLE WIDTH="740" BORDER=0 ALIGN=center>
	<TR>
		<TD><CENTER>
		<FONT FACE=Verdana,Arial SIZE=1 COLOR="#000000">
			Copyright &copy; 2010, icloudcenter.com </FONT></CENTER>
		</TD>
	</TR>
</TABLE>
</BODY>
</HTML>