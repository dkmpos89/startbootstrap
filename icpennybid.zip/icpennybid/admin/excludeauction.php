<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

include_once "../includes/config.inc.php";
include_once "loggedin.inc.php";
include_once $include_path."countries.inc.php";

//$username = $name;
$TIME = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d"),date("Y"));
$NOW = date("YmdHis",$TIME);

$id = isset($_GET['id']) ? $_GET['id'] : 0;
$mode = isset($_REQUEST['mode']) ? $_REQUEST['mode'] : "";

$ERR = "";
//if($action && strstr(basename($_SERVER['HTTP_REFERER']),basename($_SERVER['PHP_SELF']))){
	if($mode == "activate" && $id!=0) {
		if(!preg_match('/^[1-9]\d{0,9}$/',$id)) $ERR = "Auction ID invalid!";
		else{
			$sql = "SELECT * FROM BPPENNYAUTOBID_auctions WHERE id=$id";
			$res = mysql_query($sql);
			if(!$res){
				$ERR = "Auction does not exist!";    
			}elseif(!mysql_query("UPDATE BPPENNYAUTOBID_auctions set suspended=0 WHERE id='$id'")){
				$ERR = "Errore database. Please try again later.";
			}else{			
				$ERR = "Auction $id has been activated.";
				$row = mysql_fetch_array($res);
				$auction_type = $row['auction_type'];
				$start = $row['starts'];								
				$duration = intval($row['duration']);
				$second_duration = intval($row['second_duration']);
				switch($auction_type){
					case "1":						
						$time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d"),date("Y"));
						$end_time =  mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), intval(date("d"))+intval($duration),date("Y"));
						$now = date("YmdHis",$time);
						$end = date("YmdHis",$end_time);
						//$update = "UPDATE BPPENNYAUTOBID_auctions SET starts='$now',ends='$end',closed=0 WHERE id='$id'";
						break;
					case "2":
					case "3":
						$time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), date("d"),date("Y"));
						$end_time =  mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), (intval(date("d"))+$duration),date("Y"));
						$second_end_time = mktime(date("H")+$SETTINGS['timecorrection'],date("i"),date("s"),date("m"), (intval(date("d"))+$duration+$second_duration),date("Y"));
						$now = date("YmdHis",$time);
						$end = date("YmdHis",$end_time);
						$second_starts = $end;
						$second_ends = date("YmdHis",$second_end_time);
						$update = "UPDATE BPPENNYAUTOBID_auctions SET starts='$now',ends='$end',second_starts='$second_starts',second_ends='$second_ends',closed=1 WHERE id='$id'";
						break;
					default:
						$update = "";
						break;						
				}				
				//@mysql_query($update);
			}
		}
	}
//}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<STYLE TYPE="text/css">
body {
scrollbar-face-color: #aaaaaa;
scrollbar-shadow-color: #666666;
scrollbar-highlight-color: #aaaaaa;
scrollbar-3dlight-color: #dddddd;
scrollbar-darkshadow-color: #444444;
scrollbar-track-color: #cccccc;
scrollbar-arrow-color: #ffffff;
}</STYLE>
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td background="images/bac_barint.gif">
			<table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr>
				<td width="30"><img src="images/i_auc.gif" ></td>
				<td class=white><?=$MSG_239?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_5091?></td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
			<TABLE WIDTH="95%" BORDER="0" CELLSPACING="1" CELLPADDING="1" BGCOLOR="#0083D7" ALIGN="CENTER">
			<TR>
				<TD ALIGN=CENTER class=title>
					<B>
					<?
					echo $ERR;
					?>
					</B>
				</TD>
			</TR>
            </TABLE>			
		</td>
	</tr>
	</table>
</BODY>
</HTML>
