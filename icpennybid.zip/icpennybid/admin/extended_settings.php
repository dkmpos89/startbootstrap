<?php
require('../includes/config.inc.php');include_once "loggedin.inc.php";


		
         if($_POST["act"]==$MSG_530)
         {
         
			#// Update data				
		$query = "update BPPENNYAUTOBID_settings set					
				aoutobid_step='".$_POST[count]."' , extension_time='".$_POST[extension_time]."' ,add_to_balance='".$_POST[add_to_balance]."'";						
						$res = mysql_query($query);
                                //echo $res."+++";
                                if(!$res)
                                {					
					print "Error: $query<BR>".mysql_error();					
					exit;				
				}else
                                {					
					$ERR = $MSG_542;					
					//$SETTINGS = $_POST;				
				}								
		
         }
         $sql1="select * from BPPENNYAUTOBID_settings";
			$res = @mysql_query($sql1);
			
		if(!$res)
		{
			print "Error: $query<BR>".mysql_error();
			exit;
		}
		elseif(mysql_num_rows($res) > 0)
		{
			$SETTINGS = mysql_fetch_array($res);
		}
?>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='style.css' />
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666"
	alink="#000066" leftmargin="0" topmargin="0" marginwidth="0"
	marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td background="images/bac_barint.gif">
		<table width="100%" border="0" cellspacing="5" cellpadding="0">
			<tr>
				<td width=31><img src="images/i_auc.gif" width="21" height="19"></td>
				<td class=white>AUCTIONS&nbsp;&gt;&gt;&nbsp;extended settings
                                
                                </td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td align="center" valign="middle">&nbsp;</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
		<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0
			BGCOLOR="#FFFFFF">
			<TR>
				<TD align="center"><BR>
				<FORM NAME=conf ACTION=<?=basename($_SERVER['SCRIPT_NAME'])?>
					METHOD=POST>
				<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1"
					BGCOLOR="#546f95">
					<TR>
						<TD ALIGN=CENTER class=title>Extended Settings</TD>
					</TR>
					<TR>
						<TD>
						<TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
						<?
						if(isset($ERR))
						{
							?>
							<TR BGCOLOR=yellow>
								<TD COLSPAN="2" ALIGN=CENTER><B> <? print $ERR; ?> </B></TD>
							</TR>
							<?
						}
						?>
							<TR VALIGN="TOP">
								<TD COLSPAN="2"><IMG SRC="../images/transparent.gif" WIDTH="1"
									HEIGHT="5">
                                                                                    <div>
                                                                Here you can set the duration seconds for the frequency every autobid is placed.</div></TD>
							</TR>
							<TR VALIGN="TOP">
								<TD WIDTH=169></TD>
								<TD WIDTH="365"> <BR>
								Seconds &nbsp; &nbsp;<INPUT TYPE="text" NAME="count" SIZE="45" MAXLENGTH="4"
								VALUE="<?=$SETTINGS["aoutobid_step"]?>">
                                                                </TD>
							</TR>
							<TR VALIGN="TOP">
								<TD COLSPAN="2"><IMG SRC="../images/transparent.gif" WIDTH="1"
									HEIGHT="5">
                                                                                    <div>
                                                                Here you can set the amount of seconds the auction will extend to once bidding in the last 15 sec.</div></TD>
							</TR>
							<TR VALIGN="TOP">
								<TD WIDTH=169></TD>
								<TD WIDTH="365"> <BR>
								Seconds &nbsp; &nbsp;<INPUT TYPE="text" NAME="extension_time" SIZE="45" MAXLENGTH="4"
								VALUE="<?=$SETTINGS["extension_time"]?>">
                                                                </TD>
							</TR>
							
							<TR VALIGN="TOP">
								<TD WIDTH=169></TD>
								<TD WIDTH="365"> <BR>
								free bids on registration &nbsp; &nbsp;<INPUT TYPE="text" NAME="add_to_balance" SIZE="45" MAXLENGTH="4"
								VALUE="<?=$SETTINGS["add_to_balance"]?>">
                                                                </TD>
							</TR>
							
							<TR>
                                                            
								<TD WIDTH=169><INPUT TYPE="submit" NAME="act"
									VALUE="<? print $MSG_530; ?>"></TD>
								<TD WIDTH="365"></TD>
							</TR>
						</TABLE>
						</TD>
					</TR>
				</TABLE>
				</FORM>
				</TD>
			</TR>
		</TABLE>
		</TD>
	</TR>
</TABLE>
</BODY>
</HTML>
