<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////
require('..//includes//config.inc.php');

if($_POST['act'] == "insert" && basename($_SERVER['HTTP_REFERER']) == basename($_SERVER['PHP_SELF'])) {
	#// Additional security check
	$RR = mysql_query("SELECT id from BPPENNYAUTOBID_adminusers");
	if(mysql_num_rows($RR) > 0)	{
		print "Fatal error: user cannot be inserted - one or more administrators are already present in the database.<BR><A HREF=login.php>login page</A>";
		exit;
	}
	$md5_pass=md5($MD5_PREFIX.$_POST['password']);
	$query = "insert into BPPENNYAUTOBID_adminusers values (10,'$_POST[username]', '$md5_pass', '20011224', '20020110093458', 1)";
	$result = @mysql_query($query);
	#// Redirect
	Header("Location: login.php");
	exit;
}
$query = "select MAX(id) from BPPENNYAUTOBID_adminusers";
$result = @mysql_query($query);
while($row = mysql_fetch_row($result)) {
	$id = $row[0] + 1;
}
?>
<HTML>
<HEAD>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</HEAD>
<BODY>
<?
if($id==1) {
	$id=0;
?>
  
<TABLE BORDER=0 WIDTH=650 CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF" ALIGN="CENTER">
	<TR>
		<TD><CENTER><BR><BR>
			<FORM NAME=login ACTION=login.php METHOD=POST>
			<TABLE WIDTH="410" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#336699">
			<TR>
				<TD>
					<TABLE WIDTH=100% CELLPADDING=3 ALIGN="CENTER" CELLSPACING="0" BORDER="0" BGCOLOR="#FFFFFF">
					<TR BGCOLOR="#336699">
						<TD COLSPAN="2" ALIGN=CENTER>
							<FONT COLOR=white><B>:: Please create your username and password ::</B></FONT>
						</TD>
					</TR>
					<TR>
						<TD></TD>
						<TD> <FONT COLOR=red>
						<? print $ERR; ?>
						</TD>
					</TR>
					<TR>
						<TD ALIGN=right> 
							<? print $MSG_003; ?>
						</TD>
						<TD>
							<INPUT TYPE=TEXT NAME=username SIZE=20 >
						</TD>
					</TR>
					<TR>
						<TD ALIGN=right> 
							<? print $MSG_004; ?>
						</TD>
						<TD>
							<INPUT TYPE=password NAME=password SIZE=20 >
						</TD>
					</TR>
					<TR>
						<TD></TD>
						<TD>
							<INPUT TYPE="submit" NAME="act"ion VALUE="insert">
						</TD>
					</TR>
					</TABLE>
				</TD>
			</TR>
			</TABLE>
			</FORM>
			</CENTER>
		</TD>
	</TR>
	</TABLE>
<?

} else {
	$id=1;
	#//
	if($_POST[action] == "login") {
		if(strlen($_POST[username]) == 0 ||	strlen($_POST[password]) == 0) {
			$ERR = $ERR_047;
		} else {
			$query = "select * from BPPENNYAUTOBID_adminusers where username='$_POST[username]' and password='".md5($MD5_PREFIX.$_POST[password])."'";
			$res = @mysql_query($query);
			if(!$res) {
				print "Error: $query<BR>".mysql_error();
				exit;
			}
			if(mysql_num_rows($res) == 0) {
				$ERR = $ERR_048;
			} else {
				$admin = mysql_fetch_array($res);
				#// Set sessions vars
				$BPPENNYAUTOBID_ADMIN_LOGIN = $admin[id];
				$BPPENNYAUTOBID_ADMIN_USER = $admin[username];
				$_SESSION["BPPENNYAUTOBID_ADMIN_LOGIN"]=$BPPENNYAUTOBID_ADMIN_LOGIN;
				$_SESSION["BPPENNYAUTOBID_ADMIN_USER"]=$BPPENNYAUTOBID_ADMIN_USER;
				#// Update last login information for this user
				$query = "update BPPENNYAUTOBID_adminusers set lastlogin='".date("YmdHis")."' where username='$admin[username]'";
				$rr = mysql_query($query);
				if(!$rr) {
					print "Error: $query<BR>".mysql_error();
					exit;
				}
				#// Redirect
				print "<SCRIPT Language=Javascript>
						parent.location.href='index.php';
						</SCRIPT>";
				//Header("Location: home.php");
				exit;
			}
		}
	}
	
?>
<br/><br/>
<?php 
if($BPPENNYAUTOBID_TESTMODE == 'yes'){
?>	
<TABLE style="border:1px solid #336699" WIDTH=410 CELLPADDING=5 CELLSPACING=0 BGCOLOR="#FFFFFF" ALIGN="CENTER">
    <TR>
        <TD align="left">
            DEMO Version<br /><br />
            
            Admin login: <b>admin</b><br />
            Admin password: <b>test</b><br />
        </TD>
    </TR>
    </TABLE>
<?php } ?>    
<TABLE BORDER=0 WIDTH=650 CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF" ALIGN="CENTER">
<TR>
	<TD>
		<CENTER>
		<BR><BR>
<? if(!$act || ($act && $ERR)) { ?>
		<FORM NAME=login ACTION=login.php METHOD=POST>
		<TABLE WIDTH="415" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#336699">
		<TR>
			<TD>
				<TABLE WIDTH=100% CELLPADDING=4 ALIGN="CENTER" CELLSPACING="0" BORDER="0" BGCOLOR="#FFFFFF">
				<TR BGCOLOR="#33CC33">
					<TD COLSPAN="2" ALIGN=CENTER>
						<B>:: PLEASE LOG IN WITH THE USERNAME & PASSWORD YOU CREATED ::</B>
					</TD>
				</TR>
				<TR>
					<TD></TD>
					<TD>
						<FONT COLOR=red><? print $ERR; ?>
					</TD>
				</TR>
				<TR>
					<TD ALIGN=right> 
						<? print $MSG_003; ?>
					</TD>
					<TD>
						<INPUT TYPE=TEXT NAME=username SIZE=20 >
					</TD>
				</TR>
				<TR>
					<TD ALIGN=right>
						<? print $MSG_004; ?>
					</TD>
					<TD>
						<INPUT TYPE=password NAME=password SIZE=20 >
					</TD>
				</TR>
					<TR>
						<TD>&nbsp;</TD>
						<TD>
							
							<!--
							<A HREF=http://www.BPPENNYAUTOBID.net/viewfaq.php?id=24 TARGET=_blank><?=$MSG_215?></A>
							-->
							
						</TD>
					</TR>
				<TR>
					<TD></TD>
					<TD>
						<INPUT TYPE="submit" NAME="action" VALUE="login">
					</TD>
				</TR>
				</TABLE>
			</TD>
		</TR>
		</TABLE>
		</FORM>
<?  }  ?>
		
		</CENTER>
	</TD>
</TR>
</TABLE>
<?  } 
require("./footer.php");  
?>