<?#//v.3.0.0
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";


@mysql_query("DELETE FROM BPPENNYAUTOBID_banners WHERE id=$banner");
@mysql_query("DELETE FROM BPPENNYAUTOBID_bannerscategories WHERE banner=$banner");
@mysql_query("DELETE FROM BPPENNYAUTOBID_bannerskeywords WHERE banner=$banner");

@unlink("$image_upload_path"."banners/$user/$name");

#// Redirect
Header("Location: userbanners.php?id=$user");
?>