<?
#///////////////////////////////////////////////////////

#///////////////////////////////////////////////////////

require('../includes/config.inc.php');
include_once "loggedin.inc.php";
include_once $include_path.'fonts.inc.php';


#//
$ERR = "";

#//
if($_POST[action] == "update" && basename($_SERVER['HTTP_REFERER']) == basename($_SERVER['PHP_SELF']))
{
	
	if($BPPENNYAUTOBID_TESTMODE == 'yes'){
		$ERR = $ERR_9999;
	}else{
	
	$query = " UPDATE BPPENNYAUTOBID_settings SET
				   showacceptancetext=$_POST[showacceptancetext],
				   acceptancetext='".addslashes($_POST[acceptancetext])."'";
	$res_ = @mysql_query($query);
	if(!$res_)
	{
		print "Error: $query<BR>".mysql_error();
		exit;
	}
	else
	{
		$SETTINGS = $_POST;
		$ERR = $MSG_25_0111;
	}
	}
}

#//
$query = "SELECT * FROM BPPENNYAUTOBID_settings";
$res = @mysql_query($query);
if(!$res)
{
	print "Error: $query<BR>".mysql_error();
	exit;
}
elseif(mysql_num_rows($res) > 0)
{
	$SETTINGS = mysql_fetch_array($res);
}

?>
<HTML>
<HEAD>
<link rel='stylesheet' type='text/css' href='style.css' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</HEAD>
<body bgcolor="#FFFFFF" text="#000000" link="#0066FF" vlink="#666666" alink="#000066" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr> 
    <td background="images/bac_barint.gif"><table width="100%" border="0" cellspacing="5" cellpadding="0">
        <tr> 
          <td width="30"><img src="images/i_use.gif"></td>
          <td class=white><?=$MSG_25_0010?>&nbsp;&gt;&gt;&nbsp;<?=$MSG_25_0110?></td>
        </tr>
      </table></td>
  </tr>
  <tr>
    <td align="center" valign="middle">&nbsp;</td>
  </tr>
    <tr> 
    <td align="center" valign="middle">
<TABLE BORDER=0 WIDTH=100% CELLPADDING=0 CELLSPACING=0 BGCOLOR="#FFFFFF">
<TR>
<TD align="center">
<BR>
<FORM NAME=conf ACTION="<?=basename($_SERVER['PHP_SELF'])?>" METHOD="POST"  ENCTYPE="multipart/form-data">
	<TABLE WIDTH="95%" BORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#546f95">
		<TR>
			<TD ALIGN=CENTER class=title>
				<? print $MSG_25_0110; ?>
				</TD>
		</TR>
		<TR>
	<TD>
		<TABLE WIDTH=100% CELLPADDING=2 ALIGN="CENTER" BGCOLOR="#FFFFFF">
		  <?
		  if($ERR != "")
		  {
		?>
		  <TR>
			<TD class=error COLSPAN="2" ALIGN=CENTER bgcolor="yellow"><? print $ERR; ?></TD>
		  </TR>
		  <?
		  }
		?>
		  <tr valign="TOP">
			<td colspan="2"><img src="../images/transparent.gif" width="1" height="5"></td>
		  </tr>

		  <tr valign="TOP">
			<td width=169>
			  <? print $MSG_534; ?>
			  </td>
			<td width="393">
			  <? print $MSG_539; ?>
			  <br>
			  <input type="radio" name="showacceptancetext" value="1"
					 <? if($SETTINGS[showacceptancetext] == 1) print " CHECKED";?>
					 >
			  <? print $MSG_030; ?>
			  <input type="radio" name="showacceptancetext" value="2"
					 <? if($SETTINGS[showacceptancetext] == 2) print " CHECKED";?>
					 >
			  <? print $MSG_029; ?>
			   </td>
		  </tr>
		  <tr valign="TOP">
			<td width=169></td>
			<td width="393">
			  <textarea name="acceptancetext" cols="45" rows="10"><?=stripslashes($SETTINGS[acceptancetext])?></textarea>
			</td>
		  </tr>
		  <TR>
			<TD WIDTH=169>
			  <INPUT TYPE="hidden" NAME="action" VALUE="update">
			</TD>
			<TD WIDTH="393">
			  <INPUT TYPE="submit" NAME="act" VALUE="<? print $MSG_530; ?>">
			</TD>
		  </TR>
		  <TR>
			<TD WIDTH=169></TD>
			<TD WIDTH="393"> </TD>
		  </TR>
		</TABLE>
	</TD>
	</TR>
	</TABLE>
	</FORM>
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
</BODY>
</HTML>